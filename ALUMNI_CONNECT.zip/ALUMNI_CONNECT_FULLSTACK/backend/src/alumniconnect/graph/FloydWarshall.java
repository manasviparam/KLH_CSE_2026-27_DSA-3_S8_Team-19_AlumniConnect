package alumniconnect.graph;

import alumniconnect.model.Person;

import java.util.ArrayList;
import java.util.List;

/**
 * FLOYD-WARSHALL - "Overall Network Analysis".
 * All-pairs shortest connection distance (in hops) on the same accepted-connection graph used by Dijkstra.
 * Unreachable pairs stay +infinity (JSON null) and are excluded from every average / diameter.
 * dist[i][j] = min(dist[i][j], dist[i][k] + dist[k][j]) for every intermediate k. O(V^3).
 */
public final class FloydWarshall {
    private FloydWarshall() {}

    /** averageDistance is +infinity (JSON null) for a user who cannot reach anyone. */
    public record UserSummary(String id, String name, String role, String organization,
                              double averageDistance, int reachable, int unreachable, double closeness) {}

    public record Result(List<Dijkstra.NodeInfo> users, double[][] distances,
                         int userCount, int edgeCount,
                         Double diameter, String diameterFrom, String diameterTo,
                         Double averageDistance, int reachablePairs, int unreachablePairs,
                         int components, double density,
                         List<UserSummary> centrality, List<UserSummary> mostIsolated,
                         String formula) {}

    public static Result analyse(SocialGraph g) {
        int n = g.size();
        double[][] d = g.weightMatrix();

        for (int k = 0; k < n; k++)
            for (int i = 0; i < n; i++) {
                if (Double.isInfinite(d[i][k])) continue;
                for (int j = 0; j < n; j++) {
                    double via = d[i][k] + d[k][j];
                    if (via < d[i][j]) d[i][j] = via;
                }
            }

        List<Dijkstra.NodeInfo> users = new ArrayList<>();
        for (int i = 0; i < n; i++) users.add(Dijkstra.info(g.node(i)));

        double diameter = -1, sum = 0;
        int dI = -1, dJ = -1, reachablePairs = 0, unreachablePairs = 0;
        List<UserSummary> summaries = new ArrayList<>();

        for (int i = 0; i < n; i++) {
            double rowSum = 0;
            int reach = 0;
            for (int j = 0; j < n; j++) {
                if (i == j) continue;
                if (Double.isInfinite(d[i][j])) {
                    if (i < j) unreachablePairs++;
                } else {
                    rowSum += d[i][j];
                    reach++;
                    if (i < j) {
                        reachablePairs++;
                        sum += d[i][j];
                        if (d[i][j] > diameter) { diameter = d[i][j]; dI = i; dJ = j; }
                    }
                }
            }
            Person p = g.node(i);
            double avg = reach == 0 ? Double.POSITIVE_INFINITY : rowSum / reach;
            // closeness: reachable share of the network divided by average distance (higher = more central)
            double closeness = (reach == 0 || n <= 1) ? 0 : ((double) reach / (n - 1)) / avg;
            summaries.add(new UserSummary(p.id(), p.name(), p.role(), p.organization(), avg, reach, n - 1 - reach, closeness));
        }

        // most central = highest closeness; most isolated = lowest. InsertionSort-style stable ranking.
        List<UserSummary> byCloseness = alumniconnect.dsa.InsertionSort.sort(summaries,
                (a, b) -> Double.compare(b.closeness(), a.closeness()));
        List<UserSummary> top = new ArrayList<>();      // a user who reaches nobody is never "central"
        for (UserSummary u : byCloseness) if (u.reachable() > 0 && top.size() < 5) top.add(u);
        List<UserSummary> bottom = new ArrayList<>();
        for (int k = byCloseness.size() - 1; k >= 0 && bottom.size() < 5; k--) bottom.add(byCloseness.get(k));

        double density = n < 2 ? 0 : (2.0 * g.edgeCount()) / ((double) n * (n - 1));
        return new Result(users, d, n, g.edgeCount(),
                dI < 0 ? null : diameter, dI < 0 ? null : g.node(dI).name(), dI < 0 ? null : g.node(dJ).name(),
                reachablePairs == 0 ? null : sum / reachablePairs, reachablePairs, unreachablePairs,
                countComponents(d), density, top, bottom,
                "dist[i][j] = min(dist[i][j], dist[i][k] + dist[k][j]) for every intermediate user k");
    }

    private static int countComponents(double[][] d) {
        int n = d.length;
        boolean[] seen = new boolean[n];
        int comps = 0;
        for (int i = 0; i < n; i++) {
            if (seen[i]) continue;
            comps++;
            for (int j = 0; j < n; j++) if (!Double.isInfinite(d[i][j])) seen[j] = true;
        }
        return comps;
    }
}
