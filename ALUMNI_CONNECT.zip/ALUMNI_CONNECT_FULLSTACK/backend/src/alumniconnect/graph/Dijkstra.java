package alumniconnect.graph;

import alumniconnect.model.Person;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * DIJKSTRA - "Best Connection Path".
 * Finds the shortest chain of ACCEPTED connections between two users. Each accepted connection
 * costs 1, so the cheapest path is the one with the fewest hops. Uses our own binary min-heap.
 * O((V + E) log V).
 */
public final class Dijkstra {
    private Dijkstra() {}

    public record NodeInfo(String id, String name, String role, String organization) {}

    public record Result(boolean found, String message, NodeInfo source, NodeInfo target,
                         int hops, List<NodeInfo> path) {}

    static NodeInfo info(Person p) {
        return new NodeInfo(p.id(), p.name(), p.role(), p.organization());
    }

    public static Result shortestPath(SocialGraph g, String fromId, String toId) {
        int s = g.indexOf(fromId), t = g.indexOf(toId);
        if (s < 0 || t < 0) {
            return new Result(false, "User not found in the synced network: " + (s < 0 ? fromId : toId),
                    null, null, 0, List.of());
        }
        NodeInfo src = info(g.node(s)), dst = info(g.node(t));
        if (s == t) {
            return new Result(true, "Source and target are the same user.", src, dst, 0, List.of(src));
        }

        int n = g.size();
        double[] dist = new double[n];
        int[] prev = new int[n];
        boolean[] done = new boolean[n];
        Arrays.fill(dist, Double.POSITIVE_INFINITY);
        Arrays.fill(prev, -1);
        dist[s] = 0;

        MinHeap heap = new MinHeap();
        heap.push(s, 0);
        while (!heap.isEmpty()) {
            int u = heap.pop();
            if (done[u]) continue;             // stale heap entry
            done[u] = true;
            if (u == t) break;
            for (SocialGraph.Edge e : g.edges(u)) {
                if (done[e.to()]) continue;
                double candidate = dist[u] + e.weight();
                if (candidate < dist[e.to()]) {
                    dist[e.to()] = candidate;
                    prev[e.to()] = u;
                    heap.push(e.to(), candidate);
                }
            }
        }

        if (Double.isInfinite(dist[t])) {
            return new Result(false, "No connection path exists between these two users through accepted connections.",
                    src, dst, 0, List.of());
        }

        List<NodeInfo> path = new ArrayList<>();
        for (int v = t; v != -1; v = prev[v]) path.add(0, info(g.node(v)));
        return new Result(true, "Best connection path found.", src, dst, path.size() - 1, path);
    }
}
