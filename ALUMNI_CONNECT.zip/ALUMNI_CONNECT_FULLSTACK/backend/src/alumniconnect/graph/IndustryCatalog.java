package alumniconnect.graph;

import alumniconnect.model.Person;

import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Deterministic industry lookup (no randomness, no external data).
 * A person's industries = explicit industry field (if filled)
 *                       + industry of their organization (lookup table)
 *                       + industries whose keywords appear in skills / interests.
 * Department is NOT handled here - it is only ever read from the optional profile field.
 */
public final class IndustryCatalog {
    private IndustryCatalog() {}

    private static final Map<String, String> ORGANIZATIONS = new LinkedHashMap<>();
    private static final Map<String, List<String>> KEYWORDS = new LinkedHashMap<>();

    static {
        // organization (lower-case word) -> industry
        for (String o : new String[]{"google", "microsoft", "amazon", "oracle", "ibm", "salesforce"})
            ORGANIZATIONS.put(o, "Cloud & Platform");
        for (String o : new String[]{"meta", "facebook", "netflix", "spotify", "linkedin", "twitter"})
            ORGANIZATIONS.put(o, "Media & Social");
        for (String o : new String[]{"apple", "samsung"}) ORGANIZATIONS.put(o, "Mobile & Devices");
        for (String o : new String[]{"adobe", "autodesk", "figma"}) ORGANIZATIONS.put(o, "Creative Software");
        for (String o : new String[]{"uber", "ola", "swiggy", "zomato"}) ORGANIZATIONS.put(o, "Mobility & Logistics");
        for (String o : new String[]{"stripe", "paypal", "razorpay", "visa", "mastercard", "paytm"})
            ORGANIZATIONS.put(o, "Fintech");

        // industry -> keywords (single words match whole tokens, phrases match as substrings)
        KEYWORDS.put("Cloud & Platform", List.of("cloud", "aws", "azure", "gcp", "kubernetes", "docker", "devops",
                "microservices", "distributed", "kafka", "infrastructure", "backend", "availability"));
        KEYWORDS.put("Media & Social", List.of("react", "graphql", "streaming", "frontend", "ui", "ux",
                "javascript", "web"));
        KEYWORDS.put("Mobile & Devices", List.of("ios", "swift", "android", "kotlin", "mobile"));
        KEYWORDS.put("Creative Software", List.of("graphics", "webassembly", "compilers", "compiler", "creative"));
        KEYWORDS.put("Data & AI", List.of("ai", "ml", "pytorch", "tensorflow", "analytics",
                "machine learning", "data science", "data engineering"));
        KEYWORDS.put("Fintech", List.of("fintech", "financial", "finance", "payments", "banking"));
        KEYWORDS.put("Mobility & Logistics", List.of("mobility", "logistics"));
    }

    public static Set<String> industriesOf(Person p) {
        Set<String> out = new LinkedHashSet<>();
        if (!p.industry().isEmpty()) out.add(p.industry());

        Set<String> orgWords = Text.tokens(List.of(p.organization()));
        for (Map.Entry<String, String> e : ORGANIZATIONS.entrySet()) {
            if (orgWords.contains(e.getKey())) out.add(e.getValue());
        }

        List<String> texts = new java.util.ArrayList<>(p.skills());
        texts.addAll(p.interests());
        Set<String> tokens = Text.tokens(texts);
        String joined = String.join(" ", texts).toLowerCase();
        for (Map.Entry<String, List<String>> e : KEYWORDS.entrySet()) {
            for (String kw : e.getValue()) {
                boolean hit = kw.contains(" ") ? joined.contains(kw) : tokens.contains(kw);
                if (hit) { out.add(e.getKey()); break; }
            }
        }
        return out;
    }
}
