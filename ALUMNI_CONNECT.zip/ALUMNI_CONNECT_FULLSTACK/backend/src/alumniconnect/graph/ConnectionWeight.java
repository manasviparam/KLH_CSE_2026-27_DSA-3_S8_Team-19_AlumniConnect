package alumniconnect.graph;

import alumniconnect.model.Person;

import java.util.List;
import java.util.Set;

/**
 * CONNECTION STRENGTH -> EDGE WEIGHT (deterministic, never random).
 *
 *   strength = 0.35 * commonSkills      (Jaccard of skill sets)
 *            + 0.15 * sameDepartment    (1 if both filled in and equal, else 0)
 *            + 0.20 * sameIndustry      (Jaccard of industry sets, see IndustryCatalog)
 *            + 0.15 * mutualConnections (Jaccard of accepted-connection neighbour sets)
 *            + 0.05 * sharedInterests   (Jaccard of interest WORDS, e.g. "Backend Dev" ~ "Backend Systems")
 *            + 0.10 * directConnection  (1 if an accepted connection exists between them)
 *
 *   weight   = max(0.05, 1 - strength)      stronger relationship => LOWER weight
 *
 * Two users get an edge when they are directly connected or strength >= MIN_EDGE_STRENGTH.
 */
public final class ConnectionWeight {
    private ConnectionWeight() {}

    public static final double W_SKILLS = 0.35;
    public static final double W_DEPARTMENT = 0.15;
    public static final double W_INDUSTRY = 0.20;
    public static final double W_MUTUAL = 0.15;
    public static final double W_INTERESTS = 0.05;
    public static final double W_DIRECT = 0.10;

    public static final double MIN_EDGE_STRENGTH = 0.10;
    public static final double MIN_WEIGHT = 0.05;

    public static final String FORMULA =
            "strength = 0.35*commonSkills + 0.15*sameDepartment + 0.20*sameIndustry + 0.15*mutualConnections"
                    + " + 0.05*sharedInterests + 0.10*directConnection;  weight = max(0.05, 1 - strength)";

    /** Every number that went into one edge, so the UI can explain it. */
    public record Breakdown(
            double commonSkills, double sameDepartment, double sameIndustry,
            double mutualConnections, double sharedInterests, double directConnection,
            double strength, double weight,
            List<String> commonSkillList, List<String> sharedIndustryList,
            int mutualCount, boolean directlyConnected) {}

    public static Breakdown compute(Person a, Person b, Set<String> neighboursA, Set<String> neighboursB,
                                    boolean directlyConnected) {
        Set<String> skillsA = Text.normSet(a.skills());
        Set<String> skillsB = Text.normSet(b.skills());
        double skills = Text.jaccard(skillsA, skillsB);

        double dept = (!a.department().isEmpty() && Text.norm(a.department()).equals(Text.norm(b.department()))) ? 1.0 : 0.0;

        Set<String> indA = IndustryCatalog.industriesOf(a);
        Set<String> indB = IndustryCatalog.industriesOf(b);
        double industry = Text.jaccard(indA, indB);

        // mutual connections: shared accepted-connection neighbours, ignoring the pair itself
        Set<String> nA = new java.util.LinkedHashSet<>(neighboursA);
        Set<String> nB = new java.util.LinkedHashSet<>(neighboursB);
        nA.remove(a.id()); nA.remove(b.id());
        nB.remove(a.id()); nB.remove(b.id());
        double mutual = Text.jaccard(nA, nB);
        int mutualCount = Text.intersection(nA, nB).size();

        double interests = Text.jaccard(Text.tokens(a.interests()), Text.tokens(b.interests()));
        double direct = directlyConnected ? 1.0 : 0.0;

        double strength = W_SKILLS * skills + W_DEPARTMENT * dept + W_INDUSTRY * industry
                + W_MUTUAL * mutual + W_INTERESTS * interests + W_DIRECT * direct;
        strength = Math.min(1.0, strength);
        double weight = Math.max(MIN_WEIGHT, 1.0 - strength);

        return new Breakdown(skills, dept, industry, mutual, interests, direct, strength, weight,
                Text.list(Text.intersection(skillsA, skillsB)), Text.list(Text.intersection(indA, indB)),
                mutualCount, directlyConnected);
    }
}
