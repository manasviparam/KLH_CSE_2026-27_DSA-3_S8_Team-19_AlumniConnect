package alumniconnect.graph;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** Small deterministic text helpers shared by the graph scoring code. */
final class Text {
    private Text() {}

    static String norm(String s) {
        return s == null ? "" : s.toLowerCase(Locale.ROOT).trim();
    }

    /** Lower-cased, trimmed, de-duplicated items (insertion order kept). */
    static Set<String> normSet(List<String> items) {
        Set<String> out = new LinkedHashSet<>();
        for (String s : items) {
            String n = norm(s);
            if (!n.isEmpty()) out.add(n);
        }
        return out;
    }

    /** Words made of letters/digits (plus + # for c++ / c#), length >= 2. */
    static Set<String> tokens(List<String> items) {
        Set<String> out = new LinkedHashSet<>();
        for (String s : items) {
            for (String t : norm(s).split("[^a-z0-9+#]+")) {
                if (t.length() >= 2) out.add(t);
            }
        }
        return out;
    }

    static <T> Set<T> intersection(Set<T> a, Set<T> b) {
        Set<T> out = new LinkedHashSet<>();
        for (T x : a) if (b.contains(x)) out.add(x);
        return out;
    }

    static <T> int unionSize(Set<T> a, Set<T> b) {
        return a.size() + b.size() - intersection(a, b).size();
    }

    /** |A n B| / |A u B|, or 0 when both are empty. */
    static <T> double jaccard(Set<T> a, Set<T> b) {
        int union = unionSize(a, b);
        return union == 0 ? 0.0 : (double) intersection(a, b).size() / union;
    }

    static List<String> list(Set<String> s) { return new ArrayList<>(s); }
}
