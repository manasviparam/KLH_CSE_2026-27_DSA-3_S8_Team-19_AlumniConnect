package alumniconnect.graph;

import alumniconnect.model.Connection;
import alumniconnect.model.Person;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Undirected social graph built from the synced users and ACCEPTED connections only.
 * Pending / rejected requests and profile similarity never create an edge.
 * Every edge has the same weight (1.0), so a path's cost is its number of hops.
 * Stored as an adjacency list (for Dijkstra) and a weight matrix (for Floyd-Warshall).
 */
public final class SocialGraph {

    /** Cost of one accepted connection. */
    public static final double EDGE_WEIGHT = 1.0;

    public record Edge(int to, double weight) {}

    private final List<Person> nodes = new ArrayList<>();
    private final Map<String, Integer> index = new HashMap<>();
    private final List<List<Edge>> adjacency = new ArrayList<>();
    private int edgeCount = 0;

    public SocialGraph(List<Person> people, List<Connection> connections) {
        for (Person p : people) {
            if (p.id().isEmpty() || index.containsKey(p.id())) continue;
            index.put(p.id(), nodes.size());
            nodes.add(p);
            adjacency.add(new ArrayList<>());
        }

        Set<String> seen = new HashSet<>();   // ignore duplicate records of the same pair
        for (Connection c : connections) {
            if (!c.isAccepted() || c.studentId().equals(c.alumniId())) continue;
            Integer a = index.get(c.studentId()), b = index.get(c.alumniId());
            if (a == null || b == null || !seen.add(pairKey(c.studentId(), c.alumniId()))) continue;
            adjacency.get(a).add(new Edge(b, EDGE_WEIGHT));
            adjacency.get(b).add(new Edge(a, EDGE_WEIGHT));
            edgeCount++;
        }
    }

    static String pairKey(String a, String b) {
        return a.compareTo(b) < 0 ? a + "|" + b : b + "|" + a;
    }

    public int size() { return nodes.size(); }

    public int edgeCount() { return edgeCount; }

    public Person node(int i) { return nodes.get(i); }

    public List<Person> nodes() { return nodes; }

    /** Index of the user id, or -1 when unknown. */
    public int indexOf(String id) { return index.getOrDefault(id, -1); }

    public List<Edge> edges(int i) { return adjacency.get(i); }

    /** Weight matrix: 0 on the diagonal, edge weight where an edge exists, +infinity elsewhere. */
    public double[][] weightMatrix() {
        int n = nodes.size();
        double[][] w = new double[n][n];
        for (int i = 0; i < n; i++) {
            java.util.Arrays.fill(w[i], Double.POSITIVE_INFINITY);
            w[i][i] = 0;
            for (Edge e : adjacency.get(i)) w[i][e.to()] = Math.min(w[i][e.to()], e.weight());
        }
        return w;
    }
}
