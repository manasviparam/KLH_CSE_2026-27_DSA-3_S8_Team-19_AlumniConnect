package alumniconnect.graph;

import alumniconnect.dsa.InsertionSort;
import alumniconnect.model.Person;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * BIPARTITE MATCHING - "Alumni Mentor Matching".
 * Left set = students, right set = alumni (two disjoint sets). An edge student-alumnus exists when
 * MentorScore >= MIN_SCORE. Maximum matching via Kuhn's augmenting-path algorithm (DFS):
 * for each student try to take a free alumnus slot, otherwise ask the current owner to move.
 * Each alumnus can mentor `capacity` students (capacity 1 = classic one-to-one matching).
 * O(V * E). Students with the fewest options go first; each student tries best-scoring alumni first.
 */
public final class BipartiteMatching {
    private BipartiteMatching() {}

    public record Candidate(String alumniId, String alumniName, String organization, double score,
                            List<String> commonSkills, List<String> commonInterests, List<String> sharedIndustries) {}

    public record Match(String studentId, String studentName, String alumniId, String alumniName,
                        String organization, double score,
                        List<String> commonSkills, List<String> commonInterests, List<String> sharedIndustries) {}

    public record Unmatched(String id, String name, String reason) {}

    public record Result(int studentCount, int alumniCount, int capacity, int edgeCount, int matchingSize,
                         List<Match> matches, List<Unmatched> unmatchedStudents, List<Unmatched> unmatchedAlumni,
                         Map<String, List<Candidate>> candidates, String formula) {}

    public static Result match(List<Person> students, List<Person> alumni, int capacity) {
        capacity = Math.max(1, capacity);
        int S = students.size(), A = alumni.size();

        // ---- build edges (score matrix) ----
        MentorScore.Score[][] scores = new MentorScore.Score[S][A];
        List<List<Integer>> adj = new ArrayList<>();
        int edges = 0;
        for (int s = 0; s < S; s++) {
            List<Integer> cand = new ArrayList<>();
            for (int a = 0; a < A; a++) {
                scores[s][a] = MentorScore.compute(students.get(s), alumni.get(a));
                if (scores[s][a].score() >= MentorScore.MIN_SCORE) { cand.add(a); edges++; }
            }
            final int si = s;
            adj.add(InsertionSort.sort(cand, (x, y) -> Double.compare(scores[si][y].score(), scores[si][x].score())));
        }

        // ---- Kuhn's algorithm over alumni "slots" ----
        int slots = A * capacity;
        int[] slotOwner = new int[slots];            // slot -> student index or -1
        Arrays.fill(slotOwner, -1);

        List<Integer> order = new ArrayList<>();
        for (int s = 0; s < S; s++) order.add(s);
        order = InsertionSort.sort(order, (x, y) -> Integer.compare(adj.get(x).size(), adj.get(y).size()));

        int matched = 0;
        for (int s : order) {
            boolean[] visited = new boolean[slots];
            if (augment(s, adj, capacity, slotOwner, visited)) matched++;
        }

        // ---- collect result ----
        int[] studentAlumnus = new int[S];
        Arrays.fill(studentAlumnus, -1);
        int[] load = new int[A];
        for (int slot = 0; slot < slots; slot++) {
            if (slotOwner[slot] >= 0) { studentAlumnus[slotOwner[slot]] = slot / capacity; load[slot / capacity]++; }
        }

        List<Match> matches = new ArrayList<>();
        List<Unmatched> unmatchedStudents = new ArrayList<>();
        for (int s = 0; s < S; s++) {
            Person st = students.get(s);
            int a = studentAlumnus[s];
            if (a >= 0) {
                MentorScore.Score sc = scores[s][a];
                Person al = alumni.get(a);
                matches.add(new Match(st.id(), st.name(), al.id(), al.name(), al.organization(), sc.score(),
                        sc.commonSkills(), sc.commonInterests(), sc.sharedIndustries()));
            } else {
                unmatchedStudents.add(new Unmatched(st.id(), st.name(), adj.get(s).isEmpty()
                        ? "No alumnus is suitable (no score reached " + MentorScore.MIN_SCORE + ")"
                        : "All suitable alumni are already matched to other students"));
            }
        }
        List<Unmatched> unmatchedAlumni = new ArrayList<>();
        for (int a = 0; a < A; a++) {
            if (load[a] == 0) unmatchedAlumni.add(new Unmatched(alumni.get(a).id(), alumni.get(a).name(),
                    "No student was assigned"));
        }

        Map<String, List<Candidate>> candidates = new LinkedHashMap<>();
        for (int s = 0; s < S; s++) {
            List<Candidate> list = new ArrayList<>();
            for (int a : adj.get(s)) {
                MentorScore.Score sc = scores[s][a];
                Person al = alumni.get(a);
                list.add(new Candidate(al.id(), al.name(), al.organization(), sc.score(),
                        sc.commonSkills(), sc.commonInterests(), sc.sharedIndustries()));
            }
            candidates.put(students.get(s).id(), list);
        }
        return new Result(S, A, capacity, edges, matched, matches, unmatchedStudents, unmatchedAlumni,
                candidates, MentorScore.FORMULA);
    }

    /** Kuhn's DFS: can student s get a slot, possibly by re-assigning another student? */
    private static boolean augment(int s, List<List<Integer>> adj, int capacity, int[] slotOwner, boolean[] visited) {
        for (int a : adj.get(s)) {
            for (int c = 0; c < capacity; c++) {
                int slot = a * capacity + c;
                if (visited[slot]) continue;
                visited[slot] = true;
                if (slotOwner[slot] == -1 || augment(slotOwner[slot], adj, capacity, slotOwner, visited)) {
                    slotOwner[slot] = s;
                    return true;
                }
            }
        }
        return false;
    }
}
