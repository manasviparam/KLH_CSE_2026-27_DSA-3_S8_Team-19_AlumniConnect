package alumniconnect.graph;

import alumniconnect.dsa.InsertionSort;
import alumniconnect.model.Connection;
import alumniconnect.model.Person;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * PEOPLE YOU MAY KNOW.
 * Connections only exist between a student and an alumnus, so candidates are the people of the
 * OPPOSITE role. A candidate C is recommended to user U when they have mutual accepted connections:
 * people X who are connected to C and who are connected to U or share an accepted connection with U
 * (e.g. student U -- alumnus A1 -- student X -- alumnus C).
 * Excluded: U itself, anyone already connected to U, anyone with a pending request with U.
 * Ranking: 1) number of mutual connections (primary), 2) profile similarity (secondary tie-break),
 * 3) name (deterministic). Candidates without any mutual connection are not recommended.
 */
public final class Recommender {
    private Recommender() {}

    public record Suggestion(String id, String name, String role, String organization,
                             int mutualCount, List<String> mutualConnections,
                             double similarity, List<String> commonSkills) {}

    public record Result(boolean found, String message, int limit, List<Suggestion> suggestions) {}

    public static Result recommend(SocialGraph g, List<Connection> connections, String userId, int limit) {
        limit = Math.max(1, limit);
        int u = g.indexOf(userId);
        if (u < 0) return new Result(false, "User not found in the synced network: " + userId, limit, List.of());

        // every pair with a pending request (either direction) is excluded
        Set<String> pending = new HashSet<>();
        for (Connection c : connections)
            if ("pending".equalsIgnoreCase(c.status())) pending.add(SocialGraph.pairKey(c.studentId(), c.alumniId()));

        Set<Integer> direct = new HashSet<>();
        for (SocialGraph.Edge e : g.edges(u)) direct.add(e.to());

        // people who are connected to U or share an accepted connection with U (U's circle)
        Set<Integer> circle = new HashSet<>(direct);
        for (int d : direct) for (SocialGraph.Edge e : g.edges(d)) if (e.to() != u) circle.add(e.to());

        Person me = g.node(u);
        List<Suggestion> list = new ArrayList<>();
        for (int c = 0; c < g.size(); c++) {
            Person cand = g.node(c);
            if (c == u || direct.contains(c)) continue;
            if (cand.role().equalsIgnoreCase(me.role())) continue;           // cannot be connected: same role
            if (pending.contains(SocialGraph.pairKey(me.id(), cand.id()))) continue;

            Set<String> mutual = new LinkedHashSet<>();
            for (SocialGraph.Edge e : g.edges(c)) if (circle.contains(e.to())) mutual.add(g.node(e.to()).name());
            if (mutual.isEmpty()) continue;

            ConnectionWeight.Breakdown br = ConnectionWeight.compute(me, cand, Set.of(), Set.of(), false);
            list.add(new Suggestion(cand.id(), cand.name(), cand.role(), cand.organization(),
                    mutual.size(), new ArrayList<>(mutual), br.strength(), br.commonSkillList()));
        }

        List<Suggestion> ranked = InsertionSort.sort(list, (a, b) -> {
            if (a.mutualCount() != b.mutualCount()) return Integer.compare(b.mutualCount(), a.mutualCount());
            int bySim = Double.compare(b.similarity(), a.similarity());
            return bySim != 0 ? bySim : a.name().compareToIgnoreCase(b.name());
        });
        if (ranked.size() > limit) ranked = new ArrayList<>(ranked.subList(0, limit));
        return new Result(true, ranked.isEmpty() ? "No recommendations yet - connect with more people." : "OK",
                limit, ranked);
    }
}
