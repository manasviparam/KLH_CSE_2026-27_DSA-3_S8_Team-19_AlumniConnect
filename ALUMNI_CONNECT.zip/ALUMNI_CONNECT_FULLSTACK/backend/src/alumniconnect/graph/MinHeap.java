package alumniconnect.graph;

/** Binary min-heap of (node, priority) pairs - the priority queue used by Dijkstra. */
final class MinHeap {
    private int[] nodes = new int[16];
    private double[] keys = new double[16];
    private int size = 0;

    boolean isEmpty() { return size == 0; }

    void push(int node, double key) {
        if (size == nodes.length) grow();
        nodes[size] = node;
        keys[size] = key;
        siftUp(size++);
    }

    /** Removes the smallest entry and returns {node}; read its key with lastKey(). */
    int pop() {
        int top = nodes[0];
        lastKey = keys[0];
        size--;
        if (size > 0) {
            nodes[0] = nodes[size];
            keys[0] = keys[size];
            siftDown(0);
        }
        return top;
    }

    private double lastKey;

    double lastKey() { return lastKey; }

    private void siftUp(int i) {
        while (i > 0) {
            int parent = (i - 1) / 2;
            if (keys[parent] <= keys[i]) break;
            swap(parent, i);
            i = parent;
        }
    }

    private void siftDown(int i) {
        while (true) {
            int l = 2 * i + 1, r = l + 1, smallest = i;
            if (l < size && keys[l] < keys[smallest]) smallest = l;
            if (r < size && keys[r] < keys[smallest]) smallest = r;
            if (smallest == i) return;
            swap(i, smallest);
            i = smallest;
        }
    }

    private void swap(int a, int b) {
        int tn = nodes[a]; nodes[a] = nodes[b]; nodes[b] = tn;
        double tk = keys[a]; keys[a] = keys[b]; keys[b] = tk;
    }

    private void grow() {
        nodes = java.util.Arrays.copyOf(nodes, size * 2);
        keys = java.util.Arrays.copyOf(keys, size * 2);
    }
}
