package alumniconnect.graph;

import alumniconnect.model.Person;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * Student -> alumnus suitability score in [0, 1] (deterministic):
 *
 *   score = 0.45 * skillCoverage     share of the student's skills the alumnus also has
 *         + 0.30 * interestCoverage  share of the student's interest words found in the alumnus' interests/skills
 *         + 0.25 * industryOverlap   Jaccard of the two industry sets (see IndustryCatalog)
 *
 * A bipartite edge exists when score >= MIN_SCORE.
 */
public final class MentorScore {
    private MentorScore() {}

    public static final double W_SKILLS = 0.45, W_INTERESTS = 0.30, W_INDUSTRY = 0.25;
    public static final double MIN_SCORE = 0.20;
    public static final String FORMULA =
            "score = 0.45*skillCoverage + 0.30*interestCoverage + 0.25*industryOverlap;  edge if score >= 0.20";

    public record Score(double score, double skills, double interests, double industry,
                        List<String> commonSkills, List<String> commonInterests, List<String> sharedIndustries) {}

    public static Score compute(Person student, Person alumnus) {
        Set<String> sSkills = Text.normSet(student.skills());
        Set<String> aSkills = Text.normSet(alumnus.skills());
        Set<String> commonSkills = Text.intersection(sSkills, aSkills);
        double skillCoverage = sSkills.isEmpty() ? 0 : (double) commonSkills.size() / sSkills.size();

        Set<String> sInterestWords = Text.tokens(student.interests());
        List<String> alumnusPool = new ArrayList<>(alumnus.interests());
        alumnusPool.addAll(alumnus.skills());
        Set<String> aWords = Text.tokens(alumnusPool);
        Set<String> commonWords = Text.intersection(sInterestWords, aWords);
        double interestCoverage = sInterestWords.isEmpty() ? 0 : (double) commonWords.size() / sInterestWords.size();

        Set<String> sInd = IndustryCatalog.industriesOf(student);
        Set<String> aInd = IndustryCatalog.industriesOf(alumnus);
        double industry = Text.jaccard(sInd, aInd);

        double score = W_SKILLS * skillCoverage + W_INTERESTS * interestCoverage + W_INDUSTRY * industry;
        return new Score(score, skillCoverage, interestCoverage, industry,
                Text.list(commonSkills), Text.list(commonWords), Text.list(Text.intersection(sInd, aInd)));
    }
}
