package alumniconnect.model;

import java.util.List;

/**
 * A node of the social graph: either a student or an alumnus.
 * department and industry are OPTIONAL and are only used when the user entered them
 * (department is never derived from bio or skills).
 */
public record Person(
        String id,
        String name,
        String role,            // "student" or "alumni"
        String college,
        int graduationYear,
        String organization,    // alumni only (empty for students)
        String department,      // optional, may be empty
        String industry,        // optional explicit industry, may be empty
        List<String> skills,
        List<String> interests,
        String bio) {

    public Person {
        id = id == null ? "" : id;
        name = name == null ? "" : name;
        role = role == null ? "" : role;
        college = college == null ? "" : college;
        organization = organization == null ? "" : organization;
        department = department == null ? "" : department.trim();
        industry = industry == null ? "" : industry.trim();
        skills = skills == null ? List.of() : List.copyOf(skills);
        interests = interests == null ? List.of() : List.copyOf(interests);
        bio = bio == null ? "" : bio;
    }

    public boolean isStudent() { return "student".equalsIgnoreCase(role); }

    public boolean isAlumni() { return "alumni".equalsIgnoreCase(role); }
}
