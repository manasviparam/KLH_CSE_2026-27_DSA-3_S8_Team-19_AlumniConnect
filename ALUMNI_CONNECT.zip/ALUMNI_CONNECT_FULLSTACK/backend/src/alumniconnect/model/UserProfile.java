package alumniconnect.model;

import java.util.List;

/**
 * Minimal profile shape used by the DSA layer (search, autocomplete, similarity).
 * Mirrors the fields stored in localStorage for alumni/student profiles.
 * Null values are normalised to empty values so algorithms never see null.
 */
public record UserProfile(
        String userId,
        String name,
        String organization,
        String college,
        int graduationYear,
        List<String> skills,
        List<String> interests,
        String bio) {

    public UserProfile {
        userId = userId == null ? "" : userId;
        name = name == null ? "" : name;
        organization = organization == null ? "" : organization;
        college = college == null ? "" : college;
        skills = skills == null ? List.of() : List.copyOf(skills);
        interests = interests == null ? List.of() : List.copyOf(interests);
        bio = bio == null ? "" : bio;
    }
}
