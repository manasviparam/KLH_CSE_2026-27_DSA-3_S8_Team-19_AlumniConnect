package alumniconnect.model;

/** A student-alumni connection request/record, as stored in the frontend. */
public record Connection(String id, String studentId, String alumniId, String status) {
    public boolean isAccepted() { return "accepted".equalsIgnoreCase(status); }
}
