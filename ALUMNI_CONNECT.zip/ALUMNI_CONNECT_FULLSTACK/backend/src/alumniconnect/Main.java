package alumniconnect;

import alumniconnect.server.ApiServer;
import alumniconnect.server.handlers.DsaDemoHandler;
import alumniconnect.server.handlers.GraphHandler;
import alumniconnect.server.handlers.SearchHandler;
import alumniconnect.server.handlers.SimilarityHandler;
import alumniconnect.server.handlers.SyncHandler;
import alumniconnect.store.DataStore;

import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Entry point.  Usage:  java -cp out alumniconnect.Main [port] [webRoot]
 * Serves the HTML/CSS/JS frontend and the /api endpoints from one process.
 */
public class Main {
    public static void main(String[] args) throws Exception {
        int port = args.length > 0 ? Integer.parseInt(args[0]) : 8080;
        Path webRoot = args.length > 1 ? Path.of(args[1]) : defaultWebRoot();

        DataStore store = new DataStore();
        ApiServer api = new ApiServer(port, webRoot);
        SyncHandler.register(api, store);
        SearchHandler.register(api, store);
        SimilarityHandler.register(api, store);
        DsaDemoHandler.register(api, store);
        GraphHandler.register(api, store);
        api.start();

        System.out.println("AlumniConnect is running  ->  http://localhost:" + port);
        System.out.println("Frontend folder           ->  " + webRoot.toAbsolutePath().normalize());
        System.out.println("Press Ctrl+C to stop.");
    }

    /** The project root is the folder that contains backend/ (works when started from backend/ or the root). */
    private static Path defaultWebRoot() {
        if (Files.exists(Path.of("..", "index.html"))) return Path.of("..");
        if (Files.exists(Path.of("index.html"))) return Path.of(".");
        return Path.of("..");
    }
}
