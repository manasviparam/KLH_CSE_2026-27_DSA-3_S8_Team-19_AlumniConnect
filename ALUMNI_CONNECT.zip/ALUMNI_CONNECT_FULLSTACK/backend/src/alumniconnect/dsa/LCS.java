package alumniconnect.dsa;

import alumniconnect.model.UserProfile;

import java.util.Locale;

/**
 * 8. LONGEST COMMON SUBSEQUENCE - 2D dynamic programming, plus the weighted
 * profile-similarity score (50% skills + 30% interests + 20% bio). O(m*n).
 */
public final class LCS {
    private LCS() {}

    public record Result(int length, int[][] matrix) {}

    public record Similarity(int overall, int skillsPct, int interestsPct, int bioPct) {}

    public static Result compute(String str1, String str2) {
        str1 = str1 == null ? "" : str1.toLowerCase(Locale.ROOT).trim();
        str2 = str2 == null ? "" : str2.toLowerCase(Locale.ROOT).trim();
        int m = str1.length();
        int n = str2.length();
        if (m == 0 || n == 0) return new Result(0, new int[0][]);

        int[][] dp = new int[m + 1][n + 1];
        for (int i = 1; i <= m; i++) {
            for (int j = 1; j <= n; j++) {
                if (str1.charAt(i - 1) == str2.charAt(j - 1)) {
                    dp[i][j] = dp[i - 1][j - 1] + 1;
                } else {
                    dp[i][j] = Math.max(dp[i - 1][j], dp[i][j - 1]);
                }
            }
        }
        return new Result(dp[m][n], dp);
    }

    /** LCS length divided by the longer (untrimmed) string length; 0 when both are empty. */
    private static double ratio(String a, String b) {
        int lcs = compute(a, b).length();
        int maxLen = Math.max(a.length(), b.length());
        if (maxLen == 0) maxLen = 1;
        return (double) lcs / maxLen;
    }

    private static int pct(double ratio) {
        return Math.min(100, (int) Math.round(ratio * 100));
    }

    public static Similarity similarity(UserProfile a, UserProfile b) {
        if (a == null || b == null) return new Similarity(0, 0, 0, 0);

        double skills = ratio(String.join(" ", a.skills()), String.join(" ", b.skills()));
        double interests = ratio(String.join(" ", a.interests()), String.join(" ", b.interests()));
        double bio = ratio(a.bio(), b.bio());

        double weighted = 0.50 * skills + 0.30 * interests + 0.20 * bio;
        return new Similarity(pct(weighted), pct(skills), pct(interests), pct(bio));
    }

    public static int similarityScore(UserProfile a, UserProfile b) {
        return similarity(a, b).overall();
    }
}
