package alumniconnect.dsa;

import alumniconnect.model.UserProfile;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * High-level search facade (port of DSASearchEngine).
 * Single keyword -> KMP, multiple keywords (or explicit choice) -> Aho-Corasick.
 * Results are collected in our own {@link DynamicArray}.
 */
public final class SearchEngine {
    private SearchEngine() {}

    public static final String ALGO_KMP = "kmp";
    public static final String ALGO_AHO_CORASICK = "aho_corasick";

    /** Which profile fields are searched. A null/all-false instance searches everything. */
    public record SearchFields(boolean name, boolean organization, boolean skills,
                               boolean interests, boolean bio) {
        boolean none() { return !name && !organization && !skills && !interests && !bio; }
    }

    /** organization / graduationYear use "all" (or null) for "no filter". */
    public record Filters(SearchFields searchFields, String organization, String graduationYear) {
        public static Filters none() { return new Filters(null, "all", "all"); }
    }

    public record Match(UserProfile profile, List<String> matchedKeywords) {}

    public record SearchResult(List<Match> data, String algorithm, int comparisons,
                               int itemsScanned, int matchCount, String timeMs) {}

    public static String getSearchableText(UserProfile a, SearchFields f) {
        if (f == null || f.none()) {
            return a.name() + " " + a.organization() + " " + a.college() + " "
                    + String.join(" ", a.skills()) + " " + String.join(" ", a.interests()) + " " + a.bio();
        }
        List<String> parts = new ArrayList<>();
        if (f.name()) parts.add(a.name());
        if (f.organization()) { parts.add(a.organization()); parts.add(a.college()); }
        if (f.skills()) parts.add(String.join(" ", a.skills()));
        if (f.interests()) parts.add(String.join(" ", a.interests()));
        if (f.bio()) parts.add(a.bio());
        return String.join(" ", parts);
    }

    public static SearchResult search(List<UserProfile> list, String query, String algorithmChoice, Filters filters) {
        long start = System.nanoTime();
        if (filters == null) filters = Filters.none();
        String cleanQuery = query == null ? "" : query.toLowerCase(Locale.ROOT).trim();

        DynamicArray<Match> found = new DynamicArray<>();
        int totalComparisons = 0;
        String label = "KMP Pattern Matching";

        if (cleanQuery.isEmpty()) {
            for (UserProfile p : list) found.add(new Match(p, List.of()));
        } else if (ALGO_AHO_CORASICK.equals(algorithmChoice) || cleanQuery.contains(" ")) {
            label = "Aho-Corasick Automaton (Multi-Pattern Queue BFS)";
            List<String> keywords = new ArrayList<>();
            for (String k : cleanQuery.split("\\s+")) if (!k.isEmpty()) keywords.add(k);
            AhoCorasick ac = new AhoCorasick(keywords);

            for (UserProfile p : list) {
                AhoCorasick.Result res = ac.search(getSearchableText(p, filters.searchFields()));
                totalComparisons += res.comparisons();
                if (!res.matches().isEmpty()) {
                    Set<String> unique = new LinkedHashSet<>();
                    for (AhoCorasick.Match m : res.matches()) unique.add(m.pattern());
                    found.add(new Match(p, new ArrayList<>(unique)));
                }
            }
        } else {
            label = "KMP Pattern Matching (LPS Array)";
            for (UserProfile p : list) {
                KMP.Result res = KMP.search(getSearchableText(p, filters.searchFields()), cleanQuery);
                totalComparisons += res.comparisons();
                if (!res.matches().isEmpty()) found.add(new Match(p, List.of(cleanQuery)));
            }
        }

        List<Match> matches = new ArrayList<>();
        for (Match m : found.toList()) {
            if (isSet(filters.organization()) && !filters.organization().equals(m.profile().organization())) continue;
            if (isSet(filters.graduationYear())
                    && !filters.graduationYear().equals(String.valueOf(m.profile().graduationYear()))) continue;
            matches.add(m);
        }

        double ms = (System.nanoTime() - start) / 1_000_000.0;
        return new SearchResult(matches, label, totalComparisons, list.size(), matches.size(),
                String.format(Locale.ROOT, "%.2f", ms));
    }

    private static boolean isSet(String filter) {
        return filter != null && !filter.isEmpty() && !"all".equals(filter);
    }
}
