package alumniconnect.dsa;

import java.util.List;
import java.util.Locale;
import java.util.Optional;

/**
 * 7. EDIT DISTANCE (Levenshtein) - 2D dynamic programming table of size (m+1) x (n+1).
 * Used for "Did you mean ...?" typo suggestions. O(m*n).
 */
public final class EditDistance {
    private EditDistance() {}

    public record Result(int distance, int[][] matrix) {}

    public static Result compute(String str1, String str2) {
        str1 = str1 == null ? "" : str1.toLowerCase(Locale.ROOT).trim();
        str2 = str2 == null ? "" : str2.toLowerCase(Locale.ROOT).trim();
        int m = str1.length();
        int n = str2.length();
        int[][] dp = new int[m + 1][n + 1];

        for (int i = 0; i <= m; i++) dp[i][0] = i;
        for (int j = 0; j <= n; j++) dp[0][j] = j;

        for (int i = 1; i <= m; i++) {
            for (int j = 1; j <= n; j++) {
                if (str1.charAt(i - 1) == str2.charAt(j - 1)) {
                    dp[i][j] = dp[i - 1][j - 1];
                } else {
                    dp[i][j] = 1 + Math.min(dp[i - 1][j],            // deletion
                            Math.min(dp[i][j - 1],                    // insertion
                                     dp[i - 1][j - 1]));              // substitution
                }
            }
        }
        return new Result(dp[m][n], dp);
    }

    /** Closest dictionary word with distance 1..2 (first wins on ties), or empty. Query must be 3+ chars. */
    public static Optional<String> typoSuggestion(String inputQuery, List<String> dictionaryWords) {
        String query = inputQuery == null ? "" : inputQuery.toLowerCase(Locale.ROOT).trim();
        if (query.length() < 3) return Optional.empty();

        String best = null;
        int min = Integer.MAX_VALUE;
        for (String word : dictionaryWords) {
            int dist = compute(query, word).distance();
            if (dist > 0 && dist <= 2 && dist < min) {
                min = dist;
                best = word;
            }
        }
        return Optional.ofNullable(best);
    }
}
