package alumniconnect.dsa;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Function;

/**
 * 9. INSERTION SORT - stable, in-place on a copy. O(n^2) worst case, O(n) when nearly sorted.
 * No Collections.sort / List.sort is used anywhere in the DSA package.
 */
public final class InsertionSort {
    private InsertionSort() {}

    /** Sorts a copy of the list using a comparator. Stable: equal elements keep their order. */
    public static <T> List<T> sort(List<T> input, Comparator<? super T> cmp) {
        List<T> arr = new ArrayList<>(input);
        for (int i = 1; i < arr.size(); i++) {
            T current = arr.get(i);
            int j = i - 1;
            while (j >= 0 && cmp.compare(arr.get(j), current) > 0) {
                arr.set(j + 1, arr.get(j));
                j--;
            }
            arr.set(j + 1, current);
        }
        return arr;
    }

    /**
     * Sorts by an extracted key, matching the original JS insertionSort(array, key, direction):
     * numbers compare numerically, strings compare case-insensitively.
     */
    public static <T> List<T> sortByKey(List<T> input, Function<T, Object> key, boolean ascending) {
        List<T> arr = new ArrayList<>(input);
        for (int i = 1; i < arr.size(); i++) {
            T current = arr.get(i);
            Object valCurrent = key.apply(current);
            int j = i - 1;
            while (j >= 0) {
                int c = compareValues(key.apply(arr.get(j)), valCurrent);
                boolean shift = ascending ? c > 0 : c < 0;
                if (!shift) break;
                arr.set(j + 1, arr.get(j));
                j--;
            }
            arr.set(j + 1, current);
        }
        return arr;
    }

    /** Numbers numerically, strings lower-cased; null or mixed types compare as equal (no move). */
    private static int compareValues(Object a, Object b) {
        if (a instanceof Number x && b instanceof Number y) {
            return Double.compare(x.doubleValue(), y.doubleValue());
        }
        if (a instanceof String x && b instanceof String y) {
            return x.toLowerCase().compareTo(y.toLowerCase());
        }
        return 0;
    }
}
