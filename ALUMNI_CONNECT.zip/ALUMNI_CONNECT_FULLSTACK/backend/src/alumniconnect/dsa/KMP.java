package alumniconnect.dsa;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** 4. KNUTH-MORRIS-PRATT - pattern search using the LPS (failure) array. O(n + m). */
public final class KMP {
    private KMP() {}

    public record Result(List<Integer> matches, int comparisons, int[] lps) {}

    public static int[] computeLPSArray(String pattern) {
        pattern = pattern == null ? "" : pattern.toLowerCase(Locale.ROOT);
        int[] lps = new int[pattern.length()];
        int len = 0;
        int i = 1;
        while (i < pattern.length()) {
            if (pattern.charAt(i) == pattern.charAt(len)) {
                len++;
                lps[i] = len;
                i++;
            } else if (len != 0) {
                len = lps[len - 1];
            } else {
                lps[i] = 0;
                i++;
            }
        }
        return lps;
    }

    public static Result search(String text, String pattern) {
        text = text == null ? "" : text.toLowerCase(Locale.ROOT);
        pattern = pattern == null ? "" : pattern.toLowerCase(Locale.ROOT);

        List<Integer> matches = new ArrayList<>();
        if (pattern.isEmpty()) {
            matches.add(0);
            return new Result(matches, 0, new int[0]);
        }
        int[] lps = computeLPSArray(pattern);
        if (text.length() < pattern.length()) return new Result(matches, 0, lps);

        int comparisons = 0;
        int i = 0; // text index
        int j = 0; // pattern index
        while (i < text.length()) {
            comparisons++;
            if (pattern.charAt(j) == text.charAt(i)) {
                i++;
                j++;
            }
            if (j == pattern.length()) {
                matches.add(i - j);
                j = lps[j - 1];
            } else if (i < text.length() && pattern.charAt(j) != text.charAt(i)) {
                if (j != 0) {
                    j = lps[j - 1];
                } else {
                    i++;
                }
            }
        }
        return new Result(matches, comparisons, lps);
    }
}
