package alumniconnect.dsa;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** 3. NAIVE PATTERN MATCHING - baseline scanner used to compare against KMP. O(n*m). */
public final class NaiveSearch {
    private NaiveSearch() {}

    public record Result(List<Integer> matches, int comparisons) {}

    public static Result search(String text, String pattern) {
        text = text == null ? "" : text.toLowerCase(Locale.ROOT);
        pattern = pattern == null ? "" : pattern.toLowerCase(Locale.ROOT);

        List<Integer> matches = new ArrayList<>();
        if (pattern.isEmpty() || text.length() < pattern.length()) return new Result(matches, 0);

        int comparisons = 0;
        int n = text.length();
        int m = pattern.length();
        for (int i = 0; i <= n - m; i++) {
            int j;
            for (j = 0; j < m; j++) {
                comparisons++;
                if (text.charAt(i + j) != pattern.charAt(j)) break;
            }
            if (j == m) matches.add(i);
        }
        return new Result(matches, comparisons);
    }
}
