package alumniconnect.dsa;

import java.util.List;
import java.util.function.Function;

/** 10. LINEAR SEARCH - scans left to right, counting comparisons. O(n). */
public final class LinearSearch {
    private LinearSearch() {}

    public record Result<T>(boolean found, int index, T item, int comparisons) {}

    /** Case-insensitive match of String.valueOf(key(item)) against String.valueOf(target). */
    public static <T> Result<T> search(List<T> list, Function<T, Object> key, Object target) {
        String wanted = String.valueOf(target).toLowerCase();
        int comparisons = 0;
        for (int i = 0; i < list.size(); i++) {
            comparisons++;
            T item = list.get(i);
            if (String.valueOf(key.apply(item)).toLowerCase().equals(wanted)) {
                return new Result<>(true, i, item, comparisons);
            }
        }
        return new Result<>(false, -1, null, comparisons);
    }
}
