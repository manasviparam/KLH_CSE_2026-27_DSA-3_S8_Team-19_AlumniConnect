package alumniconnect.dsa;

import alumniconnect.model.UserProfile;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * 5. TRIE + DFS - prefix tree for autocomplete. Insert is O(L); suggestions are
 * gathered with a recursive depth-first search from the node that matches the prefix.
 */
public class Trie {
    private final TrieNode root = new TrieNode();

    /** One autocomplete suggestion. */
    public record Suggestion(String word, String type, List<String> alumniIds) {}

    public void insert(String prefixWord, String alumniId, String displayText, String type) {
        if (prefixWord == null) return;
        String clean = prefixWord.toLowerCase(Locale.ROOT).trim();
        if (clean.isEmpty()) return;

        String display = (displayText == null || displayText.isEmpty()) ? prefixWord : displayText;
        String entityType = type == null ? "Suggestion" : type;

        TrieNode curr = root;
        for (int i = 0; i < clean.length(); i++) {
            curr = curr.children.computeIfAbsent(clean.charAt(i), c -> new TrieNode());
        }
        curr.isEndOfWord = true;
        curr.word = clean;
        if (alumniId != null && !alumniId.isEmpty()) curr.alumniIds.add(alumniId);

        // Prevent duplicate entities at the same node (case-insensitive on display text)
        boolean exists = false;
        for (TrieNode.Entity e : curr.entities) {
            if (e.displayText().equalsIgnoreCase(display)) { exists = true; break; }
        }
        if (!exists) curr.entities.add(new TrieNode.Entity(display, entityType, alumniId));
    }

    public void insert(String word) {
        insert(word, null, null, "Suggestion");
    }

    /** Walks the trie along the prefix; returns the final node or null if the prefix is absent. */
    public TrieNode searchPrefixNode(String prefix) {
        String clean = prefix == null ? "" : prefix.toLowerCase(Locale.ROOT).trim();
        TrieNode curr = root;
        for (int i = 0; i < clean.length(); i++) {
            curr = curr.children.get(clean.charAt(i));
            if (curr == null) return null;
        }
        return curr;
    }

    public List<Suggestion> getSuggestions(String prefix) {
        return getSuggestions(prefix, 6);
    }

    /** DFS from the prefix node, then rank: prefix matches first, Alumni before others, shorter first. */
    public List<Suggestion> getSuggestions(String prefix, int maxResults) {
        String cleanPrefix = prefix == null ? "" : prefix.toLowerCase(Locale.ROOT).trim();
        TrieNode node = searchPrefixNode(cleanPrefix);
        if (node == null) return new ArrayList<>();

        Map<String, Suggestion> found = new LinkedHashMap<>();
        dfs(node, found, maxResults * 2);

        List<Suggestion> ranked = InsertionSort.sort(new ArrayList<>(found.values()), (a, b) -> {
            boolean aStarts = a.word().toLowerCase(Locale.ROOT).startsWith(cleanPrefix);
            boolean bStarts = b.word().toLowerCase(Locale.ROOT).startsWith(cleanPrefix);
            if (aStarts && !bStarts) return -1;
            if (!aStarts && bStarts) return 1;
            boolean aAlumni = "Alumni".equals(a.type());
            boolean bAlumni = "Alumni".equals(b.type());
            if (aAlumni && !bAlumni) return -1;
            if (!aAlumni && bAlumni) return 1;
            return a.word().length() - b.word().length();
        });

        return new ArrayList<>(ranked.subList(0, Math.min(maxResults, ranked.size())));
    }

    private void dfs(TrieNode curr, Map<String, Suggestion> found, int cap) {
        if (found.size() >= cap) return;

        for (TrieNode.Entity entity : curr.entities) {
            found.putIfAbsent(entity.displayText().toLowerCase(Locale.ROOT),
                    new Suggestion(entity.displayText(), entity.type(), new ArrayList<>(curr.alumniIds)));
        }
        if (curr.isEndOfWord && !curr.word.isEmpty()) {
            found.putIfAbsent(curr.word.toLowerCase(Locale.ROOT),
                    new Suggestion(curr.word, "Suggestion", new ArrayList<>(curr.alumniIds)));
        }
        for (TrieNode child : curr.orderedChildren()) {
            dfs(child, found, cap);
        }
    }

    /**
     * Indexes names, organizations and skills (full phrase plus each word of 2+ chars).
     * Equivalent of buildGlobalTrie() in the old JS.
     */
    public void addProfiles(List<UserProfile> profiles) {
        for (UserProfile p : profiles) {
            indexPhrase(p.name(), p.userId(), "Alumni");
            indexPhrase(p.organization(), p.userId(), "Organization");
            for (String skill : p.skills()) {
                indexPhrase(skill, p.userId(), "Skill");
            }
        }
    }

    private void indexPhrase(String raw, String userId, String type) {
        String phrase = raw == null ? "" : raw.trim();
        if (phrase.isEmpty()) return;
        insert(phrase, userId, phrase, type);
        for (String w : phrase.split("\\s+")) {
            if (w.length() >= 2) insert(w, userId, phrase, type);
        }
    }

    public static Trie fromProfiles(List<UserProfile> profiles) {
        Trie t = new Trie();
        t.addProfiles(profiles);
        return t;
    }
}
