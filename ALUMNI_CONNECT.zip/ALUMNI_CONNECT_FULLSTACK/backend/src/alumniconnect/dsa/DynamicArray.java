package alumniconnect.dsa;

import java.util.ArrayList;
import java.util.List;

/**
 * 1. DYNAMIC ARRAY - custom resizable array (no java.util.ArrayList used internally).
 * Capacity doubles whenever the array is full. add() is amortised O(1).
 */
public class DynamicArray<T> {
    private Object[] data;
    private int size;

    public DynamicArray() {
        this(10);
    }

    public DynamicArray(int initialCapacity) {
        this.data = new Object[Math.max(1, initialCapacity)];
        this.size = 0;
    }

    public void add(T item) {
        if (size == data.length) {
            resize(data.length * 2);
        }
        data[size++] = item;
    }

    @SuppressWarnings("unchecked")
    public T get(int index) {
        if (index < 0 || index >= size) return null;
        return (T) data[index];
    }

    /** Removes and returns the element at index, shifting later elements left. O(n). */
    @SuppressWarnings("unchecked")
    public T removeAt(int index) {
        if (index < 0 || index >= size) return null;
        T removed = (T) data[index];
        for (int i = index; i < size - 1; i++) {
            data[i] = data[i + 1];
        }
        data[--size] = null;
        return removed;
    }

    private void resize(int newCapacity) {
        Object[] newData = new Object[newCapacity];
        for (int i = 0; i < size; i++) {
            newData[i] = data[i];
        }
        data = newData;
    }

    public int size() { return size; }

    public int capacity() { return data.length; }

    public boolean isEmpty() { return size == 0; }

    @SuppressWarnings("unchecked")
    public List<T> toList() {
        List<T> out = new ArrayList<>(size);
        for (int i = 0; i < size; i++) out.add((T) data[i]);
        return out;
    }
}
