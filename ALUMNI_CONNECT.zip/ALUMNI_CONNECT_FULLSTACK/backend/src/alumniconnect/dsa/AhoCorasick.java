package alumniconnect.dsa;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * 6. AHO-CORASICK - multi-pattern matching automaton. The failure links are built with a
 * breadth-first traversal driven by our own {@link Queue}. Search is O(n + matches).
 */
public class AhoCorasick {

    public record Output(String pattern, int index) {}

    public record Match(String pattern, int index) {}

    public record Result(List<Match> matches, int comparisons) {}

    private static final class Node {
        final Map<Character, Node> children = new LinkedHashMap<>();
        Node fail = null;
        List<Output> output = new ArrayList<>();
    }

    private final Node root = new Node();
    private final List<String> patterns = new ArrayList<>();

    public AhoCorasick(List<String> patterns) {
        for (String p : patterns) {
            String clean = p == null ? "" : p.toLowerCase(Locale.ROOT).trim();
            if (!clean.isEmpty()) this.patterns.add(clean);
        }
        buildTrie();
        buildFailureLinks();
    }

    public List<String> getPatterns() { return List.copyOf(patterns); }

    private void buildTrie() {
        for (int index = 0; index < patterns.size(); index++) {
            String pattern = patterns.get(index);
            Node curr = root;
            for (int i = 0; i < pattern.length(); i++) {
                curr = curr.children.computeIfAbsent(pattern.charAt(i), c -> new Node());
            }
            curr.output.add(new Output(pattern, index));
        }
    }

    /** BFS over the trie using the Queue: level 1, then level 2, and so on. */
    private void buildFailureLinks() {
        Queue<Node> queue = new Queue<>();

        for (Node child : root.children.values()) {
            child.fail = root;
            queue.enqueue(child);
        }

        while (!queue.isEmpty()) {
            Node curr = queue.dequeue();
            for (Map.Entry<Character, Node> e : curr.children.entrySet()) {
                char ch = e.getKey();
                Node child = e.getValue();

                Node fallback = curr.fail;
                while (fallback != null && !fallback.children.containsKey(ch)) {
                    fallback = fallback.fail;
                }
                child.fail = (fallback != null) ? fallback.children.get(ch) : root;

                List<Output> merged = new ArrayList<>(child.output);
                merged.addAll(child.fail.output);
                child.output = merged;

                queue.enqueue(child);
            }
        }
    }

    public Result search(String text) {
        text = text == null ? "" : text.toLowerCase(Locale.ROOT);
        Node curr = root;
        List<Match> matches = new ArrayList<>();
        int comparisons = 0;

        for (int i = 0; i < text.length(); i++) {
            char ch = text.charAt(i);
            comparisons++;

            while (curr != null && !curr.children.containsKey(ch)) {
                curr = curr.fail;
                comparisons++;
            }
            if (curr == null) {
                curr = root;
                continue;
            }

            curr = curr.children.get(ch);
            for (Output out : curr.output) {
                matches.add(new Match(out.pattern(), i - out.pattern().length() + 1));
            }
        }
        return new Result(matches, comparisons);
    }
}
