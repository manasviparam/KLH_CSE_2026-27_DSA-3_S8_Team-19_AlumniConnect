package alumniconnect.dsa;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** A node of the Trie. Stores the entities (name / organization / skill) that end here. */
public class TrieNode {

    /** One thing a word can represent, e.g. ("Aarav Sharma", "Alumni", "user_alumni_101"). */
    public record Entity(String displayText, String type, String alumniId) {}

    final Map<Character, TrieNode> children = new LinkedHashMap<>();
    boolean isEndOfWord = false;
    String word = "";
    final List<Entity> entities = new ArrayList<>();
    final Set<String> alumniIds = new LinkedHashSet<>();

    /**
     * Children in the traversal order of the original JS object: digit keys first
     * (ascending), then the remaining keys in insertion order. Keeps DFS output
     * identical to the previous implementation.
     */
    List<TrieNode> orderedChildren() {
        List<TrieNode> ordered = new ArrayList<>(children.size());
        for (char d = '0'; d <= '9'; d++) {
            TrieNode n = children.get(d);
            if (n != null) ordered.add(n);
        }
        for (Map.Entry<Character, TrieNode> e : children.entrySet()) {
            char c = e.getKey();
            if (c < '0' || c > '9') ordered.add(e.getValue());
        }
        return ordered;
    }
}
