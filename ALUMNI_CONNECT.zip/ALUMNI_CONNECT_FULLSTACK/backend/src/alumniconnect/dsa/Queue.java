package alumniconnect.dsa;

import java.util.ArrayList;
import java.util.List;

/**
 * 2. FIFO QUEUE - singly linked list with head/tail pointers, O(1) enqueue/dequeue.
 * Used by the Aho-Corasick BFS failure-link construction (and later graph code).
 */
public class Queue<T> {
    private static final class Node<T> {
        final T value;
        Node<T> next;
        Node(T value) { this.value = value; }
    }

    private Node<T> head;
    private Node<T> tail;
    private int size;

    public void enqueue(T element) {
        Node<T> node = new Node<>(element);
        if (tail == null) {
            head = tail = node;
        } else {
            tail.next = node;
            tail = node;
        }
        size++;
    }

    /** Removes and returns the front element, or null if empty. */
    public T dequeue() {
        if (head == null) return null;
        T value = head.value;
        head = head.next;
        if (head == null) tail = null;
        size--;
        return value;
    }

    /** Returns the front element without removing it, or null if empty. */
    public T front() {
        return head == null ? null : head.value;
    }

    public boolean isEmpty() { return size == 0; }

    public int size() { return size; }

    public List<T> toList() {
        List<T> out = new ArrayList<>(size);
        for (Node<T> n = head; n != null; n = n.next) out.add(n.value);
        return out;
    }
}
