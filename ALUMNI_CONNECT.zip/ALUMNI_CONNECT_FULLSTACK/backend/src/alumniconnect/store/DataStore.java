package alumniconnect.store;

import alumniconnect.dsa.Trie;
import alumniconnect.model.Connection;
import alumniconnect.model.Person;
import alumniconnect.model.UserProfile;
import alumniconnect.server.ApiRequest;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * In-memory copy of the data the frontend keeps in localStorage.
 * The browser pushes a snapshot with POST /api/sync; every algorithm then runs on this snapshot.
 */
public final class DataStore {
    private List<UserProfile> alumni = List.of();
    private List<Person> people = List.of();
    private List<Connection> connections = List.of();
    private Trie searchTrie = new Trie();
    private Trie demoTrie = new Trie();
    private long version = 0;

    @SuppressWarnings("unchecked")
    public synchronized void sync(Map<String, Object> body) {
        List<UserProfile> newAlumni = new ArrayList<>();
        List<Person> newPeople = new ArrayList<>();
        List<Connection> newConnections = new ArrayList<>();

        if (body.get("alumni") instanceof List<?> list) {
            for (Object o : list) {
                if (!(o instanceof Map<?, ?>)) continue;
                Map<String, Object> m = (Map<String, Object>) o;
                String id = ApiRequest.str(m, "userId", ApiRequest.str(m, "id", ""));
                if (id.isEmpty()) continue;
                newAlumni.add(new UserProfile(id, ApiRequest.str(m, "name", ""), ApiRequest.str(m, "organization", ""),
                        ApiRequest.str(m, "college", ""), ApiRequest.integer(m, "graduationYear", 0),
                        ApiRequest.strings(m, "skills"), ApiRequest.strings(m, "interests"), ApiRequest.str(m, "bio", "")));
                newPeople.add(person(m, id, "alumni"));
            }
        }
        if (body.get("students") instanceof List<?> list) {
            for (Object o : list) {
                if (!(o instanceof Map<?, ?>)) continue;
                Map<String, Object> m = (Map<String, Object>) o;
                String id = ApiRequest.str(m, "userId", ApiRequest.str(m, "id", ""));
                if (!id.isEmpty()) newPeople.add(person(m, id, "student"));
            }
        }
        if (body.get("connections") instanceof List<?> list) {
            for (Object o : list) {
                if (!(o instanceof Map<?, ?>)) continue;
                Map<String, Object> m = (Map<String, Object>) o;
                newConnections.add(new Connection(ApiRequest.str(m, "id", ""), ApiRequest.str(m, "studentId", ""),
                        ApiRequest.str(m, "alumniId", ""), ApiRequest.str(m, "status", "")));
            }
        }

        alumni = List.copyOf(newAlumni);
        people = List.copyOf(newPeople);
        connections = List.copyOf(newConnections);
        searchTrie = Trie.fromProfiles(alumni);
        demoTrie = Trie.fromProfiles(alumni);
        version++;
    }

    private static Person person(Map<String, Object> m, String id, String role) {
        return new Person(id, ApiRequest.str(m, "name", ""), role, ApiRequest.str(m, "college", ""),
                ApiRequest.integer(m, "graduationYear", 0), ApiRequest.str(m, "organization", ""),
                ApiRequest.str(m, "department", ""), ApiRequest.str(m, "industry", ""),
                ApiRequest.strings(m, "skills"), ApiRequest.strings(m, "interests"), ApiRequest.str(m, "bio", ""));
    }

    public synchronized List<UserProfile> alumni() { return alumni; }

    public synchronized List<Person> people() { return people; }

    public synchronized List<Person> peopleWithRole(String role) {
        List<Person> out = new ArrayList<>();
        for (Person p : people) if (p.role().equalsIgnoreCase(role)) out.add(p);
        return out;
    }

    public synchronized List<Connection> connections() { return connections; }

    public synchronized Trie searchTrie() { return searchTrie; }

    public synchronized Trie demoTrie() { return demoTrie; }

    public synchronized long version() { return version; }
}
