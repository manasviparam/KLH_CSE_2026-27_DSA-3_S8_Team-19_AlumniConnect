package alumniconnect.server;

public class ApiException extends RuntimeException {
    private static final long serialVersionUID = 1L;
    public final int status;

    public ApiException(int status, String message) {
        super(message);
        this.status = status;
    }

    public static ApiException badRequest(String message) { return new ApiException(400, message); }

    public static ApiException notFound(String message) { return new ApiException(404, message); }
}
