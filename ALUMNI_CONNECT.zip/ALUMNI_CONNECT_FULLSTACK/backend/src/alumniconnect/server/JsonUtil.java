package alumniconnect.server;

import java.lang.reflect.Array;
import java.lang.reflect.RecordComponent;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Tiny JSON reader/writer (no external libraries).
 * parse  -> Map / List / String / Double|Long / Boolean / null
 * stringify -> accepts Map, Collection, arrays, records, String, Number, Boolean, null.
 * Records are written using their component names, so handlers can return records directly.
 */
public final class JsonUtil {
    private JsonUtil() {}

    // ------------------------------------------------------------ parsing
    public static Object parse(String json) {
        Parser p = new Parser(json);
        p.skipWs();
        Object v = p.value();
        p.skipWs();
        if (p.i != json.length()) throw p.error("Unexpected trailing characters");
        return v;
    }

    private static final class Parser {
        final String s;
        int i = 0;

        Parser(String s) { this.s = s; }

        IllegalArgumentException error(String msg) {
            return new IllegalArgumentException("Invalid JSON at position " + i + ": " + msg);
        }

        void skipWs() {
            while (i < s.length() && Character.isWhitespace(s.charAt(i))) i++;
        }

        Object value() {
            if (i >= s.length()) throw error("Unexpected end of input");
            char c = s.charAt(i);
            switch (c) {
                case '{': return object();
                case '[': return array();
                case '"': return string();
                case 't': expect("true"); return Boolean.TRUE;
                case 'f': expect("false"); return Boolean.FALSE;
                case 'n': expect("null"); return null;
                default:
                    if (c == '-' || (c >= '0' && c <= '9')) return number();
                    throw error("Unexpected character '" + c + "'");
            }
        }

        void expect(String lit) {
            if (!s.startsWith(lit, i)) throw error("Expected " + lit);
            i += lit.length();
        }

        Map<String, Object> object() {
            Map<String, Object> m = new LinkedHashMap<>();
            i++; skipWs();
            if (i < s.length() && s.charAt(i) == '}') { i++; return m; }
            while (true) {
                skipWs();
                if (i >= s.length() || s.charAt(i) != '"') throw error("Expected string key");
                String k = string();
                skipWs();
                if (i >= s.length() || s.charAt(i) != ':') throw error("Expected ':'");
                i++; skipWs();
                m.put(k, value());
                skipWs();
                if (i >= s.length()) throw error("Unterminated object");
                char c = s.charAt(i++);
                if (c == '}') return m;
                if (c != ',') throw error("Expected ',' or '}'");
            }
        }

        List<Object> array() {
            List<Object> l = new ArrayList<>();
            i++; skipWs();
            if (i < s.length() && s.charAt(i) == ']') { i++; return l; }
            while (true) {
                skipWs();
                l.add(value());
                skipWs();
                if (i >= s.length()) throw error("Unterminated array");
                char c = s.charAt(i++);
                if (c == ']') return l;
                if (c != ',') throw error("Expected ',' or ']'");
            }
        }

        String string() {
            StringBuilder sb = new StringBuilder();
            i++; // opening quote
            while (i < s.length()) {
                char c = s.charAt(i++);
                if (c == '"') return sb.toString();
                if (c == '\\') {
                    if (i >= s.length()) break;
                    char e = s.charAt(i++);
                    switch (e) {
                        case '"': sb.append('"'); break;
                        case '\\': sb.append('\\'); break;
                        case '/': sb.append('/'); break;
                        case 'b': sb.append('\b'); break;
                        case 'f': sb.append('\f'); break;
                        case 'n': sb.append('\n'); break;
                        case 'r': sb.append('\r'); break;
                        case 't': sb.append('\t'); break;
                        case 'u':
                            if (i + 4 > s.length()) throw error("Bad unicode escape");
                            sb.append((char) Integer.parseInt(s.substring(i, i + 4), 16));
                            i += 4;
                            break;
                        default: throw error("Bad escape \\" + e);
                    }
                } else {
                    sb.append(c);
                }
            }
            throw error("Unterminated string");
        }

        Object number() {
            int start = i;
            if (s.charAt(i) == '-') i++;
            while (i < s.length() && Character.isDigit(s.charAt(i))) i++;
            boolean isDouble = false;
            if (i < s.length() && s.charAt(i) == '.') {
                isDouble = true; i++;
                while (i < s.length() && Character.isDigit(s.charAt(i))) i++;
            }
            if (i < s.length() && (s.charAt(i) == 'e' || s.charAt(i) == 'E')) {
                isDouble = true; i++;
                if (i < s.length() && (s.charAt(i) == '+' || s.charAt(i) == '-')) i++;
                while (i < s.length() && Character.isDigit(s.charAt(i))) i++;
            }
            String num = s.substring(start, i);
            try {
                return isDouble ? (Object) Double.parseDouble(num) : (Object) Long.parseLong(num);
            } catch (NumberFormatException ex) {
                throw error("Bad number " + num);
            }
        }
    }

    // ------------------------------------------------------------ writing
    public static String stringify(Object o) {
        StringBuilder sb = new StringBuilder();
        write(sb, o);
        return sb.toString();
    }

    private static void write(StringBuilder sb, Object o) {
        if (o == null) { sb.append("null"); return; }
        if (o instanceof String s) { quote(sb, s); return; }
        if (o instanceof Boolean || o instanceof Integer || o instanceof Long || o instanceof Short || o instanceof Byte) {
            sb.append(o); return;
        }
        if (o instanceof Number n) { number(sb, n.doubleValue()); return; }
        if (o instanceof Character c) { quote(sb, String.valueOf(c)); return; }
        if (o instanceof Map<?, ?> m) {
            sb.append('{');
            boolean first = true;
            for (Map.Entry<?, ?> e : m.entrySet()) {
                if (!first) sb.append(',');
                first = false;
                quote(sb, String.valueOf(e.getKey()));
                sb.append(':');
                write(sb, e.getValue());
            }
            sb.append('}');
            return;
        }
        if (o instanceof Collection<?> c) {
            sb.append('[');
            boolean first = true;
            for (Object x : c) {
                if (!first) sb.append(',');
                first = false;
                write(sb, x);
            }
            sb.append(']');
            return;
        }
        if (o.getClass().isArray()) {
            sb.append('[');
            int n = Array.getLength(o);
            for (int k = 0; k < n; k++) {
                if (k > 0) sb.append(',');
                write(sb, Array.get(o, k));
            }
            sb.append(']');
            return;
        }
        if (o.getClass().isRecord()) {
            sb.append('{');
            RecordComponent[] comps = o.getClass().getRecordComponents();
            for (int k = 0; k < comps.length; k++) {
                if (k > 0) sb.append(',');
                quote(sb, comps[k].getName());
                sb.append(':');
                try {
                    var accessor = comps[k].getAccessor();
                    accessor.setAccessible(true);
                    write(sb, accessor.invoke(o));
                } catch (ReflectiveOperationException ex) {
                    throw new IllegalStateException("Cannot serialise " + o.getClass(), ex);
                }
            }
            sb.append('}');
            return;
        }
        quote(sb, String.valueOf(o));
    }

    /** Doubles are rounded to 4 decimals; NaN / Infinity become null (used for "no path"). */
    private static void number(StringBuilder sb, double d) {
        if (Double.isNaN(d) || Double.isInfinite(d)) { sb.append("null"); return; }
        double r = Math.round(d * 10000.0) / 10000.0;
        if (r == Math.rint(r) && Math.abs(r) < 1e15) sb.append((long) r);
        else sb.append(r);
    }

    private static void quote(StringBuilder sb, String s) {
        sb.append('"');
        for (int k = 0; k < s.length(); k++) {
            char c = s.charAt(k);
            switch (c) {
                case '"': sb.append("\\\""); break;
                case '\\': sb.append("\\\\"); break;
                case '\n': sb.append("\\n"); break;
                case '\r': sb.append("\\r"); break;
                case '\t': sb.append("\\t"); break;
                case '\b': sb.append("\\b"); break;
                case '\f': sb.append("\\f"); break;
                default:
                    if (c < 0x20) sb.append(String.format("\\u%04x", (int) c));
                    else sb.append(c);
            }
        }
        sb.append('"');
    }
}
