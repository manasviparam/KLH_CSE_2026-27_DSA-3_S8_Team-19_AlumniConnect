package alumniconnect.server.handlers;

import alumniconnect.dsa.InsertionSort;
import alumniconnect.dsa.LCS;
import alumniconnect.model.UserProfile;
import alumniconnect.server.ApiException;
import alumniconnect.server.ApiServer;
import alumniconnect.store.DataStore;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** GET /api/similar?id=...&limit=3 - LCS dynamic-programming similarity, ranked with Insertion Sort. */
public final class SimilarityHandler {
    private SimilarityHandler() {}

    public static void register(ApiServer api, DataStore store) {
        api.route("GET", "/api/similar", r -> {
            String id = r.requireParam("id");
            int limit = Math.max(1, Math.min(r.intParam("limit", 3), 20));

            UserProfile target = null;
            for (UserProfile p : store.alumni()) if (p.userId().equals(id)) target = p;
            if (target == null) throw ApiException.notFound("Alumni not found: " + id);

            List<Map<String, Object>> scored = new ArrayList<>();
            for (UserProfile other : store.alumni()) {
                if (other.userId().equals(id)) continue;
                LCS.Similarity s = LCS.similarity(target, other);
                Map<String, Object> m = SearchHandler.profileJson(other, null);
                m.put("similarityPct", s.overall());
                m.put("skillsPct", s.skillsPct());
                m.put("interestsPct", s.interestsPct());
                m.put("bioPct", s.bioPct());
                scored.add(m);
            }
            List<Map<String, Object>> ranked = InsertionSort.sortByKey(scored, m -> m.get("similarityPct"), false);
            Map<String, Object> out = new LinkedHashMap<>();
            out.put("similar", new ArrayList<>(ranked.subList(0, Math.min(limit, ranked.size()))));
            return out;
        });
    }
}
