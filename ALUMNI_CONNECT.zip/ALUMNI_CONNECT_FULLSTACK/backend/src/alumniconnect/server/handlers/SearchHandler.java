package alumniconnect.server.handlers;

import alumniconnect.dsa.EditDistance;
import alumniconnect.dsa.InsertionSort;
import alumniconnect.dsa.SearchEngine;
import alumniconnect.dsa.Trie;
import alumniconnect.model.UserProfile;
import alumniconnect.server.ApiRequest;
import alumniconnect.server.ApiServer;
import alumniconnect.store.DataStore;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;

/** Directory features: search (KMP / Aho-Corasick + Insertion Sort), Trie autocomplete, typo hints. */
public final class SearchHandler {
    private SearchHandler() {}

    public static void register(ApiServer api, DataStore store) {

        // GET /api/suggest?q=jav&max=6  -> Trie + DFS
        api.route("GET", "/api/suggest", r -> {
            int max = Math.max(1, Math.min(r.intParam("max", 6), 50));
            Map<String, Object> out = new LinkedHashMap<>();
            out.put("suggestions", store.searchTrie().getSuggestions(r.param("q") == null ? "" : r.param("q"), max));
            return out;
        });

        // GET /api/typo?q=javscript  -> Edit Distance
        api.route("GET", "/api/typo", r -> {
            String q = r.param("q") == null ? "" : r.param("q").trim();
            List<String> dictionary = dictionary(store.alumni());
            String suggestion = EditDistance.typoSuggestion(q, dictionary).orElse(null);
            if (suggestion != null && suggestion.equalsIgnoreCase(q)) suggestion = null;
            Map<String, Object> out = new LinkedHashMap<>();
            out.put("suggestion", suggestion);
            return out;
        });

        // POST /api/search {query, algorithm, organization, graduationYear, searchFields, sortKey, sortDir}
        api.route("POST", "/api/search", r -> {
            Map<String, Object> body = r.bodyMap();
            SearchEngine.SearchFields fields = null;
            if (body.get("searchFields") instanceof Map<?, ?>) {
                @SuppressWarnings("unchecked") Map<String, Object> f = (Map<String, Object>) body.get("searchFields");
                fields = new SearchEngine.SearchFields(ApiRequest.bool(f, "name", true), ApiRequest.bool(f, "organization", true),
                        ApiRequest.bool(f, "skills", true), ApiRequest.bool(f, "interests", true), ApiRequest.bool(f, "bio", true));
            }
            SearchEngine.Filters filters = new SearchEngine.Filters(fields,
                    ApiRequest.str(body, "organization", "all"), ApiRequest.str(body, "graduationYear", "all"));

            SearchEngine.SearchResult res = SearchEngine.search(store.alumni(), ApiRequest.str(body, "query", ""),
                    ApiRequest.str(body, "algorithm", SearchEngine.ALGO_KMP), filters);

            // Insertion Sort on the matches
            List<SearchEngine.Match> sorted = res.data();
            Function<SearchEngine.Match, Object> key = sortKey(ApiRequest.str(body, "sortKey", ""));
            if (key != null) sorted = InsertionSort.sortByKey(sorted, key, !"desc".equalsIgnoreCase(ApiRequest.str(body, "sortDir", "asc")));

            List<Object> data = new ArrayList<>();
            for (SearchEngine.Match m : sorted) data.add(profileJson(m.profile(), m.matchedKeywords()));

            Map<String, Object> out = new LinkedHashMap<>();
            out.put("data", data);
            out.put("algorithm", res.algorithm());
            out.put("comparisons", res.comparisons());
            out.put("itemsScanned", res.itemsScanned());
            out.put("matchCount", res.matchCount());
            out.put("timeMs", res.timeMs());
            return out;
        });
    }

    static Map<String, Object> profileJson(UserProfile p, List<String> matchedKeywords) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("userId", p.userId());
        m.put("name", p.name());
        m.put("organization", p.organization());
        m.put("college", p.college());
        m.put("graduationYear", p.graduationYear());
        m.put("skills", p.skills());
        m.put("interests", p.interests());
        m.put("bio", p.bio());
        if (matchedKeywords != null) m.put("matchedKeywords", matchedKeywords);
        return m;
    }

    private static Function<SearchEngine.Match, Object> sortKey(String key) {
        return switch (key) {
            case "graduationYear" -> m -> m.profile().graduationYear();
            case "name" -> m -> m.profile().name();
            case "organization" -> m -> m.profile().organization();
            default -> null;
        };
    }

    /** Words offered to the typo checker: name words, organizations and skills (lower-case). */
    private static List<String> dictionary(List<UserProfile> alumni) {
        Set<String> words = new LinkedHashSet<>();
        for (UserProfile a : alumni) {
            for (String w : a.name().split("\\s+")) if (!w.isEmpty()) words.add(w.toLowerCase(Locale.ROOT));
            if (!a.organization().isEmpty()) words.add(a.organization().toLowerCase(Locale.ROOT));
            for (String s : a.skills()) words.add(s.toLowerCase(Locale.ROOT));
        }
        return new ArrayList<>(words);
    }
}
