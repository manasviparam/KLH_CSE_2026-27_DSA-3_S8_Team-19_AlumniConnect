package alumniconnect.server.handlers;

import alumniconnect.graph.BipartiteMatching;
import alumniconnect.graph.Dijkstra;
import alumniconnect.graph.FloydWarshall;
import alumniconnect.graph.Recommender;
import alumniconnect.graph.SocialGraph;
import alumniconnect.model.Person;
import alumniconnect.server.ApiServer;
import alumniconnect.store.DataStore;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Graph features:
 *   GET /api/graph/path?from=&to=          Dijkstra         - Best Connection Path
 *   GET /api/graph/network                 Floyd-Warshall   - Overall Network Analysis
 *   GET /api/graph/recommend?userId=&limit=  People You May Know (mutual accepted connections)
 *   GET /api/graph/mentor-match?capacity=  Bipartite match  - Alumni Mentor Matching
 *   GET /api/graph/people                  user list for dropdowns
 */
public final class GraphHandler {
    private GraphHandler() {}

    private static long cachedVersion = -1;
    private static SocialGraph cachedGraph;

    private static synchronized SocialGraph graph(DataStore store) {
        long v = store.version();
        if (cachedGraph == null || cachedVersion != v) {
            cachedGraph = new SocialGraph(store.people(), store.connections());
            cachedVersion = v;
        }
        return cachedGraph;
    }

    public static void register(ApiServer api, DataStore store) {

        api.route("GET", "/api/graph/people", r -> {
            List<Object> list = new ArrayList<>();
            for (Person p : store.people()) {
                Map<String, Object> m = new LinkedHashMap<>();
                m.put("id", p.id());
                m.put("name", p.name());
                m.put("role", p.role());
                m.put("organization", p.organization());
                list.add(m);
            }
            return Map.of("people", list);
        });

        api.route("GET", "/api/graph/path", r ->
                Dijkstra.shortestPath(graph(store), r.requireParam("from"), r.requireParam("to")));

        api.route("GET", "/api/graph/network", r -> {
            SocialGraph g = graph(store);
            Map<String, Object> out = new LinkedHashMap<>();
            out.put("analysis", FloydWarshall.analyse(g));
            return out;
        });

        api.route("GET", "/api/graph/recommend", r -> Recommender.recommend(
                graph(store), store.connections(), r.requireParam("userId"), r.intParam("limit", 5)));

        api.route("GET", "/api/graph/mentor-match", r -> BipartiteMatching.match(
                store.peopleWithRole("student"), store.peopleWithRole("alumni"), r.intParam("capacity", 1)));
    }
}
