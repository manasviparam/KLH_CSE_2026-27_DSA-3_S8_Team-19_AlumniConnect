package alumniconnect.server.handlers;

import alumniconnect.server.ApiServer;
import alumniconnect.store.DataStore;

import java.util.LinkedHashMap;
import java.util.Map;

/** POST /api/sync - browser pushes its localStorage snapshot; GET /api/health - liveness check. */
public final class SyncHandler {
    private SyncHandler() {}

    public static void register(ApiServer api, DataStore store) {
        api.route("GET", "/api/health", r -> Map.of("status", "ok", "service", "AlumniConnect Java backend"));

        api.route("POST", "/api/sync", r -> {
            store.sync(r.bodyMap());
            Map<String, Object> out = new LinkedHashMap<>();
            out.put("synced", true);
            out.put("alumni", store.alumni().size());
            out.put("students", store.peopleWithRole("student").size());
            out.put("connections", store.connections().size());
            return out;
        });
    }
}
