package alumniconnect.server.handlers;

import alumniconnect.dsa.AhoCorasick;
import alumniconnect.dsa.DynamicArray;
import alumniconnect.dsa.EditDistance;
import alumniconnect.dsa.InsertionSort;
import alumniconnect.dsa.KMP;
import alumniconnect.dsa.LCS;
import alumniconnect.dsa.LinearSearch;
import alumniconnect.dsa.NaiveSearch;
import alumniconnect.dsa.Queue;
import alumniconnect.model.UserProfile;
import alumniconnect.server.ApiRequest;
import alumniconnect.server.ApiServer;
import alumniconnect.store.DataStore;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/** Endpoints behind the interactive demos on dsa/how-it-works.html. Every call runs the Java algorithm. */
public final class DsaDemoHandler {
    private DsaDemoHandler() {}

    private static DynamicArray<String> dynamicDemo = freshDynamic();
    private static final Queue<String> queueState = freshQueue();

    private static DynamicArray<String> freshDynamic() {
        DynamicArray<String> a = new DynamicArray<>(4);
        for (String s : new String[]{"Google", "Microsoft", "Amazon", "Apple"}) a.add(s);
        return a;
    }

    private static Queue<String> freshQueue() {
        Queue<String> q = new Queue<>();
        for (String s : new String[]{"Task_1", "Task_2", "Task_3"}) q.enqueue(s);
        return q;
    }

    public static void register(ApiServer api, DataStore store) {

        api.route("POST", "/api/dsa/kmp", r -> {
            Map<String, Object> b = r.bodyMap();
            KMP.Result res = KMP.search(ApiRequest.str(b, "text", ""), ApiRequest.str(b, "pattern", ""));
            Map<String, Object> out = new LinkedHashMap<>();
            out.put("matches", res.matches());
            out.put("comparisons", res.comparisons());
            out.put("lps", res.lps());
            return out;
        });

        api.route("POST", "/api/dsa/naive", r -> {
            Map<String, Object> b = r.bodyMap();
            NaiveSearch.Result res = NaiveSearch.search(ApiRequest.str(b, "text", ""), ApiRequest.str(b, "pattern", ""));
            Map<String, Object> out = new LinkedHashMap<>();
            out.put("matches", res.matches());
            out.put("comparisons", res.comparisons());
            return out;
        });

        api.route("POST", "/api/dsa/trie/insert", r -> {
            String word = ApiRequest.str(r.bodyMap(), "word", "").trim();
            if (!word.isEmpty()) store.demoTrie().insert(word);
            return Map.of("added", !word.isEmpty(), "word", word);
        });

        api.route("POST", "/api/dsa/trie/suggest", r -> {
            Map<String, Object> b = r.bodyMap();
            String prefix = ApiRequest.str(b, "prefix", "");
            Map<String, Object> out = new LinkedHashMap<>();
            out.put("suggestions", store.demoTrie().getSuggestions(prefix, ApiRequest.integer(b, "max", 10)));
            return out;
        });

        api.route("POST", "/api/dsa/ahocorasick", r -> {
            Map<String, Object> b = r.bodyMap();
            List<String> keywords = ApiRequest.strings(b, "keywords");
            AhoCorasick.Result res = new AhoCorasick(keywords).search(ApiRequest.str(b, "text", ""));
            Set<String> found = new LinkedHashSet<>();
            for (AhoCorasick.Match m : res.matches()) found.add(m.pattern());
            Map<String, Object> out = new LinkedHashMap<>();
            out.put("matches", res.matches());
            out.put("foundPatterns", found);
            out.put("comparisons", res.comparisons());
            return out;
        });

        api.route("POST", "/api/dsa/edit", r -> {
            Map<String, Object> b = r.bodyMap();
            EditDistance.Result res = EditDistance.compute(ApiRequest.str(b, "a", ""), ApiRequest.str(b, "b", ""));
            Map<String, Object> out = new LinkedHashMap<>();
            out.put("distance", res.distance());
            out.put("matrix", res.matrix());
            return out;
        });

        api.route("POST", "/api/dsa/lcs", r -> {
            Map<String, Object> b = r.bodyMap();
            String a = ApiRequest.str(b, "a", "").trim(), c = ApiRequest.str(b, "b", "").trim();
            LCS.Result res = LCS.compute(a, c);
            int pct = (int) Math.round((double) res.length() / Math.max(a.length(), c.isEmpty() ? 1 : c.length()) * 100);

            UserProfile pa = new UserProfile("a", "", "", "", 0, Arrays.asList(a.split("\\s+")), List.of("Mentorship"), a);
            UserProfile pb = new UserProfile("b", "", "", "", 0, Arrays.asList(c.split("\\s+")), List.of("Career Guidance"), c);
            Map<String, Object> out = new LinkedHashMap<>();
            out.put("length", res.length());
            out.put("similarityPct", pct);
            out.put("details", LCS.similarity(pa, pb));
            return out;
        });

        api.route("POST", "/api/dsa/sort", r -> {
            List<Object> nums = new ArrayList<>();
            if (r.bodyMap().get("numbers") instanceof List<?> l) for (Object o : l) if (o instanceof Number) nums.add(o);
            Map<String, Object> out = new LinkedHashMap<>();
            out.put("original", nums);
            out.put("sorted", InsertionSort.sortByKey(nums, x -> x, true));
            return out;
        });

        api.route("POST", "/api/dsa/linear", r -> {
            Map<String, Object> b = r.bodyMap();
            LinearSearch.Result<String> res = LinearSearch.search(ApiRequest.strings(b, "items"), s -> s, ApiRequest.str(b, "target", ""));
            Map<String, Object> out = new LinkedHashMap<>();
            out.put("found", res.found());
            out.put("index", res.index());
            out.put("comparisons", res.comparisons());
            return out;
        });

        // Stateful demos: Dynamic Array and Queue live on the server
        api.route("POST", "/api/dsa/dynamic", r -> {
            synchronized (DsaDemoHandler.class) {
                Map<String, Object> b = r.bodyMap();
                switch (ApiRequest.str(b, "op", "state")) {
                    case "add" -> {
                        String v = ApiRequest.str(b, "value", "").trim();
                        dynamicDemo.add(v.isEmpty() ? "Item_" + (dynamicDemo.size() + 1) : v);
                    }
                    case "pop" -> { if (dynamicDemo.size() > 0) dynamicDemo.removeAt(dynamicDemo.size() - 1); }
                    case "reset" -> dynamicDemo = new DynamicArray<>(4);
                    default -> { }
                }
                Map<String, Object> out = new LinkedHashMap<>();
                out.put("size", dynamicDemo.size());
                out.put("capacity", dynamicDemo.capacity());
                out.put("elements", dynamicDemo.toList());
                return out;
            }
        });

        api.route("POST", "/api/dsa/queue", r -> {
            synchronized (DsaDemoHandler.class) {
                Map<String, Object> b = r.bodyMap();
                switch (ApiRequest.str(b, "op", "state")) {
                    case "enqueue" -> {
                        String v = ApiRequest.str(b, "value", "").trim();
                        queueState.enqueue(v.isEmpty() ? "Task_" + (queueState.size() + 1) : v);
                    }
                    case "dequeue" -> queueState.dequeue();
                    default -> { }
                }
                Map<String, Object> out = new LinkedHashMap<>();
                out.put("items", queueState.toList());
                out.put("front", queueState.front());
                return out;
            }
        });
    }
}
