package alumniconnect.server;

import java.util.List;
import java.util.Map;

/** Parsed incoming API call: method, path, query-string params and (optional) JSON body. */
public record ApiRequest(String method, String path, Map<String, String> query, Object body) {

    public String param(String name) { return query.get(name); }

    public String requireParam(String name) {
        String v = query.get(name);
        if (v == null || v.isEmpty()) throw ApiException.badRequest("Missing query parameter: " + name);
        return v;
    }

    public int intParam(String name, int fallback) {
        String v = query.get(name);
        if (v == null || v.isEmpty()) return fallback;
        try { return Integer.parseInt(v.trim()); }
        catch (NumberFormatException e) { throw ApiException.badRequest("Parameter " + name + " must be an integer"); }
    }

    @SuppressWarnings("unchecked")
    public Map<String, Object> bodyMap() {
        if (body instanceof Map<?, ?> m) return (Map<String, Object>) m;
        throw ApiException.badRequest("Expected a JSON object in the request body");
    }

    // ---- small typed accessors for JSON bodies ----
    public static String str(Map<String, Object> m, String key, String fallback) {
        Object v = m.get(key);
        return v == null ? fallback : String.valueOf(v);
    }

    public static int integer(Map<String, Object> m, String key, int fallback) {
        Object v = m.get(key);
        if (v instanceof Number n) return n.intValue();
        if (v instanceof String s) { try { return Integer.parseInt(s.trim()); } catch (NumberFormatException e) { return fallback; } }
        return fallback;
    }

    public static boolean bool(Map<String, Object> m, String key, boolean fallback) {
        Object v = m.get(key);
        return v instanceof Boolean b ? b : fallback;
    }

    public static List<String> strings(Map<String, Object> m, String key) {
        Object v = m.get(key);
        List<String> out = new java.util.ArrayList<>();
        if (v instanceof List<?> l) for (Object o : l) if (o != null) out.add(String.valueOf(o));
        return out;
    }
}
