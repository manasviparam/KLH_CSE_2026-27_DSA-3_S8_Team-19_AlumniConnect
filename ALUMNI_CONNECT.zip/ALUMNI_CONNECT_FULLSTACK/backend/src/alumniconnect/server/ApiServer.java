package alumniconnect.server;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.Executors;

/**
 * HTTP layer (JDK built-in com.sun.net.httpserver, no frameworks).
 *   /api/...  -> JSON API routed to registered handlers
 *   anything else -> static files of the existing HTML/CSS/JS frontend
 */
public final class ApiServer {

    @FunctionalInterface
    public interface Handler {
        Object handle(ApiRequest request) throws Exception;
    }

    private final Map<String, Handler> routes = new LinkedHashMap<>();
    private final Path webRoot;
    private final int port;
    private HttpServer server;

    public ApiServer(int port, Path webRoot) {
        this.port = port;
        this.webRoot = webRoot.toAbsolutePath().normalize();
    }

    public void route(String method, String path, Handler handler) {
        routes.put(method + " " + path, handler);
    }

    public void start() throws IOException {
        server = HttpServer.create(new InetSocketAddress(port), 0);
        server.createContext("/", this::dispatch);
        server.setExecutor(Executors.newFixedThreadPool(8));
        server.start();
    }

    // ------------------------------------------------------------------ dispatch
    private void dispatch(HttpExchange ex) throws IOException {
        try {
            addCors(ex);
            String method = ex.getRequestMethod().toUpperCase();
            if (method.equals("OPTIONS")) { send(ex, 204, "text/plain", new byte[0]); return; }

            String path = ex.getRequestURI().getPath();
            if (path.startsWith("/api/")) handleApi(ex, method, path);
            else handleStatic(ex, method, path);
        } catch (Throwable t) {
            t.printStackTrace();
            try { sendJson(ex, 500, Map.of("error", "Internal server error: " + t.getMessage())); } catch (Exception ignored) {}
        } finally {
            ex.close();
        }
    }

    private void handleApi(HttpExchange ex, String method, String path) throws IOException {
        Handler h = routes.get(method + " " + path);
        if (h == null) {
            boolean pathKnown = routes.keySet().stream().anyMatch(k -> k.endsWith(" " + path));
            sendJson(ex, pathKnown ? 405 : 404, Map.of("error", pathKnown ? "Method not allowed" : "Unknown API route: " + path));
            return;
        }
        try {
            Object body = null;
            if (method.equals("POST") || method.equals("PUT")) {
                String raw = new String(readAll(ex.getRequestBody()), StandardCharsets.UTF_8);
                if (!raw.isBlank()) body = JsonUtil.parse(raw);
            }
            ApiRequest req = new ApiRequest(method, path, parseQuery(ex.getRequestURI().getRawQuery()), body);
            sendJson(ex, 200, h.handle(req));
        } catch (ApiException e) {
            sendJson(ex, e.status, Map.of("error", e.getMessage()));
        } catch (IllegalArgumentException e) {
            sendJson(ex, 400, Map.of("error", e.getMessage()));
        } catch (Exception e) {
            e.printStackTrace();
            sendJson(ex, 500, Map.of("error", "Server error: " + e.getMessage()));
        }
    }

    private void handleStatic(HttpExchange ex, String method, String path) throws IOException {
        if (!method.equals("GET") && !method.equals("HEAD")) { send(ex, 405, "text/plain", "Method not allowed".getBytes()); return; }
        String decoded = URLDecoder.decode(path, StandardCharsets.UTF_8);
        if (decoded.equals("/") || decoded.isEmpty()) decoded = "/index.html";
        Path file = webRoot.resolve(decoded.substring(1)).normalize();
        if (!file.startsWith(webRoot)) { send(ex, 403, "text/plain", "Forbidden".getBytes()); return; }   // path traversal guard
        if (Files.isDirectory(file)) file = file.resolve("index.html");
        if (!Files.isRegularFile(file)) {
            Path nf = webRoot.resolve("404.html");
            byte[] body = Files.isRegularFile(nf) ? Files.readAllBytes(nf) : "Not found".getBytes();
            send(ex, 404, "text/html; charset=utf-8", body);
            return;
        }
        ex.getResponseHeaders().set("Cache-Control", "no-cache");
        send(ex, 200, mime(file.getFileName().toString()), method.equals("HEAD") ? new byte[0] : Files.readAllBytes(file));
    }

    // ------------------------------------------------------------------ helpers
    private static void addCors(HttpExchange ex) {
        ex.getResponseHeaders().set("Access-Control-Allow-Origin", "*");
        ex.getResponseHeaders().set("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
        ex.getResponseHeaders().set("Access-Control-Allow-Headers", "Content-Type");
    }

    private static void sendJson(HttpExchange ex, int status, Object payload) throws IOException {
        send(ex, status, "application/json; charset=utf-8", JsonUtil.stringify(payload).getBytes(StandardCharsets.UTF_8));
    }

    private static void send(HttpExchange ex, int status, String type, byte[] body) throws IOException {
        ex.getResponseHeaders().set("Content-Type", type);
        if (status == 204) { ex.sendResponseHeaders(204, -1); return; }
        ex.sendResponseHeaders(status, body.length);
        try (OutputStream os = ex.getResponseBody()) { os.write(body); }
    }

    private static byte[] readAll(InputStream in) throws IOException {
        return in.readAllBytes();
    }

    private static Map<String, String> parseQuery(String raw) {
        Map<String, String> q = new LinkedHashMap<>();
        if (raw == null || raw.isEmpty()) return q;
        for (String pair : raw.split("&")) {
            int eq = pair.indexOf('=');
            String k = URLDecoder.decode(eq < 0 ? pair : pair.substring(0, eq), StandardCharsets.UTF_8);
            String v = eq < 0 ? "" : URLDecoder.decode(pair.substring(eq + 1), StandardCharsets.UTF_8);
            q.put(k, v);
        }
        return q;
    }

    private static String mime(String name) {
        String n = name.toLowerCase();
        if (n.endsWith(".html")) return "text/html; charset=utf-8";
        if (n.endsWith(".css")) return "text/css; charset=utf-8";
        if (n.endsWith(".js")) return "application/javascript; charset=utf-8";
        if (n.endsWith(".json")) return "application/json; charset=utf-8";
        if (n.endsWith(".svg")) return "image/svg+xml";
        if (n.endsWith(".png")) return "image/png";
        if (n.endsWith(".jpg") || n.endsWith(".jpeg")) return "image/jpeg";
        if (n.endsWith(".ico")) return "image/x-icon";
        if (n.endsWith(".woff2")) return "font/woff2";
        return "application/octet-stream";
    }
}
