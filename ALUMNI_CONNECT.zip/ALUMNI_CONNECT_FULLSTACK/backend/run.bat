@echo off
REM Compiles the Java backend and starts AlumniConnect (API + website) on http://localhost:8080
REM Usage: run.bat [port]      Requires a JDK 17+ (javac).
cd /d "%~dp0"
where javac >nul 2>nul
if errorlevel 1 (
  echo ERROR: javac not found. Install a JDK 17 or newer from https://adoptium.net and try again.
  pause
  exit /b 1
)
if exist out rmdir /s /q out
mkdir out
javac -d out -sourcepath src src\alumniconnect\Main.java
if errorlevel 1 (
  pause
  exit /b 1
)
echo Build OK.
set PORT=%1
if "%PORT%"=="" set PORT=8080
java -cp out alumniconnect.Main %PORT%
pause
