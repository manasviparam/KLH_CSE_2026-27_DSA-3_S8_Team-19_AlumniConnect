# AlumniConnect – Java Backend

All data structures, algorithms and graph algorithms of AlumniConnect, plus a tiny HTTP server.
See the project-level `README.md` for the full picture.

    src/alumniconnect/
      Main.java                    starts the server (API + static website)
      server/                      ApiServer (JDK HttpServer), JsonUtil, ApiRequest, handlers/*
      store/DataStore.java         in-memory snapshot of the browser data (no database)
      model/                       UserProfile, Person, Connection
      dsa/                         DynamicArray, Queue, Trie(+Node), KMP, NaiveSearch, AhoCorasick,
                                   EditDistance, LCS, InsertionSort, LinearSearch, SearchEngine
      graph/                       ConnectionWeight (profile similarity), IndustryCatalog, SocialGraph, Recommender, MinHeap,
                                   Dijkstra, FloydWarshall, MentorScore, BipartiteMatching
    test/alumniconnect/            DsaTests (35), GraphTests (34)

Commands (JDK 17+): `run.sh` / `run.bat` start the app on http://localhost:8080; `run-tests.sh` / `run-tests.bat` run the tests.
