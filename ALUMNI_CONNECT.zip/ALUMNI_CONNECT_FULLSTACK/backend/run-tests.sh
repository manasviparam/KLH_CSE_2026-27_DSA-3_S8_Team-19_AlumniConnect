#!/usr/bin/env bash
# Compiles the backend + tests and runs all of them. Requires a JDK 17+.
cd "$(dirname "$0")" || exit 1
rm -rf out && mkdir -p out
javac -d out -sourcepath src test/alumniconnect/DsaTests.java test/alumniconnect/GraphTests.java || exit 1
echo "=== DSA tests ===";   java -cp out alumniconnect.DsaTests || exit 1
echo; echo "=== Graph tests ==="; java -cp out alumniconnect.GraphTests
