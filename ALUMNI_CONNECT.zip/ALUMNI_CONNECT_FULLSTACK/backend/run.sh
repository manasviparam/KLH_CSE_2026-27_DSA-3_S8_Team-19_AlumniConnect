#!/usr/bin/env bash
# Compiles the Java backend and starts AlumniConnect (API + website) on http://localhost:8080
# Usage: ./run.sh [port]      Requires a JDK 17+ (javac).
cd "$(dirname "$0")" || exit 1
if ! command -v javac >/dev/null 2>&1; then
  echo "ERROR: javac not found. Install a JDK 17 or newer (https://adoptium.net) and try again."; exit 1
fi
rm -rf out && mkdir -p out
javac -d out -sourcepath src src/alumniconnect/Main.java || exit 1
echo "Build OK."
exec java -cp out alumniconnect.Main "${1:-8080}"
