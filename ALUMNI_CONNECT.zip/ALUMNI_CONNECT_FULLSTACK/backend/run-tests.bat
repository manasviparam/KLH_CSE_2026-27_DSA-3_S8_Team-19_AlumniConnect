@echo off
REM Compiles the backend + tests and runs all of them. Requires a JDK 17+.
cd /d "%~dp0"
if exist out rmdir /s /q out
mkdir out
javac -d out -sourcepath src test\alumniconnect\DsaTests.java test\alumniconnect\GraphTests.java || exit /b 1
echo === DSA tests ===
java -cp out alumniconnect.DsaTests || exit /b 1
echo.
echo === Graph tests ===
java -cp out alumniconnect.GraphTests
