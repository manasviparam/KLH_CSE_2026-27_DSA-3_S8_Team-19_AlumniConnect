package alumniconnect;

import alumniconnect.dsa.*;
import alumniconnect.dsa.Queue;
import alumniconnect.model.UserProfile;

import java.util.*;

/** Dependency-free tests. Run with backend/run-tests.sh (or .bat). Exit code 1 on failure. */
public class DsaTests {
    static int passed = 0, failed = 0;

    static void check(String name, boolean ok) {
        if (ok) { passed++; System.out.println("  PASS  " + name); }
        else    { failed++; System.out.println("  FAIL  " + name); }
    }

    static UserProfile p(String id, String name, String org, int year, List<String> skills, List<String> interests, String bio) {
        return new UserProfile(id, name, org, "KL University", year, skills, interests, bio);
    }

    public static void main(String[] args) {
        // 1. Dynamic Array
        DynamicArray<Integer> da = new DynamicArray<>();
        for (int i = 0; i < 10; i++) da.add(i);
        check("DynamicArray capacity stays 10 at 10 items", da.capacity() == 10);
        da.add(10);
        check("DynamicArray doubles to 20 when full", da.capacity() == 20 && da.size() == 11);
        check("DynamicArray removeAt shifts left", da.removeAt(0) == 0 && da.get(0) == 1 && da.size() == 10);
        check("DynamicArray get out of range -> null", da.get(99) == null);

        // 2. Queue
        Queue<String> q = new Queue<>();
        q.enqueue("a"); q.enqueue("b"); q.enqueue("c");
        check("Queue FIFO order", "a".equals(q.dequeue()) && "b".equals(q.front()) && q.size() == 2);
        q.dequeue(); q.dequeue();
        check("Queue empty -> dequeue null", q.isEmpty() && q.dequeue() == null && q.front() == null);

        // Naive + KMP
        NaiveSearch.Result nv = NaiveSearch.search("Java Developer", "Java");
        check("Naive: match at 0, 14 comparisons (4 + 10 first-char misses)", nv.matches().equals(List.of(0)) && nv.comparisons() == 14);
        check("KMP LPS of ababaca", Arrays.equals(KMP.computeLPSArray("ababaca"), new int[]{0, 0, 1, 2, 3, 0, 1}));
        KMP.Result k = KMP.search("ababcabcabababd", "ababd");
        check("KMP finds ababd at 10", k.matches().equals(List.of(10)));
        check("KMP finds overlapping matches", KMP.search("aaaa", "aa").matches().equals(List.of(0, 1, 2)));
        check("KMP is case-insensitive", KMP.search("Senior JAVA Engineer", "java").matches().equals(List.of(7)));
        check("KMP empty pattern -> [0]", KMP.search("abc", "").matches().equals(List.of(0)));

        // 5. Trie + DFS
        Trie t = new Trie();
        t.insert("Java"); t.insert("JavaScript"); t.insert("Python");
        List<String> words = new ArrayList<>();
        for (Trie.Suggestion s : t.getSuggestions("Ja")) words.add(s.word());
        check("Trie 'Ja' -> [Java, JavaScript]", words.equals(List.of("Java", "JavaScript")));
        check("Trie unknown prefix -> empty", t.getSuggestions("zzz").isEmpty());

        List<UserProfile> alumni = List.of(
            p("u1", "Aarav Sharma", "Google", 2015, List.of("DSA", "Java", "System Design"), List.of("Mentorship", "Career Guidance"), "Senior engineer working on distributed systems."),
            p("u2", "Priya Patel", "Microsoft", 2016, List.of("JavaScript", "React", "Azure"), List.of("Open Source", "Resume Reviews"), "Frontend engineer and mentor."),
            p("u3", "Rohan Mehta", "Amazon", 2017, List.of("Python", "Machine Learning", "AWS"), List.of("AI Research", "Mock Interviews"), "Applied scientist at AWS."));
        Trie profileTrie = Trie.fromProfiles(alumni);
        List<Trie.Suggestion> pr = profileTrie.getSuggestions("pri");
        check("Trie from profiles: 'pri' -> Priya Patel (Alumni)", !pr.isEmpty() && pr.get(0).word().equals("Priya Patel") && pr.get(0).type().equals("Alumni"));

        // 6. Aho-Corasick (classic he/she/his/hers)
        AhoCorasick ac = new AhoCorasick(List.of("he", "she", "his", "hers"));
        Set<String> got = new TreeSet<>();
        for (AhoCorasick.Match m : ac.search("ushers").matches()) got.add(m.pattern() + "@" + m.index());
        check("Aho-Corasick 'ushers' -> she@1, he@2, hers@2", got.equals(new TreeSet<>(List.of("she@1", "he@2", "hers@2"))));
        AhoCorasick ac2 = new AhoCorasick(List.of("Java", "React", "AWS"));
        check("Aho-Corasick multi keyword", ac2.search("Java and AWS and react").matches().size() == 3);

        // 7. Edit distance
        check("EditDistance javscript->javascript = 1", EditDistance.compute("javscript", "javascript").distance() == 1);
        check("EditDistance kitten->sitting = 3", EditDistance.compute("kitten", "sitting").distance() == 3);
        check("EditDistance identical = 0", EditDistance.compute("abc", "ABC").distance() == 0);
        check("Typo suggestion", EditDistance.typoSuggestion("javscript", List.of("python", "javascript")).orElse("").equals("javascript"));
        check("Typo suggestion: exact match gives none", EditDistance.typoSuggestion("python", List.of("python")).isEmpty());

        // 8. LCS
        check("LCS ABCBDAB / BDCABA = 4", LCS.compute("ABCBDAB", "BDCABA").length() == 4);
        check("LCS with empty = 0", LCS.compute("", "abc").length() == 0);
        check("Similarity of profile with itself = 100", LCS.similarityScore(alumni.get(0), alumni.get(0)) == 100);
        check("Similarity in range and symmetric", LCS.similarityScore(alumni.get(0), alumni.get(1)) == LCS.similarityScore(alumni.get(1), alumni.get(0))
                && LCS.similarityScore(alumni.get(0), alumni.get(1)) < 100);

        // 9. Insertion sort
        List<Integer> sorted = InsertionSort.sortByKey(List.of(90, 60, 80, 70), x -> x, false);
        check("InsertionSort desc [90,60,80,70] -> [90,80,70,60]", sorted.equals(List.of(90, 80, 70, 60)));
        List<String> byName = new ArrayList<>();
        for (UserProfile u : InsertionSort.sortByKey(alumni, UserProfile::graduationYear, false)) byName.add(u.name());
        check("InsertionSort by graduationYear desc", byName.equals(List.of("Rohan Mehta", "Priya Patel", "Aarav Sharma")));
        List<int[]> pairs = List.of(new int[]{1, 1}, new int[]{1, 2}, new int[]{0, 3});
        List<int[]> st = InsertionSort.sort(pairs, Comparator.comparingInt(a -> a[0]));
        check("InsertionSort is stable", st.get(0)[1] == 3 && st.get(1)[1] == 1 && st.get(2)[1] == 2);

        // 10. Linear search
        List<String> ids = List.of("A001", "A002", "A003", "A004");
        LinearSearch.Result<String> ls = LinearSearch.search(ids, s -> s, "a003");
        check("LinearSearch A003 -> index 2, 3 comparisons", ls.found() && ls.index() == 2 && ls.comparisons() == 3);
        check("LinearSearch missing -> not found, 4 comparisons", !LinearSearch.search(ids, s -> s, "zzz").found() && LinearSearch.search(ids, s -> s, "zzz").comparisons() == 4);

        // Search engine facade
        SearchEngine.SearchResult r1 = SearchEngine.search(alumni, "java", "kmp", SearchEngine.Filters.none());
        check("SearchEngine single keyword uses KMP and finds Aarav + Priya (JavaScript)", r1.algorithm().startsWith("KMP") && r1.matchCount() == 2);
        SearchEngine.SearchResult r2 = SearchEngine.search(alumni, "python aws", "kmp", SearchEngine.Filters.none());
        check("SearchEngine multi keyword uses Aho-Corasick", r2.algorithm().startsWith("Aho-Corasick") && r2.matchCount() == 1
                && r2.data().get(0).profile().name().equals("Rohan Mehta"));
        SearchEngine.SearchResult r3 = SearchEngine.search(alumni, "", "kmp", new SearchEngine.Filters(null, "Google", "all"));
        check("SearchEngine empty query + organization filter", r3.matchCount() == 1);
        SearchEngine.SearchResult r4 = SearchEngine.search(alumni, "engineer", "kmp",
                new SearchEngine.Filters(new SearchEngine.SearchFields(true, false, false, false, false), "all", "all"));
        check("SearchEngine honours searchFields (name only -> no match for 'engineer')", r4.matchCount() == 0);

        System.out.println("\n" + passed + " passed, " + failed + " failed");
        if (failed > 0) System.exit(1);
    }
}
