package alumniconnect;

import alumniconnect.graph.*;
import alumniconnect.model.Connection;
import alumniconnect.model.Person;
import alumniconnect.server.JsonUtil;

import java.util.*;

/** Dependency-free tests for the graph algorithms, the weight formula and the JSON utility. */
public class GraphTests {
    static int passed = 0, failed = 0;

    static void check(String name, boolean ok) {
        if (ok) { passed++; System.out.println("  PASS  " + name); }
        else    { failed++; System.out.println("  FAIL  " + name); }
    }

    static Person person(String id, String role, String org, String dept, List<String> skills, List<String> interests) {
        return new Person(id, id, role, "KL University", 2024, org, dept, "", skills, interests, "");
    }

    public static void main(String[] args) {
        weightFormula();
        dijkstra();
        floydWarshall();
        recommender();
        sync();
        bipartite();
        json();
        System.out.println("\n" + passed + " passed, " + failed + " failed");
        if (failed > 0) System.exit(1);
    }

    // ---------------------------------------------------------------- connection weight
    static void weightFormula() {
        System.out.println("Connection weight");
        double sum = ConnectionWeight.W_SKILLS + ConnectionWeight.W_DEPARTMENT + ConnectionWeight.W_INDUSTRY
                + ConnectionWeight.W_MUTUAL + ConnectionWeight.W_INTERESTS + ConnectionWeight.W_DIRECT;
        check("factor weights add up to 1.0", Math.abs(sum - 1.0) < 1e-9);

        Person a = person("a", "alumni", "Google", "CS", List.of("Java", "Go", "AWS"), List.of("Backend"));
        Person same = person("b", "alumni", "Google", "CS", List.of("Java", "Go", "AWS"), List.of("Backend"));
        Person some = person("c", "alumni", "Google", "", List.of("Java", "Python", "SQL"), List.of());
        Person none = person("d", "alumni", "Unknownco", "", List.of("Painting"), List.of());

        ConnectionWeight.Breakdown strong = ConnectionWeight.compute(a, same, Set.of(), Set.of(), false);
        ConnectionWeight.Breakdown medium = ConnectionWeight.compute(a, some, Set.of(), Set.of(), false);
        ConnectionWeight.Breakdown weak = ConnectionWeight.compute(a, none, Set.of(), Set.of(), false);
        check("stronger relationship => LOWER weight", strong.weight() < medium.weight() && medium.weight() < weak.weight());
        check("weight = 1 - strength (above the floor)", Math.abs(medium.weight() - (1 - medium.strength())) < 1e-9);
        check("weight never reaches 0 (floor 0.05)", strong.weight() >= ConnectionWeight.MIN_WEIGHT);
        check("department only counts when both filled and equal", strong.sameDepartment() == 1.0 && medium.sameDepartment() == 0.0);
        check("deterministic (same inputs, same weight)", ConnectionWeight.compute(a, some, Set.of(), Set.of(), false).weight() == medium.weight());

        ConnectionWeight.Breakdown withMutual = ConnectionWeight.compute(a, some, Set.of("m1", "m2"), Set.of("m1", "m3"), false);
        check("mutual connections raise strength", withMutual.mutualCount() == 1 && withMutual.strength() > medium.strength());
        ConnectionWeight.Breakdown direct = ConnectionWeight.compute(a, some, Set.of(), Set.of(), true);
        check("accepted direct connection raises strength", direct.strength() > medium.strength());
    }

    static List<Person> synthetic(int n, long seed) {
        Random rnd = new Random(seed);
        String[] pool = {"java", "python", "go", "react", "sql", "aws", "c++", "swift", "kafka", "docker", "ml", "rust"};
        String[] orgs = {"Google", "Meta", "Apple", "Stripe", "Uber", "Adobe", "Unknownco"};
        List<Person> list = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            List<String> skills = new ArrayList<>();
            for (int k = 0; k < 3; k++) skills.add(pool[rnd.nextInt(pool.length)]);
            list.add(person("u" + i, i % 3 == 0 ? "student" : "alumni", i % 3 == 0 ? "" : orgs[rnd.nextInt(orgs.length)],
                    rnd.nextInt(3) == 0 ? "CS" : "", skills, List.of()));
        }
        return list;
    }

    // ---------------------------------------------------------------- shared fixtures
    static Connection conn(String student, String alumni, String status) {
        return new Connection(student + "-" + alumni, student, alumni, status);
    }

    /**
     * S1 - A1 - S2 - A2 (accepted chain), S1 - A3 pending, A4 / S3 have nothing, S4 - A5 is a separate pair.
     * All profiles are IDENTICAL, so any edge created by profile similarity would shortcut the chain.
     */
    static List<Person> people() {
        List<String> sk = List.of("java", "sql");
        return List.of(
                person("S1", "student", "", "CS", sk, List.of("backend")), person("S2", "student", "", "CS", sk, List.of("backend")),
                person("S3", "student", "", "CS", sk, List.of("backend")), person("S4", "student", "", "CS", sk, List.of("backend")),
                person("A1", "alumni", "Google", "CS", sk, List.of("backend")), person("A2", "alumni", "Google", "CS", sk, List.of("backend")),
                person("A3", "alumni", "Google", "CS", sk, List.of("backend")), person("A4", "alumni", "Google", "CS", sk, List.of("backend")),
                person("A5", "alumni", "Google", "CS", sk, List.of("backend")));
    }

    static List<Connection> connections() {
        return List.of(conn("S1", "A1", "accepted"), conn("S2", "A1", "accepted"), conn("S2", "A2", "accepted"),
                conn("S1", "A3", "pending"), conn("S3", "A4", "rejected"), conn("S4", "A5", "accepted"));
    }

    static List<String> ids(Dijkstra.Result r) { return r.path().stream().map(Dijkstra.NodeInfo::id).toList(); }

    // ---------------------------------------------------------------- dijkstra
    static void dijkstra() {
        System.out.println("Dijkstra");
        SocialGraph g = new SocialGraph(people(), connections());
        check("only accepted connections are edges (4 of 6 records)", g.edgeCount() == 4);
        check("profile similarity creates no edge (identical profiles, no connection)",
                !Dijkstra.shortestPath(new SocialGraph(people(), List.of()), "S1", "S2").found());

        Dijkstra.Result r = Dijkstra.shortestPath(g, "S1", "A2");   // student -> alumni
        check("student -> alumni route S1,A1,S2,A2 with 3 hops", r.found() && r.hops() == 3 && ids(r).equals(List.of("S1", "A1", "S2", "A2")));
        r = Dijkstra.shortestPath(g, "A2", "S1");                    // alumni -> student
        check("alumni -> student route is the reverse (undirected)", r.found() && r.hops() == 3 && ids(r).equals(List.of("A2", "S2", "A1", "S1")));
        r = Dijkstra.shortestPath(g, "S1", "S2");                    // student -> student
        check("student -> student goes through a shared alumnus (2 hops)", r.found() && r.hops() == 2 && ids(r).equals(List.of("S1", "A1", "S2")));
        r = Dijkstra.shortestPath(g, "A1", "A2");                    // alumni -> alumni
        check("alumni -> alumni goes through a student (2 hops)", r.found() && r.hops() == 2 && ids(r).equals(List.of("A1", "S2", "A2")));
        r = Dijkstra.shortestPath(g, "S1", "A1");
        check("direct connection = 1 hop", r.found() && r.hops() == 1 && r.path().size() == 2);
        check("route entries carry name / role / organization", r.path().get(1).role().equals("alumni") && r.path().get(1).organization().equals("Google"));

        check("pending request is not an edge", !Dijkstra.shortestPath(g, "S1", "A3").found());
        check("rejected request is not an edge", !Dijkstra.shortestPath(g, "S3", "A4").found());
        Dijkstra.Result none = Dijkstra.shortestPath(g, "S1", "S4");
        check("disconnected users -> found=false, 0 hops, empty path, message", !none.found() && none.hops() == 0 && none.path().isEmpty() && !none.message().isEmpty());
        check("user with no connections is unreachable", !Dijkstra.shortestPath(g, "S3", "A1").found());
        check("unknown user -> found=false with message", !Dijkstra.shortestPath(g, "S1", "nobody").found());
        check("same user -> 0 hops", Dijkstra.shortestPath(g, "S1", "S1").hops() == 0);
        check("path length is symmetric", Dijkstra.shortestPath(g, "A2", "S1").hops() == Dijkstra.shortestPath(g, "S1", "A2").hops());

        // duplicate / reversed-status records of one pair count once; accepted wins over nothing
        SocialGraph dup = new SocialGraph(people(), List.of(conn("S1", "A1", "accepted"), conn("S1", "A1", "accepted")));
        check("duplicate accepted records make one edge", dup.edgeCount() == 1);
        String json = JsonUtil.stringify(Dijkstra.shortestPath(g, "S1", "A2"));
        check("result JSON has no cost / strength / explored data", !json.contains("totalWeight") && !json.contains("averageStrength")
                && !json.contains("nodesExplored") && !json.contains("hopDetails") && json.contains("\"hops\":3"));
    }

    // ---------------------------------------------------------------- floyd-warshall
    static void floydWarshall() {
        System.out.println("Floyd-Warshall");
        SocialGraph g = new SocialGraph(people(), connections());
        FloydWarshall.Result fw = FloydWarshall.analyse(g);
        double[][] d = fw.distances();
        int s1 = g.indexOf("S1"), a2 = g.indexOf("A2"), s3 = g.indexOf("S3"), s4 = g.indexOf("S4"), a5 = g.indexOf("A5");
        boolean diag = true, sym = true;
        for (int i = 0; i < d.length; i++) { diag &= d[i][i] == 0; for (int j = 0; j < d.length; j++) sym &= d[i][j] == d[j][i]; }
        check("diagonal is 0 and matrix symmetric", diag && sym);
        check("distance S1 -> A2 is 3 hops", d[s1][a2] == 3.0);
        check("unreachable pair stays infinite (user without connections)", Double.isInfinite(d[s1][s3]) && Double.isInfinite(d[s3][s3 == 0 ? 1 : 0]));
        check("groups: {S1,S2,A1,A2}, {S4,A5}, S3, A3, A4 = 5", fw.components() == 5);
        // reachable: chain of 4 -> 6 pairs, pair S4-A5 -> 1 pair; total pairs = 36
        check("reachable pairs = 7, unreachable = 29", fw.reachablePairs() == 7 && fw.unreachablePairs() == 29);
        check("diameter ignores unreachable pairs (3 hops, not infinity)", fw.diameter() != null && fw.diameter() == 3.0);
        // distances 1,1,1 (S1A1,S2A1,S2A2) + 2,2 (S1S2, A1A2) + 3 (S1A2) + 1 (S4A5) = 11 over 7 pairs
        check("average distance counts only reachable pairs (11/7)", Math.abs(fw.averageDistance() - 11.0 / 7) < 1e-9);
        check("network density = 2E / (V(V-1))", Math.abs(fw.density() - 8.0 / 72) < 1e-9);
        boolean noIsolatedCentral = fw.centrality().stream().noneMatch(u -> u.reachable() == 0);
        check("users with no connections are never listed as central", noIsolatedCentral && !fw.centrality().isEmpty());
        FloydWarshall.UserSummary iso = fw.mostIsolated().get(0);
        check("least connected user has reachable=0 and unreachable=8", iso.reachable() == 0 && iso.unreachable() == 8);
        String json = JsonUtil.stringify(fw);
        check("unreachable distances serialise as null (no Infinity)", json.contains("null") && !json.contains("Infinity"));
        check("central user is S2 or A1 (closest to everyone in the chain)", Set.of("S2", "A1").contains(fw.centrality().get(0).id()));

        FloydWarshall.Result empty = FloydWarshall.analyse(new SocialGraph(people(), List.of()));
        check("no accepted connections: no diameter / average, nothing reachable",
                empty.diameter() == null && empty.averageDistance() == null && empty.reachablePairs() == 0 && empty.centrality().isEmpty());
        FloydWarshall.Result nobody = FloydWarshall.analyse(new SocialGraph(List.of(), List.of()));
        check("empty network does not crash", nobody.userCount() == 0);

        // cross-check every pair against Dijkstra on random student/alumni networks (many unreachable pairs)
        boolean allEqual = true;
        for (long seed = 1; seed <= 5; seed++) {
            List<Person> ps = synthetic(24, seed);
            List<Connection> cs = new ArrayList<>();
            Random rnd = new Random(seed);
            for (int k = 0; k < 20; k++) {
                Person x = ps.get(rnd.nextInt(ps.size())), y = ps.get(rnd.nextInt(ps.size()));
                if (x.isStudent() && y.isAlumni()) cs.add(conn(x.id(), y.id(), rnd.nextInt(4) == 0 ? "pending" : "accepted"));
            }
            SocialGraph sg = new SocialGraph(ps, cs);
            double[][] m = FloydWarshall.analyse(sg).distances();
            for (int i = 0; i < sg.size(); i++)
                for (int j = 0; j < sg.size(); j++) {
                    Dijkstra.Result res = Dijkstra.shortestPath(sg, sg.node(i).id(), sg.node(j).id());
                    boolean same = res.found() ? Math.abs(res.hops() - m[i][j]) < 1e-9 : Double.isInfinite(m[i][j]);
                    if (!same) allEqual = false;
                }
        }
        check("Floyd-Warshall == Dijkstra on every pair (5 random networks x 576 pairs)", allEqual);
    }

    // ---------------------------------------------------------------- people you may know
    static List<String> suggested(Recommender.Result r) { return r.suggestions().stream().map(Recommender.Suggestion::id).toList(); }

    static void recommender() {
        System.out.println("People You May Know");
        // S1-A1, S2-A1, S2-A2, S2-A3, S5-A2, S5-A3 ; pending S1-A3 ; rejected S1-A4 ; S3 has nothing
        List<Person> ps = new ArrayList<>(people());
        ps.add(person("S5", "student", "", "", List.of("zzz"), List.of()));
        List<Connection> cs = List.of(conn("S1", "A1", "accepted"), conn("S2", "A1", "accepted"), conn("S2", "A2", "accepted"),
                conn("S2", "A3", "accepted"), conn("S5", "A2", "accepted"), conn("S5", "A3", "accepted"),
                conn("S1", "A3", "pending"), conn("S1", "A4", "rejected"));
        SocialGraph g = new SocialGraph(ps, cs);

        Recommender.Result r = Recommender.recommend(g, cs, "S1", 10);
        check("student gets alumni recommended through mutual connections", r.found() && suggested(r).contains("A2"));
        check("excludes yourself", !suggested(r).contains("S1"));
        check("excludes existing accepted connections", !suggested(r).contains("A1"));
        check("excludes pending requests (A3 has a mutual but is pending)", !suggested(r).contains("A3"));
        check("same-role users are not recommended (cannot connect)", suggested(r).stream().noneMatch(id -> id.startsWith("S")));
        check("no mutual connection -> not recommended (A4 rejected, A5 unrelated)", !suggested(r).contains("A4") && !suggested(r).contains("A5"));
        check("mutual connections are named", r.suggestions().get(0).mutualConnections().contains("S2") && r.suggestions().get(0).mutualCount() == 1);

        Recommender.Result alumniView = Recommender.recommend(g, cs, "A1", 10);
        check("alumnus gets students recommended (S5 via S2 / A2,A3)", suggested(alumniView).contains("S5") && !suggested(alumniView).contains("S2") && !suggested(alumniView).contains("S1"));

        // ranking: more mutual connections first, similarity only as tie-break
        List<Person> rp = List.of(
                person("U", "student", "", "", List.of("java", "sql", "go"), List.of()),
                person("P", "student", "", "", List.of("x"), List.of()), person("Q", "student", "", "", List.of("y"), List.of()),
                person("L1", "alumni", "Unknownco", "", List.of("java"), List.of()),   // link to U
                person("L2", "alumni", "Unknownco", "", List.of("java"), List.of()),   // link to U
                person("C2", "alumni", "Unknownco", "", List.of("q1"), List.of()),     // 2 mutual, dissimilar
                person("C1a", "alumni", "Unknownco", "", List.of("java", "sql", "go"), List.of()), // 1 mutual, very similar
                person("C1b", "alumni", "Unknownco", "", List.of("q2"), List.of()));   // 1 mutual, dissimilar
        List<Connection> rc = List.of(conn("U", "L1", "accepted"), conn("U", "L2", "accepted"),
                conn("P", "L1", "accepted"), conn("Q", "L2", "accepted"),
                conn("P", "C2", "accepted"), conn("Q", "C2", "accepted"),
                conn("P", "C1a", "accepted"), conn("P", "C1b", "accepted"));
        Recommender.Result rr = Recommender.recommend(new SocialGraph(rp, rc), rc, "U", 10);
        check("ranked by mutual count first, then similarity", suggested(rr).equals(List.of("C2", "C1a", "C1b")));
        check("similarity is secondary (C2 first despite lower similarity)", rr.suggestions().get(0).similarity() < rr.suggestions().get(1).similarity());
        check("limit is respected", Recommender.recommend(new SocialGraph(rp, rc), rc, "U", 2).suggestions().size() == 2);

        Recommender.Result isolated = Recommender.recommend(g, cs, "S3", 5);
        check("user without connections -> empty list with message", isolated.found() && isolated.suggestions().isEmpty() && !isolated.message().isEmpty());
        check("unknown user -> found=false", !Recommender.recommend(g, cs, "ghost", 5).found());
        check("pending request from the OTHER side is also excluded",
                !suggested(Recommender.recommend(g, cs, "A3", 10)).contains("S1"));
        // after a request is accepted it becomes an edge and disappears from the suggestions
        List<Connection> cs2 = new ArrayList<>(cs); cs2.add(conn("S1", "A2", "accepted"));
        check("newly accepted connection is no longer suggested", !suggested(Recommender.recommend(new SocialGraph(ps, cs2), cs2, "S1", 10)).contains("A2"));
    }

    // ---------------------------------------------------------------- data sync (DataStore <- browser snapshot)
    static String snapshot(String connectionsJson) {
        return "{\"alumni\":[{\"userId\":\"a1\",\"name\":\"Al\",\"organization\":\"Google\",\"skills\":[\"java\"],\"interests\":[]},"
                + "{\"userId\":\"a2\",\"name\":\"Bo\",\"organization\":\"Uber\",\"skills\":[\"go\"],\"interests\":[]}],"
                + "\"students\":[{\"userId\":\"s1\",\"name\":\"Sam\",\"skills\":[\"java\"],\"interests\":[]},"
                + "{\"userId\":\"s2\",\"name\":\"Sue\",\"skills\":[],\"interests\":[]}],"
                + "\"connections\":" + connectionsJson + "}";
    }

    @SuppressWarnings("unchecked")
    static void sync() {
        System.out.println("Data sync");
        alumniconnect.store.DataStore store = new alumniconnect.store.DataStore();
        long v0 = store.version();
        store.sync((Map<String, Object>) JsonUtil.parse(snapshot("[{\"id\":\"c1\",\"studentId\":\"s1\",\"alumniId\":\"a1\",\"status\":\"accepted\"},"
                + "{\"id\":\"c2\",\"studentId\":\"s2\",\"alumniId\":\"a1\",\"status\":\"pending\"}]")));
        check("snapshot loads students, alumni and connections", store.people().size() == 4 && store.peopleWithRole("student").size() == 2
                && store.peopleWithRole("alumni").size() == 2 && store.connections().size() == 2);
        check("sync bumps the version (graph cache is rebuilt)", store.version() > v0);
        SocialGraph g1 = new SocialGraph(store.people(), store.connections());
        check("graph built from the snapshot uses only the accepted record", g1.edgeCount() == 1 && Dijkstra.shortestPath(g1, "s1", "a1").hops() == 1);
        check("pending record from the snapshot is not an edge", !Dijkstra.shortestPath(g1, "s2", "a1").found());

        store.sync((Map<String, Object>) JsonUtil.parse(snapshot("[{\"id\":\"c2\",\"studentId\":\"s2\",\"alumniId\":\"a1\",\"status\":\"accepted\"}]")));
        check("re-sync REPLACES the snapshot (no duplicates, old connection gone)", store.people().size() == 4 && store.connections().size() == 1);
        SocialGraph g2 = new SocialGraph(store.people(), store.connections());
        check("accepting a request in the browser shows up after the next sync",
                Dijkstra.shortestPath(g2, "s2", "a1").hops() == 1 && !Dijkstra.shortestPath(g2, "s1", "a1").found());
        store.sync((Map<String, Object>) JsonUtil.parse("{}"));
        check("empty snapshot is accepted and clears the data", store.people().isEmpty() && store.connections().isEmpty());
        store.sync((Map<String, Object>) JsonUtil.parse("{\"students\":[{\"userId\":\"s1\"},{\"userId\":\"s1\"},{\"name\":\"no id\"}],\"connections\":[{}]}"));
        SocialGraph g3 = new SocialGraph(store.people(), store.connections());
        check("records without id are skipped, duplicate ids collapse to one node, blank connection ignored", g3.size() == 1 && g3.edgeCount() == 0);
    }

    // ---------------------------------------------------------------- bipartite matching
    static int bruteForceMax(List<List<Integer>> adj, int cap) {
        return brute(0, adj, new int[adj.stream().flatMap(List::stream).mapToInt(x -> x).max().orElse(-1) + 1], cap);
    }

    static int brute(int s, List<List<Integer>> adj, int[] load, int cap) {
        if (s == adj.size()) return 0;
        int best = brute(s + 1, adj, load, cap);                 // leave s unmatched
        for (int a : adj.get(s)) {
            if (load[a] < cap) {
                load[a]++;
                best = Math.max(best, 1 + brute(s + 1, adj, load, cap));
                load[a]--;
            }
        }
        return best;
    }

    static void bipartite() {
        System.out.println("Bipartite matching");
        List<Person> students = List.of(
                person("s1", "student", "", "", List.of("java", "sql"), List.of("backend")),
                person("s2", "student", "", "", List.of("java"), List.of()),
                person("s3", "student", "", "", List.of("painting"), List.of()));
        List<Person> alumni = List.of(
                person("a1", "alumni", "Google", "", List.of("java", "sql", "go"), List.of("backend")),
                person("a2", "alumni", "Uber", "", List.of("java", "kafka"), List.of()));

        BipartiteMatching.Result r = BipartiteMatching.match(students, alumni, 1);
        check("s1 and s2 both matched (augmenting path needed: both want java)", r.matchingSize() == 2);
        check("student with no suitable alumnus stays unmatched", r.unmatchedStudents().size() == 1 && r.unmatchedStudents().get(0).id().equals("s3"));
        Set<String> used = new HashSet<>();
        boolean unique = true;
        for (BipartiteMatching.Match m : r.matches()) unique &= used.add(m.alumniId());
        check("capacity 1: no alumnus used twice", unique);
        boolean aboveThreshold = true;
        for (BipartiteMatching.Match m : r.matches()) aboveThreshold &= m.score() >= MentorScore.MIN_SCORE;
        check("every match scores above the threshold", aboveThreshold);
        check("capacity 2 lets one alumnus take two students", BipartiteMatching.match(students, List.of(alumni.get(0)), 2).matchingSize() == 2);
        check("capacity 1 with one alumnus matches only one", BipartiteMatching.match(students, List.of(alumni.get(0)), 1).matchingSize() == 1);

        check("capacity 0 is treated as 1", BipartiteMatching.match(students, alumni, 0).capacity() == 1);
        check("no alumni -> nobody matched, every student unmatched", BipartiteMatching.match(students, List.of(), 1).matchingSize() == 0
                && BipartiteMatching.match(students, List.of(), 1).unmatchedStudents().size() == 3);
        check("no students -> no matches, every alumnus unmatched", BipartiteMatching.match(List.of(), alumni, 1).matchingSize() == 0
                && BipartiteMatching.match(List.of(), alumni, 1).unmatchedAlumni().size() == 2);
        check("mentor matching ignores connection status (works on profiles)", BipartiteMatching.match(students, alumni, 1).matchingSize() == 2);
        check("matches are student -> alumnus only", r.matches().stream().allMatch(m -> m.studentId().startsWith("s") && m.alumniId().startsWith("a")));

        // Kuhn result must equal the brute-force maximum matching on random small instances
        boolean maximum = true;
        for (long seed = 1; seed <= 40; seed++) {
            List<Person> st = synthetic(18, seed).stream().filter(Person::isStudent).limit(5).toList();
            List<Person> al = synthetic(18, seed + 100).stream().filter(Person::isAlumni).limit(4).toList();
            for (int cap = 1; cap <= 2; cap++) {
                BipartiteMatching.Result res = BipartiteMatching.match(st, al, cap);
                List<List<Integer>> adj = new ArrayList<>();
                for (Person s : st) {
                    List<Integer> row = new ArrayList<>();
                    for (int a = 0; a < al.size(); a++) if (MentorScore.compute(s, al.get(a)).score() >= MentorScore.MIN_SCORE) row.add(a);
                    adj.add(row);
                }
                if (res.matchingSize() != brute(0, adj, new int[al.size()], cap)) maximum = false;
            }
        }
        check("matching size equals brute-force maximum (80 random instances)", maximum);
    }

    // ---------------------------------------------------------------- json
    record Sample(String name, int n, double x, List<String> tags) {}

    static void json() {
        System.out.println("JSON utility");
        Object parsed = JsonUtil.parse("{\"a\":[1,2.5,\"x\\n\\u0041\"],\"b\":{\"c\":true,\"d\":null}}");
        check("parse nested object", JsonUtil.stringify(parsed).equals("{\"a\":[1,2.5,\"x\\nA\"],\"b\":{\"c\":true,\"d\":null}}"));
        check("records serialise with component names", JsonUtil.stringify(new Sample("q\"t", 3, 0.123456, List.of("a"))).equals("{\"name\":\"q\\\"t\",\"n\":3,\"x\":0.1235,\"tags\":[\"a\"]}"));
        check("infinity / NaN become null", JsonUtil.stringify(new double[]{1, Double.POSITIVE_INFINITY, Double.NaN}).equals("[1,null,null]"));
        boolean threw = false;
        try { JsonUtil.parse("{\"a\":"); } catch (IllegalArgumentException e) { threw = true; }
        check("malformed JSON rejected", threw);
    }
}
