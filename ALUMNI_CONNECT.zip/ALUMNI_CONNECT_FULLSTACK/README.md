# AlumniConnect – Full-Stack Edition

```
Frontend (HTML / CSS / JS)  ──►  Java Backend / API  ──►  Java DSA & Graph Algorithms
   user interface only            JDK HttpServer            backend/src/alumniconnect/{dsa,graph}
```

* **No database.** The browser keeps `localStorage` as before; before each algorithm call the page sends a
  snapshot (`POST /api/sync`) and the Java server keeps it **in memory only**.
* **All algorithms are Java.** The browser contains no DSA code (`js/dsa.js` was removed). `js/api.js` only
  calls the API and `js/graph-ui.js` only draws the results.
* **No external libraries.** Plain Java 17+ and the JDK's built-in `com.sun.net.httpserver`.

## How to run

1. Install a **JDK 17 or newer** (`javac -version` must work) – e.g. from https://adoptium.net
2. Start everything with one command:

   | Windows | Linux / macOS |
   |---|---|
   | `cd backend` then `run.bat` | `cd backend` then `./run.sh` |

3. Open **http://localhost:8080** (the Java server also serves the website).
   Always use this address – do not double-click the HTML files, otherwise the browser's
   `localStorage` (and your accounts) will differ from the server origin.

Demo logins (password `123456`): student `rahul@gmail.com`, alumni `aarav.sharma@google.com`
(the existing login flow still asks for its captcha / verification code).

Run the automated tests: `backend/run-tests.bat` / `backend/run-tests.sh` (114 tests).

## Where each requirement lives

| Requirement | Java file (`backend/src/alumniconnect/…`) | UI |
|---|---|---|
| Dynamic Array | `dsa/DynamicArray.java` | DSA demo #9 |
| Queue | `dsa/Queue.java` | DSA demo #10, Aho-Corasick BFS |
| Trie + DFS | `dsa/Trie.java`, `TrieNode.java` | Directory autocomplete, demo #3 |
| KMP / Naive | `dsa/KMP.java`, `NaiveSearch.java` | Directory search, demos #1–2 |
| Aho-Corasick + BFS | `dsa/AhoCorasick.java` | Multi-word search, demo #4 |
| Edit Distance | `dsa/EditDistance.java` | "Did you mean…?" banner, demo #5 |
| LCS / DP | `dsa/LCS.java` | Similar alumni on profile page, demo #6 |
| Insertion Sort | `dsa/InsertionSort.java` | Result sorting, demo #7 |
| Linear Search | `dsa/LinearSearch.java` | Demo #8 |
| **Dijkstra** – Best Connection Path | `graph/Dijkstra.java`, `MinHeap.java`, `SocialGraph.java` | `student/network.html`, alumni profile page, demo #11 |
| **Floyd-Warshall** – Overall Network Analysis | `graph/FloydWarshall.java` | `student/network.html`, demo #12 |
| **Bipartite Matching** – Alumni Mentor Matching | `graph/BipartiteMatching.java`, `MentorScore.java` | `student/mentor-match.html`, alumni dashboard, demo #13 |

BFS/DFS were **not** added as graph features (they already exist as Aho-Corasick BFS and Trie DFS).

## Graph (deterministic – nothing is random)

**Edges = accepted connections only.** Pending / declined requests and profile similarity never create an edge.
Every accepted connection costs 1, so Dijkstra's best path is the shortest chain of people and its cost is the number of hops.
Floyd-Warshall uses the same graph; pairs with no chain of accepted connections are *unreachable* (shown as `–`)
and are left out of the average distance and diameter.

**People You May Know** (`graph/Recommender.java`, `GET /api/graph/recommend?userId=&limit=`)
Candidates are people of the opposite role (connections only exist between a student and an alumnus) who are not you,
not already connected to you and have no pending request with you. A candidate needs at least one mutual connection:
a person connected to the candidate who is connected to you or shares an accepted connection with you.
Ranking: number of mutual connections first, profile similarity (`ConnectionWeight`) only to break ties.

**Sample data:** `js/data.js` seeds sample accepted / pending / declined connections once, only for pairs that have no
record yet (existing data is never overwritten or duplicated).

**Mentor suitability (bipartite edge when ≥ 0.20)**
`score = 0.45·skillCoverage + 0.30·interestCoverage + 0.25·industryOverlap`.
Matching = Kuhn's augmenting-path algorithm (maximum matching); the "students per alumnus" selector sets capacity.

## API (JSON)

| Method & path | Algorithm |
|---|---|
| `POST /api/sync` | store the browser snapshot in memory |
| `GET /api/suggest?q=&max=` | Trie + DFS |
| `GET /api/typo?q=` | Edit Distance |
| `POST /api/search` | KMP / Aho-Corasick + Insertion Sort |
| `GET /api/similar?id=&limit=` | LCS |
| `GET /api/graph/path?from=&to=` | Dijkstra |
| `GET /api/graph/network` | Floyd-Warshall |
| `GET /api/graph/mentor-match?capacity=` | Bipartite matching |
| `POST /api/dsa/*` | the interactive demos |

## Troubleshooting

* *"Java backend is not reachable"* toast → the server is not running; start `run.bat` / `run.sh`.
* *`javac` not found* → install a JDK (a JRE is not enough).
* *Port in use* → `run.bat 9090` / `./run.sh 9090`, then open `http://localhost:9090`.
