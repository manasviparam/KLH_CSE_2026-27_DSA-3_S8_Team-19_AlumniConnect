/**
 * AlumniConnect - Graph result renderers (UI only).
 * Turns the JSON returned by the Java graph algorithms into HTML.
 * No algorithm runs here: Dijkstra / Floyd-Warshall / Bipartite Matching are in the Java backend.
 */
const GraphUI = (() => {
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const pct = v => Math.round((v || 0) * 100) + '%';
  const num = (v, d = 2) => (v == null ? '–' : Number(v).toFixed(d));

  /** Dijkstra result -> HTML: the people on the route and the number of hops. */
  function pathHTML(r) {
    const box = 'padding:1rem; background:var(--surface); border-radius:var(--radius-md); color:var(--text-muted);';
    if (!r.found) return `<div style="${box}">⚠️ ${esc(r.message)}</div>`;
    if (r.hops === 0) return `<div style="${box}">${esc(r.message)}</div>`;

    const chips = r.path.map((n, i) => `
      <span style="display:inline-flex; align-items:center; gap:0.4rem; padding:0.4rem 0.8rem; border-radius:var(--radius-full); font-weight:700; font-size:0.85rem;
        background:${i === 0 ? 'var(--accent-light)' : (i === r.path.length - 1 ? 'var(--secondary-light)' : 'var(--surface)')};
        color:${i === 0 ? 'var(--accent)' : (i === r.path.length - 1 ? 'var(--secondary)' : 'var(--text-main)')}; border:1px solid var(--border);">
        ${esc(n.name)} <span style="font-weight:500; font-size:0.72rem; opacity:0.8;">${n.role === 'alumni' ? esc(n.organization || 'Alumni') : 'Student'}</span>
      </span>`).join('<span style="color:var(--text-muted); font-weight:700;">→</span>');

    return `
      <div style="display:flex; align-items:center; gap:0.5rem; flex-wrap:wrap; margin-bottom:0.75rem;">${chips}</div>
      <div style="font-size:0.9rem;"><strong>Hops:</strong> ${r.hops}</div>`;
  }

  /** Floyd-Warshall distance matrix as a heat-map table. highlightId marks the signed-in user's row/column. */
  function matrixHTML(a, highlightId) {
    const n = a.users.length;
    let max = 0;
    for (let i = 0; i < n; i++) for (let j = 0; j < n; j++) { const v = a.distances[i][j]; if (v != null && v > max) max = v; }
    max = max || 1;

    const th = 'padding:3px 6px; border:1px solid var(--border); background:var(--surface); font-size:0.7rem; position:sticky;';
    let html = `<table style="border-collapse:collapse; font-size:0.72rem; text-align:center;"><thead><tr><th style="${th} left:0; z-index:2;"></th>`;
    for (let j = 0; j < n; j++) {
      const u = a.users[j];
      html += `<th title="${esc(u.name)}" style="${th} top:0; ${u.id === highlightId ? 'color:var(--accent);' : ''}">${j + 1}</th>`;
    }
    html += '</tr></thead><tbody>';
    for (let i = 0; i < n; i++) {
      const u = a.users[i];
      html += `<tr><th style="${th} left:0; text-align:left; white-space:nowrap; ${u.id === highlightId ? 'color:var(--accent);' : ''}">${i + 1}. ${esc(u.name)}</th>`;
      for (let j = 0; j < n; j++) {
        const v = a.distances[i][j];
        let bg = 'var(--surface)', txt = '–';   // – = not reachable
        if (v != null) {
          txt = String(Math.round(v));
          const t = i === j ? 0 : Math.min(1, (v - 1) / Math.max(1, max - 1));   // 0 = 1 hop (green), 1 = farthest (red)
          bg = i === j ? 'var(--surface)' : `hsl(${Math.round(140 - 140 * t)}, 65%, ${Math.round(88 - 10 * t)}%)`;
        }
        html += `<td title="${esc(u.name)} → ${esc(a.users[j].name)}: ${v == null ? 'not reachable' : (Math.round(v) + (Math.round(v) === 1 ? ' hop' : ' hops'))}" style="padding:3px 6px; border:1px solid var(--border); background:${bg}; color:${v == null ? 'var(--text-muted)' : '#0f172a'};">${txt}</td>`;
      }
      html += '</tr>';
    }
    return html + '</tbody></table>';
  }

  /** Floyd-Warshall summary cards. */
  function statCards(a) {
    const card = (label, value, sub) => `
      <div style="background:var(--surface); border:1px solid var(--border); border-radius:var(--radius-md); padding:0.85rem 1rem; min-width:150px; flex:1;">
        <div style="font-size:1.4rem; font-weight:800; color:var(--primary);">${value}</div>
        <div style="font-size:0.78rem; font-weight:600; color:var(--text-main);">${label}</div>
        ${sub ? `<div style="font-size:0.72rem; color:var(--text-muted);">${sub}</div>` : ''}
      </div>`;
    return `<div style="display:flex; gap:0.75rem; flex-wrap:wrap;">
      ${card('Users in network', a.userCount, a.edgeCount + ' accepted connections')}
      ${card('Average distance', a.averageDistance == null ? '–' : num(a.averageDistance, 2) + ' hops', 'over ' + a.reachablePairs + ' reachable pairs')}
      ${card('Network diameter', a.diameter == null ? '–' : Math.round(a.diameter) + ' hops', a.diameterFrom ? esc(a.diameterFrom) + ' ↔ ' + esc(a.diameterTo) : 'longest reachable distance')}
      ${card('Density', pct(a.density), 'links ÷ possible links')}
      ${card('Separate groups', a.components, a.unreachablePairs + ' unreachable pairs (not counted in averages)')}
    </div>`;
  }

  function rankList(list, highlightId) {
    return list.map((u, i) => `
      <div style="display:flex; justify-content:space-between; align-items:center; padding:0.45rem 0.6rem; border-radius:var(--radius-md); ${u.id === highlightId ? 'background:var(--accent-light);' : ''}">
        <span style="font-weight:600; font-size:0.88rem;">${i + 1}. ${esc(u.name)} <span style="font-weight:500; color:var(--text-muted); font-size:0.75rem;">${u.role === 'alumni' ? esc(u.organization || 'Alumni') : 'Student'}</span></span>
        <span style="font-size:0.78rem; color:var(--text-muted);">${u.reachable === 0 ? 'no accepted connections nearby' : 'avg ' + num(u.averageDistance, 2) + ' hops · reaches ' + u.reachable + ' of ' + (u.reachable + u.unreachable)}</span>
      </div>`).join('');
  }

  /** Small coloured chips for matched skills / interests / industries. */
  function chips(list, cls) {
    return (list || []).map(x => `<span class="tag ${cls || ''}" style="font-size:0.72rem;">${esc(x)}</span>`).join('');
  }

  /** People You May Know -> HTML. linkBase (optional) makes names link to the alumni profile page. */
  function suggestionsHTML(res, linkBase) {
    if (!res.suggestions || !res.suggestions.length) {
      return `<p style="color:var(--text-muted); font-size:0.9rem;">${esc(res.message || 'No recommendations yet.')}</p>`;
    }
    return res.suggestions.map(s => {
      const name = linkBase && s.role === 'alumni' ? `<a href="${linkBase}${encodeURIComponent(s.id)}">${esc(s.name)}</a>` : esc(s.name);
      return `
      <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:0.75rem; padding:0.75rem 0; border-bottom:1px solid var(--border);">
        <div>
          <strong>${name}</strong>
          <span style="color:var(--text-muted); font-size:0.8rem;"> ${s.role === 'alumni' ? esc(s.organization || 'Alumni') : 'Student'}</span>
          <div style="font-size:0.78rem; color:var(--text-muted); margin-top:0.2rem;">Mutual: ${s.mutualConnections.map(esc).join(', ')}</div>
          ${s.commonSkills.length ? `<div class="tag-cloud" style="margin-top:0.35rem;">${chips(s.commonSkills, 'accent')}</div>` : ''}
        </div>
        <span class="tag" style="background:var(--secondary-light); color:var(--secondary); font-weight:700;">${s.mutualCount} mutual</span>
      </div>`;
    }).join('');
  }

  return { esc, pct, num, pathHTML, suggestionsHTML, matrixHTML, statCards, rankList, chips };
})();
