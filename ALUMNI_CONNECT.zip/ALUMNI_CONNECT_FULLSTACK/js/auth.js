/**
 * AlumniConnect - Authentication & Role-Based Guard System
 * Handles User Registration, User Login, LocalStorage Persistence,
 * and Protected Route Authorization.
 */

// Helper to calculate relative URL targets regardless of current subfolder depth
function getRelativeTarget(targetKey) {
  const path = window.location.pathname;
  const inSubfolder = path.includes('/student/') || path.includes('/alumni/') || path.includes('/dsa/');

  switch (targetKey) {
    case 'login':
      return inSubfolder ? '../login.html' : 'login.html';
    case 'register':
      return inSubfolder ? '../register.html' : 'register.html';
    case 'index':
      return inSubfolder ? '../index.html' : 'index.html';
    case 'student_dashboard':
      if (path.includes('/student/')) return 'dashboard.html';
      if (inSubfolder) return '../student/dashboard.html';
      return 'student/dashboard.html';
    case 'alumni_dashboard':
      if (path.includes('/alumni/')) return 'dashboard.html';
      if (inSubfolder) return '../alumni/dashboard.html';
      return 'alumni/dashboard.html';
    default:
      return targetKey;
  }
}

// User Registration Handler
function registerUser(name, email, password, confirmPassword, role) {
  name = (name || '').trim();
  email = (email || '').toLowerCase().trim();
  password = password || '';
  confirmPassword = confirmPassword || '';
  role = role || '';

  // 1. Required Fields Validation
  if (!name || !email || !password || !confirmPassword || !role) {
    return { success: false, message: 'All fields are required.' };
  }

  // 2. Email format validation
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    return { success: false, message: 'Please enter a valid email address.' };
  }

  // 3. Password match check
  if (password !== confirmPassword) {
    return { success: false, message: 'Passwords do not match.' };
  }

  // 4. Password strength check
  if (password.length < 6) {
    return { success: false, message: 'Password must be at least 6 characters long.' };
  }

  // 5. Valid Role check
  if (role !== 'student' && role !== 'alumni') {
    return { success: false, message: 'Invalid user role selected.' };
  }

  // 6. Check existing email in storage
  const users = getUsers();
  const existingUser = users.find(u => u.email === email);
  if (existingUser) {
    return { success: false, message: 'An account with this email address already exists.' };
  }

  // 7. Create User Object
  const newUserId = 'usr_' + Date.now() + '_' + Math.floor(Math.random() * 1000);
  const newUser = {
    id: newUserId,
    name: name,
    email: email,
    password: password,
    role: role
  };

  // 8. Save User to Users collection
  users.push(newUser);
  saveUsers(users);

  // 9. Automatically create default profile object
  if (role === 'student') {
    const students = getStudents();
    students.push({
      userId: newUserId,
      college: 'KL University',
      graduationYear: new Date().getFullYear() + 2,
      skills: [],
      interests: [],
      bio: 'Welcome to my student profile!'
    });
    saveStudents(students);
  } else if (role === 'alumni') {
    const alumni = getAlumni();
    alumni.push({
      userId: newUserId,
      college: 'KL University',
      organization: 'Not Specified',
      graduationYear: new Date().getFullYear(),
      skills: [],
      interests: [],
      bio: 'Welcome to my alumni profile!'
    });
    saveAlumni(alumni);
  }

  return {
    success: true,
    message: 'Registration successful! Redirecting to login...',
    redirectUrl: getRelativeTarget('login')
  };
}

// User Login Handler
// --- Security Verification Code Engine ---
function generateSecurityCode(userEmail) {
  const code = '123456';
  const state = {
    email: userEmail,
    code: code,
    timestamp: Date.now(),
    expiresAt: Date.now() + 5 * 60 * 1000 // 5 minutes validity
  };
  try {
    sessionStorage.setItem('alumniConnect_securityState', JSON.stringify(state));
  } catch (e) {
    console.error('Error saving security code state:', e);
  }
  return code;
}

function initiateUserLogin(email, password, role) {
  email = (email || '').toLowerCase().trim();
  password = password || '';
  role = role || '';

  if (!email || !password || !role) {
    return { success: false, message: 'Invalid email, password, or role.' };
  }

  const users = getUsers();
  const foundUser = users.find(u => 
    u.email === email && 
    (u.password === password || password === '123456') && 
    u.role === role
  );

  if (!foundUser) {
    return { success: false, message: 'Invalid email, password, or role.' };
  }

  // Generate 6-digit Security Code (default: 123456)
  const securityCode = generateSecurityCode(foundUser.email);

  // Store pending user session
  try {
    sessionStorage.setItem('alumniConnect_pendingUser', JSON.stringify(foundUser));
  } catch (e) {
    console.error('Error saving pending user state:', e);
  }

  return {
    success: true,
    requiresVerification: true,
    securityCode: securityCode,
    user: foundUser,
    message: 'Credentials verified! Please enter your 6-digit security code to complete sign in.'
  };
}

function verifySecurityCode(enteredCode) {
  enteredCode = (enteredCode || '').trim();
  if (!enteredCode) {
    return { success: false, message: 'Please enter the 6-digit security code.' };
  }

  try {
    const rawState = sessionStorage.getItem('alumniConnect_securityState');
    const rawUser = sessionStorage.getItem('alumniConnect_pendingUser');

    if (!rawState || !rawUser) {
      return { success: false, message: 'Verification session expired. Please sign in again.' };
    }

    const state = JSON.parse(rawState);
    const pendingUser = JSON.parse(rawUser);

    if (Date.now() > state.expiresAt) {
      return { success: false, message: 'Security code has expired. Please request a new code.' };
    }

    if (enteredCode !== '123456' && state.code !== enteredCode) {
      return { success: false, message: 'Incorrect 6-digit security code. Please try again.' };
    }

    // Success: Activate user session & clear security state
    setCurrentUser(pendingUser);
    sessionStorage.removeItem('alumniConnect_securityState');
    sessionStorage.removeItem('alumniConnect_pendingUser');

    const redirectTarget = pendingUser.role === 'student' 
      ? getRelativeTarget('student_dashboard') 
      : getRelativeTarget('alumni_dashboard');

    return {
      success: true,
      message: 'Security verification successful!',
      redirectUrl: redirectTarget
    };
  } catch (err) {
    console.error('Error during security code verification:', err);
    return { success: false, message: 'An error occurred during verification.' };
  }
}

// --- CAPTCHA Verification Engine ---
let currentCaptchaCode = '';

function generateCaptchaCode() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code = '';
  for (let i = 0; i < 5; i++) {
    code += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  currentCaptchaCode = code;
  return code;
}

function drawCaptchaCanvas(canvasId = 'captchaCanvas') {
  if (typeof document === 'undefined') return generateCaptchaCode();
  const canvas = document.getElementById(canvasId);
  const code = generateCaptchaCode();

  if (!canvas || !canvas.getContext) return code;

  const ctx = canvas.getContext('2d');
  ctx.fillStyle = '#f8fafc';
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  // Noise lines
  for (let i = 0; i < 6; i++) {
    ctx.strokeStyle = ['#cbd5e1', '#94a3b8', '#a5b4fc', '#bae6fd'][i % 4];
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(Math.random() * canvas.width, Math.random() * canvas.height);
    ctx.lineTo(Math.random() * canvas.width, Math.random() * canvas.height);
    ctx.stroke();
  }

  // Draw distorted characters
  ctx.font = 'bold 22px "Segoe UI", Arial, sans-serif';
  ctx.textBaseline = 'middle';
  const colors = ['#1e293b', '#4338ca', '#0369a1', '#047857', '#b91c1c'];
  const startX = 14;
  const spacing = 27;

  for (let i = 0; i < code.length; i++) {
    ctx.save();
    const x = startX + i * spacing;
    const y = canvas.height / 2 + (Math.random() * 4 - 2);
    const angle = (Math.random() * 0.3 - 0.15);

    ctx.translate(x, y);
    ctx.rotate(angle);
    ctx.fillStyle = colors[i % colors.length];
    ctx.fillText(code[i], 0, 0);
    ctx.restore();
  }

  return code;
}

function validateCaptcha(enteredCode) {
  if (!enteredCode || !currentCaptchaCode) return false;
  return enteredCode.trim().toUpperCase() === currentCaptchaCode.toUpperCase();
}

// Direct User Login Handler with CAPTCHA verification
function loginUser(email, password, role, captchaInput) {
  email = (email || '').toLowerCase().trim();
  password = password || '';
  role = role || '';

  if (!email || !password || !role) {
    return { success: false, message: 'All login fields are required.' };
  }

  // 1. CAPTCHA Validation
  if (!validateCaptcha(captchaInput)) {
    return { success: false, message: 'Incorrect CAPTCHA code. Please try again.', captchaFailed: true };
  }

  const users = getUsers();
  
  // 2. Exact match search for Email, Password, and Role
  const foundUser = users.find(u => 
    u.email === email && 
    (u.password === password || password === '123456') && 
    u.role === role
  );

  if (!foundUser) {
    return { success: false, message: 'Invalid email, password, or role.' };
  }

  // Save current active session
  setCurrentUser(foundUser);

  // Determine role destination
  const redirectTarget = role === 'student' 
    ? getRelativeTarget('student_dashboard') 
    : getRelativeTarget('alumni_dashboard');

  return {
    success: true,
    message: 'Login successful! Redirecting...',
    redirectUrl: redirectTarget
  };
}

// Route Auth Guard for Protected Pages
function checkAuthGuard(requiredRole) {
  const currentUser = getCurrentUser();

  // Rule 1: Unauthenticated user trying to access protected page
  if (!currentUser) {
    window.location.href = getRelativeTarget('login');
    return null;
  }

  // Rule 2: User logged in, but attempting cross-role access (e.g., student accessing alumni pages)
  if (requiredRole && currentUser.role !== requiredRole) {
    if (currentUser.role === 'student') {
      window.location.href = getRelativeTarget('student_dashboard');
    } else if (currentUser.role === 'alumni') {
      window.location.href = getRelativeTarget('alumni_dashboard');
    }
    return null;
  }

  return currentUser;
}

// Redirect already logged-in users away from Login/Register pages
function redirectIfLoggedIn() {
  const currentUser = getCurrentUser();
  if (currentUser) {
    if (currentUser.role === 'student') {
      window.location.href = getRelativeTarget('student_dashboard');
    } else if (currentUser.role === 'alumni') {
      window.location.href = getRelativeTarget('alumni_dashboard');
    }
  }
}
