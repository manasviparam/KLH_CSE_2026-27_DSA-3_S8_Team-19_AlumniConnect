/**
 * AlumniConnect - Seed Data & Application Initialization
 * Preloads realistic initial Alumni and Student records into LocalStorage
 * if they do not already exist.
 */

const SEED_USERS = [
  // Seed Alumni Users
  {
    id: 'user_alumni_101',
    name: 'Aarav Sharma',
    email: 'aarav.sharma@google.com',
    password: '123456',
    role: 'alumni'
  },
  {
    id: 'user_alumni_102',
    name: 'Priya Patel',
    email: 'priya.patel@microsoft.com',
    password: '123456',
    role: 'alumni'
  },
  {
    id: 'user_alumni_103',
    name: 'Rohan Mehta',
    email: 'rohan.mehta@amazon.com',
    password: '123456',
    role: 'alumni'
  },
  {
    id: 'user_alumni_104',
    name: 'Ananya Roy',
    email: 'ananya.roy@meta.com',
    password: '123456',
    role: 'alumni'
  },
  {
    id: 'user_alumni_105',
    name: 'Vikram Singh',
    email: 'vikram.singh@apple.com',
    password: '123456',
    role: 'alumni'
  },
  {
    id: 'user_alumni_106',
    name: 'Priya Verma',
    email: 'priya.verma@example.com',
    password: '123456',
    role: 'alumni'
  },
  {
    id: 'user_alumni_107',
    name: 'Neha Agarwal',
    email: 'neha.agarwal@uber.com',
    password: '123456',
    role: 'alumni'
  },
  {
    id: 'user_alumni_108',
    name: 'Sidharth Malhotra',
    email: 'sidharth.m@netflix.com',
    password: '123456',
    role: 'alumni'
  },
  {
    id: 'user_alumni_109',
    name: 'Arjun Nambiar',
    email: 'arjun.nambiar@adobe.com',
    password: '123456',
    role: 'alumni'
  },
  {
    id: 'user_alumni_110',
    name: 'Kavya Reddy',
    email: 'kavya.reddy@stripe.com',
    password: '123456',
    role: 'alumni'
  },

  // Seed Student Users
  {
    id: 'user_student_201',
    name: 'Rahul Verma',
    email: 'rahul@gmail.com',
    password: '123456',
    role: 'student'
  },
  {
    id: 'user_student_202',
    name: 'Sneha Gupta',
    email: 'sneha@gmail.com',
    password: '123456',
    role: 'student'
  },
  {
    id: 'user_student_203',
    name: 'Ishaan Sharma',
    email: 'ishaan@gmail.com',
    password: '123456',
    role: 'student'
  },
  {
    id: 'user_student_204',
    name: 'Tanvi Verma',
    email: 'tanvi@gmail.com',
    password: '123456',
    role: 'student'
  },
  {
    id: 'user_student_205',
    name: 'Aditya Kapoor',
    email: 'aditya@gmail.com',
    password: '123456',
    role: 'student'
  },
  {
    id: 'user_student_206',
    name: 'Riya Sen',
    email: 'riya@gmail.com',
    password: '123456',
    role: 'student'
  },
  {
    id: 'user_student_207',
    name: 'Devansh Joshi',
    email: 'devansh@gmail.com',
    password: '123456',
    role: 'student'
  }
];

const SEED_ALUMNI_PROFILES = [
  {
    userId: 'user_alumni_101',
    college: 'KL University',
    organization: 'Google',
    graduationYear: 2015,
    skills: ['DSA', 'Java', 'System Design', 'Cloud Computing', 'Go'],
    interests: ['Mentorship', 'Career Guidance', 'Competitive Programming'],
    bio: 'Senior Software Engineer at Google. Passionate about distributed systems, DSA problem solving, and helping juniors navigate Tech interviews.'
  },
  {
    userId: 'user_alumni_102',
    college: 'KL University',
    organization: 'Microsoft',
    graduationYear: 2016,
    skills: ['JavaScript', 'React', 'Node.js', 'System Design', 'Azure'],
    interests: ['Frontend Engineering', 'Open Source', 'Resume Reviews'],
    bio: 'Software Engineer II at Microsoft Cloud. Focused on web scale applications, frontend UI architecture, and tech mentoring.'
  },
  {
    userId: 'user_alumni_103',
    college: 'KL University',
    organization: 'Amazon',
    graduationYear: 2017,
    skills: ['Python', 'Machine Learning', 'AWS', 'DSA', 'Data Engineering'],
    interests: ['Data Science', 'AI Research', 'Mock Interviews'],
    bio: 'Applied Scientist at Amazon AWS. Working on large-scale machine learning models and predictive analytics.'
  },
  {
    userId: 'user_alumni_104',
    college: 'KL University',
    organization: 'Meta',
    graduationYear: 2018,
    skills: ['C++', 'Algorithms', 'Distributed Systems', 'Backend Dev'],
    interests: ['Algorithm Optimization', 'Internship Prep'],
    bio: 'Infrastructure Software Engineer at Meta. Competitive programmer with ICPC regional rank background.'
  },
  {
    userId: 'user_alumni_105',
    college: 'KL University',
    organization: 'Apple',
    graduationYear: 2019,
    skills: ['iOS Dev', 'Swift', 'System Design', 'Mobile Architecture'],
    interests: ['Mobile Applications', 'Career Transition', 'Product Design'],
    bio: 'Senior iOS Engineer at Apple. Building scalable mobile user experiences and mentoring aspiring app developers.'
  },
  {
    userId: 'user_alumni_106',
    college: 'KL University',
    organization: 'Tech Corp',
    graduationYear: 2020,
    skills: ['Java', 'Design System', 'Cloud Computing', 'Microservices'],
    interests: ['System Design', 'Tech Leadership', 'Mock Interviews'],
    bio: 'Software Engineer at Tech Corp. Passionate about high performance backend architecture and mentorship.'
  },
  {
    userId: 'user_alumni_107',
    college: 'KL University',
    organization: 'Uber',
    graduationYear: 2021,
    skills: ['Java', 'Kafka', 'Distributed Systems', 'Go', 'Kubernetes'],
    interests: ['Backend Systems', 'High Availability Architecture'],
    bio: 'Senior Backend Engineer at Uber. Building real-time location matching and routing services.'
  },
  {
    userId: 'user_alumni_108',
    college: 'KL University',
    organization: 'Netflix',
    graduationYear: 2022,
    skills: ['JavaScript', 'React', 'GraphQL', 'System Design', 'Node.js'],
    interests: ['UI/UX Systems', 'Streaming Infrastructure', 'Mentorship'],
    bio: 'UI Engineer at Netflix. Architecting seamless video streaming client experiences across devices.'
  },
  {
    userId: 'user_alumni_109',
    college: 'KL University',
    organization: 'Adobe',
    graduationYear: 2023,
    skills: ['C++', 'Graphics Programming', 'WebAssembly', 'Algorithms'],
    interests: ['Creative Tech', 'Compilers', 'Interview Prep'],
    bio: 'Software Development Engineer at Adobe Creative Cloud core engine team.'
  },
  {
    userId: 'user_alumni_110',
    college: 'KL University',
    organization: 'Stripe',
    graduationYear: 2024,
    skills: ['Python', 'Ruby', 'API Design', 'Financial Systems', 'SQL'],
    interests: ['Fintech Architecture', 'Open Source', 'Career Guidance'],
    bio: 'Platform Engineer at Stripe. Focused on developer payment APIs and global payout reliability.'
  }
];

const SEED_STUDENT_PROFILES = [
  {
    userId: 'user_student_201',
    college: 'KL University',
    graduationYear: 2025,
    skills: ['Java', 'Data Structures', 'HTML/CSS', 'JavaScript'],
    interests: ['Backend Development', 'Alumni Networking', 'Placement Prep'],
    bio: 'Pre-final year Computer Science undergraduate eager to connect with alumni for software engineering career advice.'
  },
  {
    userId: 'user_student_202',
    college: 'KL University',
    graduationYear: 2026,
    skills: ['Python', 'SQL', 'Web Development'],
    interests: ['Full Stack Development', 'Open Source', 'Internships'],
    bio: '3rd Year CSE student exploring full-stack development and competitive coding.'
  },
  {
    userId: 'user_student_203',
    college: 'KL University',
    graduationYear: 2027,
    skills: ['C++', 'DSA', 'Algorithms', 'System Design'],
    interests: ['Competitive Programming', 'Tech Internships'],
    bio: 'Competitive programmer and 3rd year student working on algorithm problem solving.'
  },
  {
    userId: 'user_student_204',
    college: 'KL University',
    graduationYear: 2028,
    skills: ['JavaScript', 'React', 'Node.js', 'MongoDB'],
    interests: ['Frontend Engineering', 'Open Source', 'Hackathons'],
    bio: 'Full stack enthusiast interested in web application design and React ecosystem.'
  },
  {
    userId: 'user_student_205',
    college: 'KL University',
    graduationYear: 2029,
    skills: ['Python', 'Machine Learning', 'PyTorch', 'Data Science'],
    interests: ['AI Research', 'Data Engineering'],
    bio: 'Passionate about deep learning models and data science applications.'
  },
  {
    userId: 'user_student_206',
    college: 'KL University',
    graduationYear: 2030,
    skills: ['Java', 'Android', 'Kotlin', 'Mobile Dev'],
    interests: ['Mobile Applications', 'UI Design'],
    bio: 'Android developer creating open source mobile apps and exploring mobile architecture.'
  },
  {
    userId: 'user_student_207',
    college: 'KL University',
    graduationYear: 2031,
    skills: ['Go', 'Docker', 'Kubernetes', 'Cloud'],
    interests: ['DevOps', 'Cloud Infrastructure'],
    bio: 'Cloud computing enthusiast practicing containerization and backend system scalability.'
  }
];

// Seed Data Initialization Routine
function initSeedData() {
  const usersRaw = localStorage.getItem(STORAGE_KEYS.USERS);
  const alumniRaw = localStorage.getItem(STORAGE_KEYS.ALUMNI);
  const studentsRaw = localStorage.getItem(STORAGE_KEYS.STUDENTS);

  if (!usersRaw) {
    saveUsers(SEED_USERS);
  } else {
    try {
      const parsedUsers = JSON.parse(usersRaw);
      let updated = false;

      // Ensure passwords are 123456
      parsedUsers.forEach(u => {
        if (u.password !== '123456') {
          u.password = '123456';
          updated = true;
        }
      });

      // Merge missing seed users into existing dataset
      SEED_USERS.forEach(seedUser => {
        if (!parsedUsers.some(u => u.id === seedUser.id || u.email === seedUser.email)) {
          parsedUsers.push(seedUser);
          updated = true;
        }
      });

      if (updated) saveUsers(parsedUsers);
    } catch (e) {
      console.error('Error updating users:', e);
    }
  }

  if (!alumniRaw) {
    saveAlumni(SEED_ALUMNI_PROFILES);
  } else {
    try {
      const parsedAlumni = JSON.parse(alumniRaw);
      let updated = false;
      SEED_ALUMNI_PROFILES.forEach(seedAlumni => {
        const existing = parsedAlumni.find(a => a.userId === seedAlumni.userId);
        if (!existing) {
          parsedAlumni.push(seedAlumni);
          updated = true;
        } else {
          // Synchronize college & batch to updated seed configuration
          if (existing.college !== 'KL University' || existing.graduationYear !== seedAlumni.graduationYear) {
            existing.college = 'KL University';
            existing.graduationYear = seedAlumni.graduationYear;
            updated = true;
          }
        }
      });
      if (updated) saveAlumni(parsedAlumni);
    } catch (e) {
      console.error('Error updating alumni:', e);
    }
  }

  if (!studentsRaw) {
    saveStudents(SEED_STUDENT_PROFILES);
  } else {
    try {
      const parsedStudents = JSON.parse(studentsRaw);
      let updated = false;
      SEED_STUDENT_PROFILES.forEach(seedStudent => {
        const existing = parsedStudents.find(s => s.userId === seedStudent.userId);
        if (!existing) {
          parsedStudents.push(seedStudent);
          updated = true;
        } else {
          // Synchronize college & batch to updated seed configuration
          if (existing.college !== 'KL University' || existing.graduationYear !== seedStudent.graduationYear) {
            existing.college = 'KL University';
            existing.graduationYear = seedStudent.graduationYear;
            updated = true;
          }
        }
      });
      if (updated) saveStudents(parsedStudents);
    } catch (e) {
      console.error('Error updating students:', e);
    }
  }
}


// Sample accepted / pending / declined connections for testing the graph features.
// Seeded ONCE (flag below) and only for pairs that have no record yet, so existing data is never
// overwritten or duplicated, and a connection the user later cancels is not brought back.
// Groups: a large connected network, two small separate groups (206 & 105, 207 & 107) and two alumni (109, 110) with none.
const SEED_CONNECTIONS_FLAG = 'alumniConnect_seedConnectionsV1';
const SEED_CONNECTIONS = [
  ['201', '101', 'accepted'], ['201', '106', 'accepted'],
  ['202', '102', 'accepted'], ['202', '103', 'accepted'],
  ['203', '101', 'accepted'], ['203', '104', 'accepted'], ['203', '102', 'accepted'],
  ['204', '102', 'accepted'], ['204', '108', 'accepted'],
  ['205', '103', 'accepted'],
  ['206', '105', 'accepted'],
  ['207', '107', 'accepted'],
  ['201', '103', 'pending'], ['202', '101', 'pending'],
  ['204', '105', 'rejected']
].map(([s, a, status]) => ({
  id: `conn_seed_${s}_${a}`,
  studentId: `user_student_${s}`,
  alumniId: `user_alumni_${a}`,
  status,
  message: 'Hi! I would like to connect with you on AlumniConnect.',
  createdAt: '2026-01-15T10:00:00.000Z'
}));

function initSeedConnections() {
  try {
    if (localStorage.getItem(SEED_CONNECTIONS_FLAG)) return;
    const users = getUsers();
    const connections = getConnections();
    let added = false;
    SEED_CONNECTIONS.forEach(seed => {
      const bothExist = users.some(u => u.id === seed.studentId) && users.some(u => u.id === seed.alumniId);
      const pairExists = connections.some(c => c.studentId === seed.studentId && c.alumniId === seed.alumniId);
      if (bothExist && !pairExists) { connections.push(seed); added = true; }
    });
    if (added) saveConnections(connections);
    localStorage.setItem(SEED_CONNECTIONS_FLAG, '1');
  } catch (e) {
    console.error('Error seeding connections:', e);
  }
}

// Auto-run seed initialization when data.js is loaded
document.addEventListener('DOMContentLoaded', () => {
  initSeedData();
  initSeedConnections();
});
