/**
 * AlumniConnect - API Client (Frontend -> Java Backend)
 *
 * The browser no longer runs any data-structure / graph algorithm.
 * All DSA logic (Dynamic Array, Trie + DFS, KMP, Aho-Corasick + BFS, Queue, Edit Distance,
 * LCS, Insertion Sort, Linear Search, Dijkstra, Floyd-Warshall, Bipartite Matching)
 * lives in the Java backend (backend/src/alumniconnect/...).
 *
 * localStorage stays the data source for the UI. Before a call this client pushes a snapshot of
 * users / profiles / connections to the Java server (POST /api/sync), then calls the algorithm.
 *
 * Requires storage.js (getUsers, getAlumni, getStudents, getConnections) to be loaded first.
 */
const API = (() => {
  // Same-origin when served by the Java server (http://localhost:8080); fall back when opened as a file.
  const BASE = window.location.protocol === 'file:' ? 'http://localhost:8080' : '';

  let lastPayload = null;
  let syncPromise = null;

  // ---------- localStorage snapshot ----------
  function buildSnapshot() {
    const users = typeof getUsers === 'function' ? getUsers() : [];
    const nameOf = (id, fallback) => (users.find(u => u.id === id) || {}).name || fallback;

    const alumni = (typeof getAlumni === 'function' ? getAlumni() : []).map(p => ({
      userId: p.userId,
      name: nameOf(p.userId, 'Alumni Member'),
      college: p.college || 'KL University',
      organization: p.organization || 'Tech Company',
      graduationYear: p.graduationYear || 2021,
      skills: p.skills || [],
      interests: p.interests || [],
      bio: p.bio || 'Alumni member on AlumniConnect.',
      department: p.department || '',   // optional
      industry: p.industry || ''         // optional
    }));

    const students = (typeof getStudents === 'function' ? getStudents() : []).map(p => ({
      userId: p.userId,
      name: nameOf(p.userId, 'Student Member'),
      college: p.college || 'KL University',
      graduationYear: p.graduationYear || 2026,
      skills: p.skills || [],
      interests: p.interests || [],
      bio: p.bio || 'Student member on AlumniConnect.',
      department: p.department || '',   // optional
      industry: p.industry || ''         // optional
    }));

    const connections = (typeof getConnections === 'function' ? getConnections() : []).map(c => ({
      id: c.id, studentId: c.studentId, alumniId: c.alumniId, status: c.status
    }));

    return { alumni, students, connections };
  }

  // ---------- low level ----------
  async function raw(method, path, bodyText) {
    let res;
    try {
      res = await fetch(BASE + path, {
        method,
        headers: bodyText !== undefined ? { 'Content-Type': 'application/json' } : undefined,
        body: bodyText
      });
    } catch (e) {
      const err = new Error('Java backend is not reachable. Start it with backend/run.bat (Windows) or backend/run.sh, then open http://localhost:8080');
      err.offline = true;
      throw err;
    }
    let data = null;
    try { data = await res.json(); } catch (e) { /* non-JSON */ }
    if (!res.ok) throw new Error((data && data.error) || ('Request failed (' + res.status + ')'));
    return data;
  }

  /** Push the current localStorage data to Java (skipped when nothing changed since the last push). */
  function sync(force) {
    const payload = JSON.stringify(buildSnapshot());
    if (!force && payload === lastPayload && syncPromise) return syncPromise;
    lastPayload = payload;
    syncPromise = raw('POST', '/api/sync', payload).catch(err => {
      lastPayload = null; syncPromise = null; throw err;
    });
    return syncPromise;
  }

  async function post(path, body) {
    await sync();
    return raw('POST', path, JSON.stringify(body || {}));
  }

  async function get(path, params) {
    await sync();
    const qs = params ? '?' + new URLSearchParams(params).toString() : '';
    return raw('GET', path + qs);
  }

  /** Stateless demo calls do not need the snapshot. */
  function postNoSync(path, body) {
    return raw('POST', path, JSON.stringify(body || {}));
  }

  /** Show a friendly message when the Java server is down (or any API error happens). */
  let lastReport = { msg: '', at: 0 };
  function report(err) {
    console.error(err);
    const now = Date.now();
    // avoid a toast on every keystroke while the server is down
    if (typeof showToast === 'function' && !(err.message === lastReport.msg && now - lastReport.at < 4000)) {
      showToast(err.message, 'danger');
    }
    lastReport = { msg: err.message, at: now };
    return err.message;
  }

  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }

  return {
    sync, report, esc,

    // ---- Directory: search / autocomplete / typo / similarity (Java DSA) ----
    search: (query, algorithm, filters, sortKey, sortDir) => post('/api/search', {
      query, algorithm,
      organization: filters.organization, graduationYear: filters.graduationYear,
      searchFields: filters.searchFields, sortKey, sortDir
    }),
    suggest: (q, max) => get('/api/suggest', { q, max: max || 6 }),
    typo: q => get('/api/typo', { q }),
    similar: (id, limit) => get('/api/similar', { id, limit: limit || 3 }),

    // ---- Graph algorithms (Java) ----
    graph: {
      path: (from, to) => get('/api/graph/path', { from, to }),               // Dijkstra
      network: () => get('/api/graph/network'),                                // Floyd-Warshall
      mentorMatch: capacity => get('/api/graph/mentor-match', { capacity: capacity || 1 }), // Bipartite matching
      recommend: (userId, limit) => get('/api/graph/recommend', { userId, limit: limit || 5 }), // People You May Know
      people: () => get('/api/graph/people')
    },

    // ---- Interactive DSA demos (dsa/how-it-works.html) ----
    dsa: {
      kmp: (text, pattern) => postNoSync('/api/dsa/kmp', { text, pattern }),
      naive: (text, pattern) => postNoSync('/api/dsa/naive', { text, pattern }),
      trieInsert: word => post('/api/dsa/trie/insert', { word }),
      trieSuggest: (prefix, max) => post('/api/dsa/trie/suggest', { prefix, max }),
      ahoCorasick: (text, keywords) => postNoSync('/api/dsa/ahocorasick', { text, keywords }),
      edit: (a, b) => postNoSync('/api/dsa/edit', { a, b }),
      lcs: (a, b) => postNoSync('/api/dsa/lcs', { a, b }),
      sort: numbers => postNoSync('/api/dsa/sort', { numbers }),
      linear: (items, target) => postNoSync('/api/dsa/linear', { items, target }),
      dynamic: (op, value) => postNoSync('/api/dsa/dynamic', { op, value }),
      queue: (op, value) => postNoSync('/api/dsa/queue', { op, value })
    }
  };
})();
