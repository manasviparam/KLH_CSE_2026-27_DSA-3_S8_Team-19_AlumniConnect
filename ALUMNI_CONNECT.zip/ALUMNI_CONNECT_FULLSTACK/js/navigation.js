/**
 * AlumniConnect - Navigation & UI Interactions
 * Manages sidebar drawer toggles, active page highlighting, and scroll animations.
 */

document.addEventListener('DOMContentLoaded', () => {
  setupSidebarNavigation();
  setupMobileMenu();
  setupScrollAnimations();
  updateNavbarState();
});

// Highlight active sidebar link based on current window location
function setupSidebarNavigation() {
  const sidebarLinks = document.querySelectorAll('.sidebar-link');
  if (sidebarLinks.length === 0) return;

  const currentPath = window.location.pathname.toLowerCase();

  sidebarLinks.forEach(link => {
    const href = link.getAttribute('href');
    if (!href) return;

    const hrefClean = href.toLowerCase().replace('../', '').replace('./', '');
    
    // Exact or trailing path match
    if (currentPath.endsWith(hrefClean)) {
      link.classList.add('active');
    } else {
      link.classList.remove('active');
    }
  });

  // Mobile Sidebar Drawer Toggle
  const sidebarToggleBtn = document.getElementById('sidebarToggleBtn');
  const appSidebar = document.querySelector('.app-sidebar');

  if (sidebarToggleBtn && appSidebar) {
    sidebarToggleBtn.addEventListener('click', () => {
      appSidebar.classList.toggle('open');
    });

    // Close sidebar when clicking outside on mobile overlay
    document.addEventListener('click', (e) => {
      if (appSidebar.classList.contains('open') && 
          !appSidebar.contains(e.target) && 
          !sidebarToggleBtn.contains(e.target)) {
        appSidebar.classList.remove('open');
      }
    });
  }
}

// Public Mobile Navbar Menu Toggle
function setupMobileMenu() {
  const hamburgerBtn = document.querySelector('.navbar .hamburger');
  const navbarContainer = document.querySelector('.navbar .container');

  if (hamburgerBtn && navbarContainer) {
    let mobileMenu = document.querySelector('.mobile-menu');
    if (!mobileMenu) {
      mobileMenu = document.createElement('div');
      mobileMenu.className = 'mobile-menu';
      
      const navLinks = document.querySelector('.nav-links');
      const navActions = document.querySelector('.nav-actions');
      
      if (navLinks) mobileMenu.appendChild(navLinks.cloneNode(true));
      if (navActions) mobileMenu.appendChild(navActions.cloneNode(true));
      
      navbarContainer.appendChild(mobileMenu);
    }

    hamburgerBtn.addEventListener('click', () => {
      mobileMenu.classList.toggle('open');
      if (mobileMenu.classList.contains('open')) {
        hamburgerBtn.setAttribute('aria-expanded', 'true');
      } else {
        hamburgerBtn.setAttribute('aria-expanded', 'false');
      }
    });
  }
}

// Scroll Animations using IntersectionObserver
function setupScrollAnimations() {
  const animatedElements = document.querySelectorAll('.fade-in-up');
  if (animatedElements.length === 0) return;

  const observerOptions = {
    root: null,
    rootMargin: '0px',
    threshold: 0.12
  };

  const observer = new IntersectionObserver((entries, observerInstance) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
        observerInstance.unobserve(entry.target);
      }
    });
  }, observerOptions);

  animatedElements.forEach(el => observer.observe(el));
}

// Update public header right-hand menu
function updateNavbarState() {
  const currentUser = typeof getCurrentUser === 'function' ? getCurrentUser() : null;
  const navActionsContainers = document.querySelectorAll('.nav-actions');

  if (navActionsContainers.length === 0) return;

  if (currentUser) {
    const isSubfolder = window.location.pathname.includes('/student/') || 
                        window.location.pathname.includes('/alumni/') || 
                        window.location.pathname.includes('/dsa/');
    const dashboardLink = currentUser.role === 'student'
      ? (isSubfolder ? '../student/dashboard.html' : 'student/dashboard.html')
      : (isSubfolder ? '../alumni/dashboard.html' : 'alumni/dashboard.html');

    const userMenuHTML = `
      <div class="user-menu">
        <span class="role-badge ${currentUser.role}">${currentUser.role}</span>
        <a href="${dashboardLink}" class="btn btn-secondary btn-sm">Dashboard</a>
        <button onclick="logout()" class="btn btn-outline btn-sm">Logout</button>
      </div>
    `;

    navActionsContainers.forEach(container => {
      container.innerHTML = userMenuHTML;
    });
  }
}
