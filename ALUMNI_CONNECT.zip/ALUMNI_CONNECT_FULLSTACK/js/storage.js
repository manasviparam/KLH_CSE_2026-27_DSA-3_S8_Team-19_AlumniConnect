/**
 * AlumniConnect - Centralized LocalStorage Storage System
 * Shared data persistence, session management, joined queries,
 * student-specific search history, and connection state machine.
 */

const STORAGE_KEYS = {
  USERS: 'alumniConnect_users',
  STUDENTS: 'alumniConnect_students',
  ALUMNI: 'alumniConnect_alumni',
  CURRENT_USER: 'alumniConnect_currentUser',
  CONNECTIONS: 'alumniConnect_connections',
  SEARCH_HISTORY: 'alumniConnect_searchHistory'
};

// --- Helper Utilities ---
function getItemJSON(key, defaultValue = []) {
  try {
    const data = localStorage.getItem(key);
    return data ? JSON.parse(data) : defaultValue;
  } catch (err) {
    console.error(`Error reading key ${key} from localStorage:`, err);
    return defaultValue;
  }
}

function setItemJSON(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (err) {
    console.error(`Error writing key ${key} to localStorage:`, err);
  }
}

// --- Users Storage ---
function getUsers() {
  return getItemJSON(STORAGE_KEYS.USERS, []);
}

function saveUsers(users) {
  setItemJSON(STORAGE_KEYS.USERS, users);
}

// --- Current User / Session Storage ---
function getCurrentUser() {
  return getItemJSON(STORAGE_KEYS.CURRENT_USER, null);
}

function setCurrentUser(user) {
  if (!user) {
    localStorage.removeItem(STORAGE_KEYS.CURRENT_USER);
  } else {
    setItemJSON(STORAGE_KEYS.CURRENT_USER, user);
  }
}

function logout(redirectPath) {
  localStorage.removeItem(STORAGE_KEYS.CURRENT_USER);
  const inSubfolder = window.location.pathname.includes('/student/') || 
                      window.location.pathname.includes('/alumni/') || 
                      window.location.pathname.includes('/dsa/');
  const target = redirectPath || (inSubfolder ? '../index.html' : 'index.html');
  window.location.href = target;
}

// --- Student Profiles & Joined Data ---
function getStudents() {
  return getItemJSON(STORAGE_KEYS.STUDENTS, []);
}

function saveStudents(students) {
  setItemJSON(STORAGE_KEYS.STUDENTS, students);
}

function getStudentProfileByUserId(userId) {
  const students = getStudents();
  return students.find(s => s.userId === userId) || null;
}

function getStudentWithUserData(userId) {
  const users = getUsers();
  const students = getStudents();

  const user = users.find(u => u.id === userId) || {};
  const profile = students.find(s => s.userId === userId) || {};

  return {
    userId: userId,
    name: user.name || 'Student Member',
    email: user.email || 'student@connect.com',
    role: 'Student',
    college: profile.college || 'KL University',
    graduationYear: profile.graduationYear || 2026,
    skills: profile.skills || [],
    interests: profile.interests || [],
    bio: profile.bio || 'Student member on AlumniConnect.'
  };
}

function updateStudentProfile(userId, updateData) {
  const users = getUsers();
  const students = getStudents();

  // Update user record
  const userIndex = users.findIndex(u => u.id === userId);
  if (userIndex !== -1 && updateData.name) {
    users[userIndex].name = updateData.name;
    saveUsers(users);

    const currentUser = getCurrentUser();
    if (currentUser && currentUser.id === userId) {
      currentUser.name = updateData.name;
      setCurrentUser(currentUser);
    }
  }

  // Update student profile record
  let studentIndex = students.findIndex(s => s.userId === userId);
  if (studentIndex === -1) {
    students.push({
      userId: userId,
      college: updateData.college || 'KL University',
      graduationYear: updateData.graduationYear ? Number(updateData.graduationYear) : 2026,
      skills: updateData.skills || [],
      interests: updateData.interests || [],
      bio: updateData.bio || ''
    });
  } else {
    students[studentIndex] = {
      ...students[studentIndex],
      college: updateData.college !== undefined ? updateData.college : students[studentIndex].college,
      graduationYear: updateData.graduationYear !== undefined ? Number(updateData.graduationYear) : (students[studentIndex].graduationYear || 2026),
      skills: updateData.skills !== undefined ? updateData.skills : students[studentIndex].skills,
      interests: updateData.interests !== undefined ? updateData.interests : students[studentIndex].interests,
      bio: updateData.bio !== undefined ? updateData.bio : students[studentIndex].bio
    };
  }
  saveStudents(students);
  return true;
}

// --- Alumni Profiles & Joined Data ---
function getAlumni() {
  return getItemJSON(STORAGE_KEYS.ALUMNI, []);
}

function saveAlumni(alumni) {
  setItemJSON(STORAGE_KEYS.ALUMNI, alumni);
}

function getAlumniWithUserData() {
  const users = getUsers();
  const alumniProfiles = getAlumni();

  return alumniProfiles.map(profile => {
    const user = users.find(u => u.id === profile.userId) || {};
    return {
      userId: profile.userId,
      name: user.name || 'Alumni Member',
      email: user.email || 'alumni@connect.com',
      college: profile.college || 'KL University',
      organization: profile.organization || 'Tech Company',
      graduationYear: profile.graduationYear || 2021,
      skills: profile.skills || [],
      interests: profile.interests || [],
      bio: profile.bio || 'Alumni member on AlumniConnect.'
    };
  });
}

function getAlumniById(userId) {
  const allAlumni = getAlumniWithUserData();
  return allAlumni.find(a => a.userId === userId) || null;
}

function updateAlumniProfile(userId, updateData) {
  const users = getUsers();
  const alumniList = getAlumni();

  const userIndex = users.findIndex(u => u.id === userId);
  if (userIndex !== -1 && updateData.name) {
    users[userIndex].name = updateData.name;
    saveUsers(users);

    const currentUser = getCurrentUser();
    if (currentUser && currentUser.id === userId) {
      currentUser.name = updateData.name;
      setCurrentUser(currentUser);
    }
  }

  let alumniIndex = alumniList.findIndex(a => a.userId === userId);
  if (alumniIndex === -1) {
    alumniList.push({
      userId: userId,
      college: updateData.college || '',
      organization: updateData.organization || '',
      graduationYear: updateData.graduationYear ? Number(updateData.graduationYear) : new Date().getFullYear(),
      skills: updateData.skills || [],
      interests: updateData.interests || [],
      bio: updateData.bio || ''
    });
  } else {
    alumniList[alumniIndex] = {
      ...alumniList[alumniIndex],
      college: updateData.college !== undefined ? updateData.college : alumniList[alumniIndex].college,
      organization: updateData.organization !== undefined ? updateData.organization : alumniList[alumniIndex].organization,
      graduationYear: updateData.graduationYear !== undefined ? Number(updateData.graduationYear) : alumniList[alumniIndex].graduationYear,
      skills: updateData.skills !== undefined ? updateData.skills : alumniList[alumniIndex].skills,
      interests: updateData.interests !== undefined ? updateData.interests : alumniList[alumniIndex].interests,
      bio: updateData.bio !== undefined ? updateData.bio : alumniList[alumniIndex].bio
    };
  }
  saveAlumni(alumniList);
  return true;
}

function calculateAlumniProfileCompletion(userId) {
  const alumni = getAlumniById(userId);
  if (!alumni) return 0;

  const fields = [
    alumni.name,
    alumni.email,
    alumni.college,
    alumni.organization,
    alumni.graduationYear,
    Array.isArray(alumni.skills) && alumni.skills.length > 0 ? true : '',
    Array.isArray(alumni.interests) && alumni.interests.length > 0 ? true : '',
    alumni.bio
  ];

  const filledCount = fields.filter(f => f && String(f).trim() !== '' && String(f) !== 'Not Specified').length;
  return Math.round((filledCount / fields.length) * 100);
}

// --- Connections System (Shared Data Source) ---
function getConnections() {
  return getItemJSON(STORAGE_KEYS.CONNECTIONS, []);
}

function saveConnections(connections) {
  setItemJSON(STORAGE_KEYS.CONNECTIONS, connections);
}

function sendConnectionRequest(studentId, alumniId, message = '') {
  const connections = getConnections();
  
  const existing = connections.find(c => c.studentId === studentId && c.alumniId === alumniId);
  if (existing) {
    if (existing.status === 'pending') {
      return { success: false, message: 'A request is already pending with this alumni.' };
    } else if (existing.status === 'accepted') {
      return { success: false, message: 'You are already connected with this alumni.' };
    }
  }

  const newConn = {
    id: 'conn_' + Date.now() + '_' + Math.floor(Math.random() * 1000),
    studentId: studentId,
    alumniId: alumniId,
    status: 'pending',
    message: message || 'Hi! I would like to connect with you on AlumniConnect.',
    createdAt: new Date().toISOString()
  };

  connections.push(newConn);
  saveConnections(connections);
  return { success: true, connection: newConn };
}

function getConnectionStatus(studentId, alumniId) {
  const connections = getConnections();
  const conn = connections.find(c => c.studentId === studentId && c.alumniId === alumniId);
  return conn ? conn.status : 'none';
}

function getStudentConnections(studentId) {
  const connections = getConnections();
  const allAlumni = getAlumniWithUserData();

  return connections
    .filter(c => c.studentId === studentId)
    .map(c => {
      const alumni = allAlumni.find(a => a.userId === c.alumniId) || {};
      return {
        ...c,
        alumniName: alumni.name || 'Alumni Member',
        alumniOrg: alumni.organization || 'Company',
        alumniCollege: alumni.college || 'KL University',
        alumniGraduationYear: alumni.graduationYear || 2020,
        alumniSkills: alumni.skills || []
      };
    });
}

function getAlumniConnectionRequests(alumniId) {
  const connections = getConnections();
  return connections
    .filter(c => c.alumniId === alumniId && c.status === 'pending')
    .map(c => {
      const student = getStudentWithUserData(c.studentId);
      return {
        ...c,
        studentName: student.name,
        studentEmail: student.email,
        studentCollege: student.college,
        studentGraduationYear: student.graduationYear,
        studentSkills: student.skills,
        studentInterests: student.interests,
        studentBio: student.bio
      };
    });
}

function getAlumniConnections(alumniId) {
  const connections = getConnections();
  return connections
    .filter(c => c.alumniId === alumniId && c.status === 'accepted')
    .map(c => {
      const student = getStudentWithUserData(c.studentId);
      return {
        ...c,
        studentName: student.name,
        studentEmail: student.email,
        studentCollege: student.college,
        studentGraduationYear: student.graduationYear,
        studentSkills: student.skills,
        studentInterests: student.interests,
        studentBio: student.bio
      };
    });
}

function respondToConnectionRequest(requestId, newStatus) {
  const connections = getConnections();
  const index = connections.findIndex(c => c.id === requestId);
  if (index !== -1) {
    connections[index].status = newStatus;
    saveConnections(connections);
    return true;
  }
  return false;
}

function cancelConnectionRequest(requestId) {
  let connections = getConnections();
  connections = connections.filter(c => c.id !== requestId);
  saveConnections(connections);
  return true;
}

// --- Student-Specific Search History Storage ---
function getStudentSearchHistory(studentId) {
  if (!studentId) return [];
  const history = getItemJSON(STORAGE_KEYS.SEARCH_HISTORY, []);
  return history.filter(item => item.studentId === studentId);
}

function addStudentSearchHistory(studentId, query, matchCount, algorithmUsed) {
  if (!studentId || !query || query.trim() === '') return;
  const history = getItemJSON(STORAGE_KEYS.SEARCH_HISTORY, []);
  
  const newItem = {
    id: 'search_' + Date.now(),
    studentId: studentId,
    query: query.trim(),
    matchCount: matchCount,
    algorithm: algorithmUsed,
    timestamp: new Date().toLocaleString()
  };

  // Prepend new search for this student, keep max 10 recent searches per student
  const otherStudentHistory = history.filter(item => item.studentId !== studentId);
  const myHistory = history.filter(item => item.studentId === studentId && item.query.toLowerCase() !== query.trim().toLowerCase());
  
  const updatedMyHistory = [newItem, ...myHistory].slice(0, 10);
  setItemJSON(STORAGE_KEYS.SEARCH_HISTORY, [...newItemList(updatedMyHistory, otherStudentHistory)]);
}

function newItemList(myHistory, otherHistory) {
  return [...myHistory, ...otherHistory];
}

function clearStudentSearchHistory(studentId) {
  if (!studentId) return;
  const history = getItemJSON(STORAGE_KEYS.SEARCH_HISTORY, []);
  const remaining = history.filter(item => item.studentId !== studentId);
  setItemJSON(STORAGE_KEYS.SEARCH_HISTORY, remaining);
}
