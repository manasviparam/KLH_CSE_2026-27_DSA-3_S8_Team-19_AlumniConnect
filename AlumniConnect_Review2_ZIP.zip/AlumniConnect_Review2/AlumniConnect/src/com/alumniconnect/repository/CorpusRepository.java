package com.alumniconnect.repository;

import com.alumniconnect.model.AlumniRecord;
import com.alumniconnect.util.DynamicArray;
import com.alumniconnect.util.TextOps;
import com.alumniconnect.util.Trie;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/**
 * CorpusRepository
 * ----------------
 * Owns the on-disk vocabulary that feeds the autocomplete Trie: a
 * hand-curated base corpus (data/corpus.txt) of common skill/interest
 * terms, merged in memory with every name/skill/interest already in the
 * live AlumniRepository. The file itself is MAINTAINED going forward --
 * any genuinely new term typed in via "Add Alumni/Student Record" gets
 * appended to it, so it grows across runs instead of resetting each time.
 *
 * File I/O here (BufferedReader/BufferedWriter) is a plain I/O boundary,
 * the same exception already made for Scanner elsewhere in this project --
 * no matching, dedup, or tokenizing decision is delegated to it. Every
 * actual decision is hand-built below, using DynamicArray + TextOps.
 */
public class CorpusRepository {

    private static final String CORPUS_PATH = "data" + File.separator + "corpus.txt";

    private final DynamicArray<String> terms = new DynamicArray<>();
    private final Trie trie = new Trie();

    /** Loads the base corpus file from disk (if present) into memory + the Trie. */
    public void load() {
        File file = new File(CORPUS_PATH);
        if (!file.exists()) return;
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String term = TextOps.trim(line);
                if (term.length() > 0) addInMemory(term);
            }
        } catch (IOException e) {
            System.out.println("(corpus file could not be read -- continuing without it)");
        }
    }

    /** Merges every name/skill/interest already in the repository into the corpus (in memory only). */
    public void mergeFromRepository(AlumniRepository repo) {
        DynamicArray<AlumniRecord> all = repo.getAll();
        for (int i = 0; i < all.size(); i++) {
            mergeFromRecordInMemory(all.get(i));
        }
    }

    /** Adds every name/skill/interest term from a newly added record, persisting new ones to disk. */
    public void addRecordTerms(AlumniRecord rec) {
        addAndPersist(rec.getName());
        DynamicArray<String> skills = rec.getSkills();
        for (int i = 0; i < skills.size(); i++) addAndPersist(skills.get(i));
        DynamicArray<String> interests = rec.getInterests();
        for (int i = 0; i < interests.size(); i++) addAndPersist(interests.get(i));
    }

    public Trie getTrie() {
        return trie;
    }

    // ---------------------------------------------------------------

    private void mergeFromRecordInMemory(AlumniRecord rec) {
        addInMemory(rec.getName());
        DynamicArray<String> skills = rec.getSkills();
        for (int i = 0; i < skills.size(); i++) addInMemory(skills.get(i));
        DynamicArray<String> interests = rec.getInterests();
        for (int i = 0; i < interests.size(); i++) addInMemory(interests.get(i));
    }

    private void addInMemory(String term) {
        if (containsIgnoreCase(term)) return;
        terms.add(term);
        trie.insert(term);
    }

    private void addAndPersist(String term) {
        if (containsIgnoreCase(term)) return;
        addInMemory(term);
        persist(term);
    }

    private void persist(String term) {
        File file = new File(CORPUS_PATH);
        File parent = file.getParentFile();
        if (parent != null && !parent.exists()) parent.mkdirs();
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file, true))) {
            writer.write(term);
            writer.newLine();
        } catch (IOException e) {
            System.out.println("(could not save \"" + term + "\" to the corpus file)");
        }
    }

    private boolean containsIgnoreCase(String term) {
        for (int i = 0; i < terms.size(); i++) {
            if (TextOps.equalsIgnoreCase(terms.get(i), term)) return true;
        }
        return false;
    }
}
