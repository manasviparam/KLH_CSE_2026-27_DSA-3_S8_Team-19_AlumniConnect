package com.alumniconnect.repository;

import com.alumniconnect.util.DynamicArray;

/**
 * DataSeeder
 * ----------
 * Preloads a handful of sample alumni/student/mentor records so the
 * repository, search, fuzzy search, and similarity features all have
 * something to demonstrate on immediately. Add more via the menu at runtime.
 */
public class DataSeeder {

    private static DynamicArray<String> list(String... items) {
        DynamicArray<String> arr = new DynamicArray<>();
        for (String s : items) arr.add(s);
        return arr;
    }

    public static void seed(AlumniRepository repo) {
        repo.addRecord(
                "Ananya Rao", "Alumni", "Google", 2021,
                list("Java", "React", "System Design", "DSA"),
                list("Mentoring", "Open Source", "Competitive Programming"),
                "Backend engineer at Google, loves mentoring juniors in DSA and system design."
        );

        repo.addRecord(
                "Rahul Menon", "Alumni", "Microsoft", 2020,
                list("Python", "Machine Learning", "Cloud", "Azure"),
                list("AI Research", "Reading", "Mentoring"),
                "ML engineer at Microsoft working on cloud AI services, enjoys research and mentoring."
        );

        repo.addRecord(
                "Sneha Iyer", "Student", "KL University", 2026,
                list("React", "Node.js", "MongoDB", "JavaScript"),
                list("Web Development", "Hackathons", "UI Design"),
                "Final-year CSE student building full stack web apps and competing in hackathons."
        );

        repo.addRecord(
                "Kiran Kumar", "Mentor", "Amazon", 2018,
                list("Java", "AWS", "System Design", "Leadership"),
                list("Mentoring", "Placements", "Public Speaking"),
                "Senior SDE at Amazon focused on system design mentoring and placement guidance."
        );

        repo.addRecord(
                "Divya Prasad", "Student", "KL University", 2027,
                list("Python", "Data Analysis", "Pandas", "SQL"),
                list("Data Science", "Reading", "Open Source"),
                "Second-year student exploring data analysis and machine learning fundamentals."
        );
    }
}
