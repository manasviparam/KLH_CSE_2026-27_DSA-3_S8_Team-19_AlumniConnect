package com.alumniconnect.repository;

import com.alumniconnect.model.AlumniRecord;
import com.alumniconnect.util.DynamicArray;

/**
 * AlumniRepository
 * ----------------
 * CONCEPT: "Repository Creation" (mirrors Practical Session 1 of the handout:
 * "Corpus Loading and Article Repository Creation for TextHack").
 *
 * In TextHack, the repository loads and stores the article corpus that every
 * later query (search, similarity, flow, etc.) operates on. In AlumniConnect,
 * this class plays exactly that role: it is the central in-memory repository
 * that stores every alumni/student/mentor record and hands out the record
 * set to every downstream algorithm (pattern matching, fuzzy search,
 * similarity engine).
 *
 * Storage is a hand-built DynamicArray<AlumniRecord> — no java.util
 * collections — consistent with the engine constraint in the handout.
 */
public class AlumniRepository {

    private DynamicArray<AlumniRecord> records;
    private int nextId;

    public AlumniRepository() {
        records = new DynamicArray<>();
        nextId = 1;
    }

    /** Adds a new record to the repository and auto-assigns its ID. */
    public AlumniRecord addRecord(String name, String role, String organization,
                                   int graduationYear, DynamicArray<String> skills,
                                   DynamicArray<String> interests, String bio) {
        AlumniRecord record = new AlumniRecord(nextId, name, role, organization,
                graduationYear, skills, interests, bio);
        records.add(record);
        nextId++;
        return record;
    }

    public DynamicArray<AlumniRecord> getAll() {
        return records;
    }

    public AlumniRecord getById(int id) {
        for (int i = 0; i < records.size(); i++) {
            if (records.get(i).getId() == id) return records.get(i);
        }
        return null;
    }

    public int size() {
        return records.size();
    }

    public boolean isEmpty() {
        return records.isEmpty();
    }
}
