package com.alumniconnect.util;

/**
 * TextOps
 * -------
 * Hand-built replacements for the Java standard-library string/character/
 * number helpers used elsewhere in the project (Character.isLetterOrDigit,
 * String.toLowerCase, String.equalsIgnoreCase, String.trim, Integer.parseInt,
 * Math.min/max, String.format). Every method here works character-by-character
 * or digit-by-digit instead of delegating to a built-in that already does
 * the work.
 *
 * Boundary note: java.lang.String itself (and StringBuilder as a growable
 * text buffer) are kept, since Java has no way to hold text without them and
 * they perform no algorithmic work on their own -- charAt()/length()/append()
 * are just character access and storage, not logic. Everything that actually
 * *decides* something (case conversion, comparison, parsing, min/max,
 * padding/formatting) is written here from scratch.
 */
public class TextOps {

    // ---------------- character checks ----------------

    public static boolean isLetterOrDigit(char c) {
        return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9');
    }

    public static boolean isDigit(char c) {
        return c >= '0' && c <= '9';
    }

    private static boolean isWhitespace(char c) {
        return c == ' ' || c == '\t' || c == '\n' || c == '\r';
    }

    private static char toLowerChar(char c) {
        if (c >= 'A' && c <= 'Z') {
            return (char) (c + 32);
        }
        return c;
    }

    // ---------------- string transforms ----------------

    public static String toLower(String s) {
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            result.append(toLowerChar(s.charAt(i)));
        }
        return result.toString();
    }

    public static boolean equalsIgnoreCase(String a, String b) {
        if (a == null || b == null) return a == b;
        if (a.length() != b.length()) return false;
        for (int i = 0; i < a.length(); i++) {
            if (toLowerChar(a.charAt(i)) != toLowerChar(b.charAt(i))) return false;
        }
        return true;
    }

    /** Strips leading/trailing whitespace by scanning from both ends, building the result manually. */
    public static String trim(String s) {
        int start = 0;
        int end = s.length() - 1;
        while (start <= end && isWhitespace(s.charAt(start))) start++;
        while (end >= start && isWhitespace(s.charAt(end))) end--;

        StringBuilder result = new StringBuilder();
        for (int i = start; i <= end; i++) {
            result.append(s.charAt(i));
        }
        return result.toString();
    }

    /** Pads a string on the right with spaces until it reaches the given width. */
    public static String padRight(String s, int width) {
        StringBuilder sb = new StringBuilder(s);
        while (sb.length() < width) sb.append(' ');
        return sb.toString();
    }

    // ---------------- numbers ----------------

    public static int min(int a, int b) {
        return a < b ? a : b;
    }

    public static int min3(int a, int b, int c) {
        return min(min(a, b), c);
    }

    public static int max(int a, int b) {
        return a > b ? a : b;
    }

    /** Converts a non-negative int to its decimal string, digit by digit. */
    public static String intToString(int value) {
        if (value == 0) return "0";
        boolean negative = value < 0;
        int v = negative ? -value : value;

        StringBuilder digits = new StringBuilder();
        while (v > 0) {
            int digit = v % 10;
            digits.append((char) ('0' + digit));
            v = v / 10;
        }
        if (negative) digits.append('-');

        // reverse manually
        StringBuilder result = new StringBuilder();
        for (int i = digits.length() - 1; i >= 0; i--) {
            result.append(digits.charAt(i));
        }
        return result.toString();
    }

    /** Zero-pads a non-negative int on the left to the given width. */
    public static String padLeftZero(int value, int width) {
        String s = intToString(value);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < width - s.length(); i++) sb.append('0');
        sb.append(s);
        return sb.toString();
    }

    /**
     * Parses a (possibly negative) integer from a string by walking its
     * digits and accumulating the value manually. Throws NumberFormatException
     * on anything that isn't a valid integer, matching the caller's existing
     * catch blocks.
     */
    public static int parseInt(String s) {
        String t = trim(s);
        if (t.length() == 0) {
            throw new NumberFormatException("empty input");
        }
        int i = 0;
        boolean negative = false;
        if (t.charAt(0) == '-' || t.charAt(0) == '+') {
            negative = t.charAt(0) == '-';
            i = 1;
        }
        if (i >= t.length()) {
            throw new NumberFormatException("no digits in: " + s);
        }
        int value = 0;
        for (; i < t.length(); i++) {
            char c = t.charAt(i);
            if (!isDigit(c)) {
                throw new NumberFormatException("invalid character in: " + s);
            }
            value = value * 10 + (c - '0');
        }
        return negative ? -value : value;
    }

    /** Formats a 0..1 (or any small non-negative) double to 2 decimal places, no built-in formatter. */
    public static String formatDecimal2(double value) {
        int scaled = (int) (value * 100 + 0.5); // manual rounding
        int whole = scaled / 100;
        int frac = scaled % 100;
        StringBuilder sb = new StringBuilder();
        sb.append(intToString(whole)).append('.');
        if (frac < 10) sb.append('0');
        sb.append(intToString(frac));
        return sb.toString();
    }
}
