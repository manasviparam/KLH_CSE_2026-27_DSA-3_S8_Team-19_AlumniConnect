package com.alumniconnect.util;

/**
 * DynamicArray<T>
 * ----------------
 * A hand-built, generic, resizable array — the storage backbone of the
 * whole AlumniConnect repository engine.
 *
 * WHY THIS EXISTS:
 * The DSA-3 handout's core constraint (carried over from DSA-1/DSA-2) is
 * that java.util.* is forbidden inside the "engine" — students must
 * hand-build every data structure and algorithm themselves rather than
 * lean on ArrayList / HashMap / Collections. This class is our
 * hand-built replacement for java.util.ArrayList<T>.
 *
 * It supports the classic dynamic-array behaviour:
 *   - O(1) amortized append (doubling strategy when full)
 *   - O(1) random access by index
 *   - O(n) linear scan / search (used heavily by the algorithms package)
 */
public class DynamicArray<T> {

    private Object[] data;
    private int size;
    private static final int DEFAULT_CAPACITY = 8;

    public DynamicArray() {
        data = new Object[DEFAULT_CAPACITY];
        size = 0;
    }

    public DynamicArray(int initialCapacity) {
        data = new Object[Math.max(1, initialCapacity)];
        size = 0;
    }

    /** Appends an item, growing the backing array (doubling) if full. */
    public void add(T item) {
        if (size == data.length) {
            grow();
        }
        data[size] = item;
        size++;
    }

    private void grow() {
        Object[] newData = new Object[data.length * 2];
        for (int i = 0; i < data.length; i++) {
            newData[i] = data[i];
        }
        data = newData;
    }

    @SuppressWarnings("unchecked")
    public T get(int index) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException("Index: " + index + ", Size: " + size);
        }
        return (T) data[index];
    }

    public void set(int index, T item) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException("Index: " + index + ", Size: " + size);
        }
        data[index] = item;
    }

    /** Removes the element at index, shifting subsequent elements left (O(n)). */
    public void removeAt(int index) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException("Index: " + index + ", Size: " + size);
        }
        for (int i = index; i < size - 1; i++) {
            data[i] = data[i + 1];
        }
        data[size - 1] = null;
        size--;
    }

    public int size() {
        return size;
    }

    public boolean isEmpty() {
        return size == 0;
    }
}
