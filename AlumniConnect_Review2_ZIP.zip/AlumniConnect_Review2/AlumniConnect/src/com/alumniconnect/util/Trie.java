package com.alumniconnect.util;

/**
 * Trie
 * ----
 * Hand-built prefix tree used for live autocomplete suggestions. Each node
 * stores its children as a pair of parallel DynamicArrays (character ->
 * child node) instead of java.util.HashMap, consistent with the rest of
 * this project's "no java.util collections" rule -- lookups here are a
 * short linear scan per node (fine at this vocabulary size), the same
 * trade-off DynamicArray itself makes.
 *
 * Two operations only: insert() to add a word, and wordsWithPrefix() to
 * collect every stored word starting with a given prefix (a plain
 * depth-first walk from the prefix's node) -- exactly what autocomplete
 * needs.
 */
public class Trie {

    private static class Node {
        DynamicArray<Character> childChars = new DynamicArray<>();
        DynamicArray<Node> childNodes = new DynamicArray<>();
        boolean isWord;
    }

    private final Node root = new Node();

    private Node getChild(Node node, char c) {
        for (int i = 0; i < node.childChars.size(); i++) {
            if (node.childChars.get(i) == c) return node.childNodes.get(i);
        }
        return null;
    }

    private Node getOrAddChild(Node node, char c) {
        Node existing = getChild(node, c);
        if (existing != null) return existing;
        Node created = new Node();
        node.childChars.add(c);
        node.childNodes.add(created);
        return created;
    }

    /** Inserts a word (case-insensitive; stored/matched in lowercase). */
    public void insert(String word) {
        if (word == null || word.length() == 0) return;
        String w = TextOps.toLower(word);
        Node cur = root;
        for (int i = 0; i < w.length(); i++) {
            cur = getOrAddChild(cur, w.charAt(i));
        }
        cur.isWord = true;
    }

    public boolean contains(String word) {
        Node node = walk(word);
        return node != null && node.isWord;
    }

    private Node walk(String prefix) {
        if (prefix == null) return null;
        String p = TextOps.toLower(prefix);
        Node cur = root;
        for (int i = 0; i < p.length(); i++) {
            cur = getChild(cur, p.charAt(i));
            if (cur == null) return null;
        }
        return cur;
    }

    /**
     * Collects up to maxResults stored words that start with prefix
     * (case-insensitive), via a depth-first walk of the prefix's subtree.
     */
    public DynamicArray<String> wordsWithPrefix(String prefix, int maxResults) {
        DynamicArray<String> results = new DynamicArray<>();
        if (prefix == null || prefix.length() == 0) return results;
        Node start = walk(prefix);
        if (start == null) return results;
        collect(start, new StringBuilder(TextOps.toLower(prefix)), results, maxResults);
        return results;
    }

    private void collect(Node node, StringBuilder soFar, DynamicArray<String> results, int maxResults) {
        if (results.size() >= maxResults) return;
        if (node.isWord) results.add(soFar.toString());
        for (int i = 0; i < node.childChars.size() && results.size() < maxResults; i++) {
            soFar.append(node.childChars.get(i));
            collect(node.childNodes.get(i), soFar, results, maxResults);
            soFar.deleteCharAt(soFar.length() - 1);
        }
    }
}
