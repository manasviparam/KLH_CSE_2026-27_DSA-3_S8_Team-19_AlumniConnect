package com.alumniconnect.algorithms;

import com.alumniconnect.model.AlumniRecord;
import com.alumniconnect.repository.AlumniRepository;
import com.alumniconnect.util.DynamicArray;
import com.alumniconnect.util.TextOps;

/**
 * AhoCorasick
 * -----------
 * Hand-built Aho-Corasick multi-pattern automaton: a trie of every search
 * keyword plus failure links (classic BFS construction), letting a whole
 * record be scanned ONCE to find which of several keywords it contains,
 * instead of re-scanning the record once per keyword the way PatternMatcher's
 * single-pattern KMP would. This is what powers multi-keyword search (typing
 * several terms at once, e.g. "java react mentoring") in Main's Search menu.
 *
 * Children are stored per-node as parallel DynamicArrays (character -> child),
 * and the BFS queue used to build failure links is a plain DynamicArray read
 * with an advancing head index -- no java.util collections, same rule as the
 * rest of the project.
 */
public class AhoCorasick {

    private static class Node {
        DynamicArray<Character> childChars = new DynamicArray<>();
        DynamicArray<Node> childNodes = new DynamicArray<>();
        Node fail;
        DynamicArray<String> output = new DynamicArray<>();
    }

    private final Node root = new Node();

    private AhoCorasick() {
    }

    private Node getChild(Node node, char c) {
        for (int i = 0; i < node.childChars.size(); i++) {
            if (node.childChars.get(i) == c) return node.childNodes.get(i);
        }
        return null;
    }

    private Node getOrAddChild(Node node, char c) {
        Node existing = getChild(node, c);
        if (existing != null) return existing;
        Node created = new Node();
        node.childChars.add(c);
        node.childNodes.add(created);
        return created;
    }

    private void insert(String pattern) {
        Node cur = root;
        for (int i = 0; i < pattern.length(); i++) {
            cur = getOrAddChild(cur, pattern.charAt(i));
        }
        cur.output.add(pattern);
    }

    /** Classic BFS failure-link construction, using a DynamicArray as a FIFO queue. */
    private void buildFailureLinks() {
        DynamicArray<Node> queue = new DynamicArray<>();
        int head = 0;

        for (int i = 0; i < root.childNodes.size(); i++) {
            root.childNodes.get(i).fail = root;
            queue.add(root.childNodes.get(i));
        }

        while (head < queue.size()) {
            Node current = queue.get(head);
            head++;
            for (int i = 0; i < current.childChars.size(); i++) {
                char c = current.childChars.get(i);
                Node child = current.childNodes.get(i);

                Node f = current.fail;
                while (f != null && getChild(f, c) == null) {
                    f = f.fail;
                }
                child.fail = (f == null) ? root : getChild(f, c);
                if (child.fail == child) child.fail = root;

                for (int k = 0; k < child.fail.output.size(); k++) {
                    child.output.add(child.fail.output.get(k));
                }
                queue.add(child);
            }
        }
    }

    /** Builds an automaton matching all given patterns (case-insensitive). */
    public static AhoCorasick build(DynamicArray<String> patterns) {
        AhoCorasick ac = new AhoCorasick();
        for (int i = 0; i < patterns.size(); i++) {
            String p = TextOps.toLower(patterns.get(i));
            if (p.length() > 0) ac.insert(p);
        }
        ac.buildFailureLinks();
        return ac;
    }

    /** Scans text once; returns the distinct patterns found in it (case-insensitive). */
    public DynamicArray<String> findMatches(String text) {
        DynamicArray<String> found = new DynamicArray<>();
        String t = TextOps.toLower(text);
        Node cur = root;

        for (int i = 0; i < t.length(); i++) {
            char c = t.charAt(i);
            while (cur != root && getChild(cur, c) == null) {
                cur = cur.fail;
            }
            Node next = getChild(cur, c);
            cur = (next != null) ? next : root;

            for (int k = 0; k < cur.output.size(); k++) {
                String pattern = cur.output.get(k);
                if (!contains(found, pattern)) found.add(pattern);
            }
        }
        return found;
    }

    private static boolean contains(DynamicArray<String> list, String value) {
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).equals(value)) return true;
        }
        return false;
    }

    // ---------------------------------------------------------------
    // Domain-level multi-keyword search
    // ---------------------------------------------------------------

    public static class MultiMatch {
        public AlumniRecord record;
        public DynamicArray<String> matchedKeywords;
        public MultiMatch(AlumniRecord record, DynamicArray<String> matchedKeywords) {
            this.record = record;
            this.matchedKeywords = matchedKeywords;
        }
    }

    /**
     * Searches every record for however many of `keywords` it contains
     * (each record scanned once), keeping only records with at least one
     * match, sorted by descending number of matched keywords (hand-built
     * insertion sort, same style as SimilarityEngine/FuzzySearch).
     */
    public static DynamicArray<MultiMatch> searchRepositoryMultiKeyword(AlumniRepository repo,
                                                                          DynamicArray<String> keywords,
                                                                          PatternMatcher.SearchField field) {
        AhoCorasick ac = build(keywords);
        DynamicArray<MultiMatch> results = new DynamicArray<>();
        DynamicArray<AlumniRecord> all = repo.getAll();

        for (int i = 0; i < all.size(); i++) {
            AlumniRecord rec = all.get(i);
            DynamicArray<String> matched = ac.findMatches(fieldValue(rec, field));
            if (matched.size() > 0) {
                results.add(new MultiMatch(rec, matched));
            }
        }

        for (int i = 1; i < results.size(); i++) {
            MultiMatch key = results.get(i);
            int j = i - 1;
            while (j >= 0 && results.get(j).matchedKeywords.size() < key.matchedKeywords.size()) {
                results.set(j + 1, results.get(j));
                j--;
            }
            results.set(j + 1, key);
        }
        return results;
    }

    private static String fieldValue(AlumniRecord rec, PatternMatcher.SearchField field) {
        switch (field) {
            case NAME: return rec.getName();
            case ORGANIZATION: return rec.getOrganization();
            case SKILLS: return rec.skillsAsString();
            case INTERESTS: return rec.interestsAsString();
            case BIO: return rec.getBio();
            case ALL:
            default:
                return rec.getName() + " " + rec.getOrganization() + " "
                        + rec.skillsAsString() + " " + rec.interestsAsString() + " " + rec.getBio();
        }
    }
}
