package com.alumniconnect.algorithms;

import com.alumniconnect.model.AlumniRecord;
import com.alumniconnect.repository.AlumniRepository;
import com.alumniconnect.util.DynamicArray;
import com.alumniconnect.util.TextOps;

/**
 * FuzzySearch
 * -----------
 * Typo-tolerant matching, computed as a hand-built edit-distance table
 * (classic dynamic-programming recurrence, no built-in min/max/lowercase
 * helpers -- see util.TextOps).
 *
 * Also powers AlumniConnect's "Did you mean...?" search suggestions
 * (buildVocabulary / suggestSimilarWords), offering close-spelling
 * alternatives before running the exact search.
 */
public class FuzzySearch {

    /** Closeness score between two strings: 0 = identical, higher = more different. */
    public static int editDistance(String a, String b) {
        int n = a.length();
        int m = b.length();
        int[][] dp = new int[n + 1][m + 1];

        for (int i = 0; i <= n; i++) dp[i][0] = i;
        for (int j = 0; j <= m; j++) dp[0][j] = j;

        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= m; j++) {
                if (a.charAt(i - 1) == b.charAt(j - 1)) {
                    dp[i][j] = dp[i - 1][j - 1];
                } else {
                    dp[i][j] = 1 + TextOps.min3(dp[i - 1][j - 1], dp[i][j - 1], dp[i - 1][j]);
                }
            }
        }
        return dp[n][m];
    }

    /**
     * Splits a field value into word tokens. Non-letter/non-digit characters
     * (spaces, commas, periods, etc.) are treated as delimiters.
     */
    private static DynamicArray<String> tokenize(String field) {
        DynamicArray<String> tokens = new DynamicArray<>();
        StringBuilder current = new StringBuilder();
        for (int i = 0; i < field.length(); i++) {
            char c = field.charAt(i);
            if (TextOps.isLetterOrDigit(c)) {
                current.append(c);
            } else if (current.length() > 0) {
                tokens.add(current.toString());
                current = new StringBuilder();
            }
        }
        if (current.length() > 0) tokens.add(current.toString());
        return tokens;
    }

    private static boolean containsIgnoreCase(DynamicArray<String> list, String value) {
        for (int i = 0; i < list.size(); i++) {
            if (TextOps.equalsIgnoreCase(list.get(i), value)) return true;
        }
        return false;
    }

    public static class FuzzyMatch {
        public AlumniRecord record;
        public String matchedToken;
        public int distance;
        public FuzzyMatch(AlumniRecord record, String matchedToken, int distance) {
            this.record = record;
            this.matchedToken = matchedToken;
            this.distance = distance;
        }
    }

    /**
     * Finds records whose closest token (in the chosen field) is within
     * maxDistance of the query. Sorted ascending by distance (hand-built
     * insertion sort).
     */
    public static DynamicArray<FuzzyMatch> fuzzySearch(AlumniRepository repo, String query,
                                                          PatternMatcher.SearchField field,
                                                          int maxDistance) {
        DynamicArray<FuzzyMatch> results = new DynamicArray<>();
        String q = TextOps.toLower(query);
        DynamicArray<AlumniRecord> all = repo.getAll();

        for (int i = 0; i < all.size(); i++) {
            AlumniRecord rec = all.get(i);
            String haystack = TextOps.toLower(fieldValue(rec, field));
            DynamicArray<String> tokens = tokenize(haystack);

            String bestToken = null;
            int bestDistance = Integer.MAX_VALUE;
            for (int t = 0; t < tokens.size(); t++) {
                int d = editDistance(q, tokens.get(t));
                if (d < bestDistance) {
                    bestDistance = d;
                    bestToken = tokens.get(t);
                }
            }

            if (bestToken != null && bestDistance <= maxDistance) {
                results.add(new FuzzyMatch(rec, bestToken, bestDistance));
            }
        }

        for (int i = 1; i < results.size(); i++) {
            FuzzyMatch key = results.get(i);
            int j = i - 1;
            while (j >= 0 && results.get(j).distance > key.distance) {
                results.set(j + 1, results.get(j));
                j--;
            }
            results.set(j + 1, key);
        }

        return results;
    }

    // ---------------------------------------------------------------
    // "Did you mean...?" search suggestions
    // ---------------------------------------------------------------

    public static class Suggestion {
        public String word;
        public int distance;
        public Suggestion(String word, int distance) {
            this.word = word;
            this.distance = distance;
        }
    }

    /** Collects every distinct word token appearing in the chosen field, across all records. */
    public static DynamicArray<String> buildVocabulary(AlumniRepository repo, PatternMatcher.SearchField field) {
        DynamicArray<String> vocabulary = new DynamicArray<>();
        DynamicArray<AlumniRecord> all = repo.getAll();
        for (int i = 0; i < all.size(); i++) {
            String haystack = fieldValue(all.get(i), field);
            DynamicArray<String> tokens = tokenize(haystack);
            for (int t = 0; t < tokens.size(); t++) {
                if (!containsIgnoreCase(vocabulary, tokens.get(t))) {
                    vocabulary.add(tokens.get(t));
                }
            }
        }
        return vocabulary;
    }

    /**
     * Finds close-spelling vocabulary words for a typed query (distance
     * 1..maxDistance, excluding an exact match), sorted ascending, capped
     * at maxSuggestions.
     */
    public static DynamicArray<Suggestion> suggestSimilarWords(DynamicArray<String> vocabulary, String query,
                                                                  int maxDistance, int maxSuggestions) {
        DynamicArray<Suggestion> suggestions = new DynamicArray<>();
        String q = TextOps.toLower(query);

        for (int i = 0; i < vocabulary.size(); i++) {
            String word = vocabulary.get(i);
            int d = editDistance(q, TextOps.toLower(word));
            if (d > 0 && d <= maxDistance) {
                suggestions.add(new Suggestion(word, d));
            }
        }

        for (int i = 1; i < suggestions.size(); i++) {
            Suggestion key = suggestions.get(i);
            int j = i - 1;
            while (j >= 0 && suggestions.get(j).distance > key.distance) {
                suggestions.set(j + 1, suggestions.get(j));
                j--;
            }
            suggestions.set(j + 1, key);
        }

        DynamicArray<Suggestion> capped = new DynamicArray<>();
        for (int i = 0; i < suggestions.size() && i < maxSuggestions; i++) {
            capped.add(suggestions.get(i));
        }
        return capped;
    }

    private static String fieldValue(AlumniRecord rec, PatternMatcher.SearchField field) {
        switch (field) {
            case NAME: return rec.getName();
            case ORGANIZATION: return rec.getOrganization();
            case SKILLS: return rec.skillsAsString();
            case INTERESTS: return rec.interestsAsString();
            case BIO: return rec.getBio();
            case ALL:
            default:
                return rec.getName() + " " + rec.getOrganization() + " "
                        + rec.skillsAsString() + " " + rec.interestsAsString() + " " + rec.getBio();
        }
    }
}
