package com.alumniconnect.algorithms;

import com.alumniconnect.model.AlumniRecord;
import com.alumniconnect.repository.AlumniRepository;
import com.alumniconnect.util.DynamicArray;
import com.alumniconnect.util.TextOps;

/**
 * PatternMatcher
 * --------------
 * CONCEPT: String Algorithms — Module 2 of the handout
 * ("Naive Pattern Matching" and "Knuth-Morris-Pratt (KMP)").
 *
 * In TextHack this powers keyword search over the article corpus. In
 * AlumniConnect it powers exact keyword search over alumni records: a
 * recruiter or student can search for an exact skill token ("React"),
 * an organization name ("Google"), or a name substring, and get back
 * every matching record.
 *
 * Two algorithms are implemented side-by-side, exactly as taught:
 *   1. Naive Pattern Matching — O(n*m) brute-force sliding comparison.
 *   2. Knuth-Morris-Pratt (KMP) — O(n+m) using the failure function
 *      (LPS array) to avoid re-comparing characters already known to match.
 *
 * A comparison counter is tracked for both so the efficiency gap can be
 * demonstrated live (this is exactly the classroom exercise in Practical
 * Session 3: "compare the number of comparisons performed by each algorithm").
 */
public class PatternMatcher {

    /** Result wrapper: match positions + number of character comparisons performed. */
    public static class MatchResult {
        public DynamicArray<Integer> positions = new DynamicArray<>();
        public long comparisons = 0;
    }

    // ---------------------------------------------------------------
    // 1. NAIVE PATTERN MATCHING  —  O(n*m)
    // ---------------------------------------------------------------
    public static MatchResult naiveSearch(String text, String pattern) {
        MatchResult result = new MatchResult();
        if (text == null || pattern == null || pattern.isEmpty()) return result;

        int n = text.length();
        int m = pattern.length();

        for (int i = 0; i <= n - m; i++) {
            int j;
            for (j = 0; j < m; j++) {
                result.comparisons++;
                if (text.charAt(i + j) != pattern.charAt(j)) {
                    break;
                }
            }
            if (j == m) {
                result.positions.add(i); // full match found at index i
            }
        }
        return result;
    }

    // ---------------------------------------------------------------
    // 2. KMP — Failure Function (LPS array) + Linear Search — O(n+m)
    // ---------------------------------------------------------------

    /**
     * Builds the LPS ("Longest Prefix which is also Suffix") array —
     * the KMP failure function — for the given pattern.
     * lps[i] = length of the longest proper prefix of pattern[0..i]
     *          that is also a suffix of pattern[0..i].
     */
    public static int[] computeLPS(String pattern) {
        int m = pattern.length();
        int[] lps = new int[m];
        if (m == 0) return lps; // empty pattern -> empty LPS array, nothing to compute
        int len = 0; // length of the previous longest prefix-suffix
        int i = 1;
        lps[0] = 0;

        while (i < m) {
            if (pattern.charAt(i) == pattern.charAt(len)) {
                len++;
                lps[i] = len;
                i++;
            } else {
                if (len != 0) {
                    len = lps[len - 1]; // fall back using the failure function itself
                } else {
                    lps[i] = 0;
                    i++;
                }
            }
        }
        return lps;
    }

    public static MatchResult kmpSearch(String text, String pattern) {
        MatchResult result = new MatchResult();
        if (text == null || pattern == null || pattern.isEmpty()) return result;

        int n = text.length();
        int m = pattern.length();
        int[] lps = computeLPS(pattern);

        int i = 0; // index into text
        int j = 0; // index into pattern

        while (i < n) {
            result.comparisons++;
            if (text.charAt(i) == pattern.charAt(j)) {
                i++;
                j++;
                if (j == m) {
                    result.positions.add(i - j); // match found
                    j = lps[j - 1];
                }
            } else {
                if (j != 0) {
                    j = lps[j - 1]; // no re-comparison of text[i]; jump pattern pointer
                } else {
                    i++;
                }
            }
        }
        return result;
    }

    // ---------------------------------------------------------------
    // Domain-level search: apply pattern matching across the repository
    // ---------------------------------------------------------------

    public enum SearchField { NAME, ORGANIZATION, SKILLS, INTERESTS, BIO, ALL }
    public enum Algorithm { NAIVE, KMP }

    public static class FieldSearchOutcome {
        public DynamicArray<AlumniRecord> matches = new DynamicArray<>();
        public long totalComparisons = 0;
    }

    /**
     * Searches every record in the repository for an exact occurrence of
     * `query` within the chosen field, using the chosen algorithm.
     * Case-insensitive (both text and pattern are lower-cased before matching,
     * which does not change algorithm behaviour, only comparison content).
     */
    public static FieldSearchOutcome searchRepository(AlumniRepository repo, String query,
                                                        SearchField field, Algorithm algorithm) {
        FieldSearchOutcome outcome = new FieldSearchOutcome();
        String pattern = TextOps.toLower(query);
        DynamicArray<AlumniRecord> all = repo.getAll();

        for (int i = 0; i < all.size(); i++) {
            AlumniRecord rec = all.get(i);
            String haystack = TextOps.toLower(fieldValue(rec, field));

            MatchResult mr = (algorithm == Algorithm.KMP)
                    ? kmpSearch(haystack, pattern)
                    : naiveSearch(haystack, pattern);

            outcome.totalComparisons += mr.comparisons;
            if (mr.positions.size() > 0) {
                outcome.matches.add(rec);
            }
        }
        return outcome;
    }

    private static String fieldValue(AlumniRecord rec, SearchField field) {
        switch (field) {
            case NAME: return rec.getName();
            case ORGANIZATION: return rec.getOrganization();
            case SKILLS: return rec.skillsAsString();
            case INTERESTS: return rec.interestsAsString();
            case BIO: return rec.getBio();
            case ALL:
            default:
                return rec.getName() + " " + rec.getOrganization() + " "
                        + rec.skillsAsString() + " " + rec.interestsAsString() + " " + rec.getBio();
        }
    }
}
