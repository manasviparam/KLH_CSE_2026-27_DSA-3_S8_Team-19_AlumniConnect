package com.alumniconnect.algorithms;

import com.alumniconnect.model.AlumniRecord;
import com.alumniconnect.repository.AlumniRepository;
import com.alumniconnect.util.DynamicArray;
import com.alumniconnect.util.TextOps;

/**
 * SimilarityEngine
 * ----------------
 * Powers AlumniConnect's "find similar alumni" feature: skills, interests,
 * and bio text are each compared via a hand-built longest-common-subsequence
 * length (dynamic programming, no built-in min/max), normalised into a
 * 0..1 similarity score, then combined into one weighted match score.
 */
public class SimilarityEngine {

    public static int lcsLength(String a, String b) {
        int n = a.length();
        int m = b.length();
        int[][] dp = new int[n + 1][m + 1];

        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= m; j++) {
                if (a.charAt(i - 1) == b.charAt(j - 1)) {
                    dp[i][j] = dp[i - 1][j - 1] + 1;
                } else {
                    dp[i][j] = TextOps.max(dp[i - 1][j], dp[i][j - 1]);
                }
            }
        }
        return dp[n][m];
    }

    /** Longest-common-subsequence length normalised by the longer string's length -> 0..1 score. */
    public static double lcsSimilarity(String a, String b) {
        if (a == null || b == null || a.length() == 0 || b.length() == 0) return 0.0;
        int lcs = lcsLength(TextOps.toLower(a), TextOps.toLower(b));
        int maxLen = TextOps.max(a.length(), b.length());
        return (double) lcs / (double) maxLen;
    }

    public static class SimilarityResult {
        public AlumniRecord record;
        public double skillSimilarity;
        public double interestSimilarity;
        public double bioSimilarity;
        public double combinedScore;

        public SimilarityResult(AlumniRecord record, double skillSimilarity,
                                 double interestSimilarity, double bioSimilarity) {
            this.record = record;
            this.skillSimilarity = skillSimilarity;
            this.interestSimilarity = interestSimilarity;
            this.bioSimilarity = bioSimilarity;
            // Skills weigh most for mentoring/placement matches, interests next,
            // bio-text overlap as a light supporting signal.
            this.combinedScore = (0.5 * skillSimilarity) + (0.3 * interestSimilarity) + (0.2 * bioSimilarity);
        }
    }

    /**
     * Ranks every other record in the repository by similarity to `target`.
     * Sorted by descending combined score (hand-built insertion sort).
     */
    public static DynamicArray<SimilarityResult> findSimilarAlumni(AlumniRepository repo,
                                                                     AlumniRecord target) {
        DynamicArray<SimilarityResult> results = new DynamicArray<>();
        DynamicArray<AlumniRecord> all = repo.getAll();

        for (int i = 0; i < all.size(); i++) {
            AlumniRecord candidate = all.get(i);
            if (candidate.getId() == target.getId()) continue;

            double skillScore = lcsSimilarity(target.skillsAsString(), candidate.skillsAsString());
            double interestScore = lcsSimilarity(target.interestsAsString(), candidate.interestsAsString());
            double bioScore = lcsSimilarity(target.getBio(), candidate.getBio());

            results.add(new SimilarityResult(candidate, skillScore, interestScore, bioScore));
        }

        for (int i = 1; i < results.size(); i++) {
            SimilarityResult key = results.get(i);
            int j = i - 1;
            while (j >= 0 && results.get(j).combinedScore < key.combinedScore) {
                results.set(j + 1, results.get(j));
                j--;
            }
            results.set(j + 1, key);
        }

        return results;
    }
}
