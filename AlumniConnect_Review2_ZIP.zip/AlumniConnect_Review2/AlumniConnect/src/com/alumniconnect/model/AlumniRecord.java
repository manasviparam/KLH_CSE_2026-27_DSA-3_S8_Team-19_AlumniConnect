package com.alumniconnect.model;

import com.alumniconnect.util.DynamicArray;
import com.alumniconnect.util.TextOps;

/**
 * AlumniRecord
 * ------------
 * Core data entity of AlumniConnect. Each record represents one person
 * (student, alumnus, or mentor) in the network, along with the attributes
 * the matching engine operates on: skills, interests, organization, and a
 * short bio.
 */
public class AlumniRecord {

    private final int id;
    private String name;
    private String role;          // "Student", "Alumni", "Mentor"
    private String organization;  // current company / institution
    private int graduationYear;
    private DynamicArray<String> skills;
    private DynamicArray<String> interests;
    private String bio;

    public AlumniRecord(int id, String name, String role, String organization,
                         int graduationYear, DynamicArray<String> skills,
                         DynamicArray<String> interests, String bio) {
        this.id = id;
        this.name = name;
        this.role = role;
        this.organization = organization;
        this.graduationYear = graduationYear;
        this.skills = skills;
        this.interests = interests;
        this.bio = bio;
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public String getRole() { return role; }
    public String getOrganization() { return organization; }
    public int getGraduationYear() { return graduationYear; }
    public DynamicArray<String> getSkills() { return skills; }
    public DynamicArray<String> getInterests() { return interests; }
    public String getBio() { return bio; }

    /** Flattens skills into a single space-joined string. */
    public String skillsAsString() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < skills.size(); i++) {
            sb.append(skills.get(i));
            if (i != skills.size() - 1) sb.append(" ");
        }
        return sb.toString();
    }

    public String interestsAsString() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < interests.size(); i++) {
            sb.append(interests.get(i));
            if (i != interests.size() - 1) sb.append(" ");
        }
        return sb.toString();
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("[ID:").append(TextOps.padLeftZero(id, 2)).append("] ")
          .append(TextOps.padRight(name, 18)).append(" | ")
          .append(TextOps.padRight(role, 8)).append(" | ")
          .append(TextOps.padRight(organization, 20)).append(" | Batch:")
          .append(TextOps.intToString(graduationYear)).append("\n");
        sb.append("         Skills   : ").append(skillsAsString()).append("\n");
        sb.append("         Interests: ").append(interestsAsString()).append("\n");
        sb.append("         Bio      : ").append(bio);
        return sb.toString();
    }

    /** Compact one-line form used in result lists. */
    public String toCompactString() {
        StringBuilder sb = new StringBuilder();
        sb.append("[ID:").append(TextOps.padLeftZero(id, 2)).append("] ")
          .append(TextOps.padRight(name, 18))
          .append(" (").append(role).append(" @ ").append(organization).append(") | Skills: ")
          .append(skillsAsString());
        return sb.toString();
    }
}
