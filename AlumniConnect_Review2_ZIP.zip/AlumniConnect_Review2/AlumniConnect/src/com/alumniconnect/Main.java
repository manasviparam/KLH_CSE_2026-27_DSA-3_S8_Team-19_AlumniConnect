package com.alumniconnect;

import com.alumniconnect.model.AlumniRecord;
import com.alumniconnect.repository.AlumniRepository;
import com.alumniconnect.repository.CorpusRepository;
import com.alumniconnect.repository.DataSeeder;
import com.alumniconnect.algorithms.AhoCorasick;
import com.alumniconnect.algorithms.PatternMatcher;
import com.alumniconnect.algorithms.FuzzySearch;
import com.alumniconnect.algorithms.SimilarityEngine;
import com.alumniconnect.io.AutocompleteReader;
import com.alumniconnect.util.DynamicArray;
import com.alumniconnect.util.TextOps;

import java.io.IOException;
// AutocompleteReader (io package) is this project's terminal I/O boundary --
// the role Scanner used to play, now upgraded to show live autocomplete
// suggestions from the corpus Trie as the user types. No data storage,
// comparison, parsing, or algorithm logic is delegated to it; that is all
// hand-built in util/TextOps, util/Trie, util/DynamicArray, and
// algorithms/AhoCorasick, and used throughout this file.

/**
 * Main
 * ----
 * AlumniConnect -- menu-driven terminal application.
 * Type 'back' at any prompt to cancel the current action and return to the
 * main menu without exiting the application.
 */
public class Main {

    private static AutocompleteReader in;
    private static AlumniRepository repo = new AlumniRepository();
    private static CorpusRepository corpus = new CorpusRepository();

    /** Thrown when the user types 'back' at any prompt; caught in the main loop. */
    private static class CancelInputException extends RuntimeException {}

    /** Thrown when input ends for good (Ctrl+D, or piped input running dry); ends the app, not just the current prompt. */
    private static class EndOfInputException extends RuntimeException {}

    public static void main(String[] args) {
        System.out.println("=================================================");
        System.out.println("   ALUMNI CONNECT");
        System.out.println("=================================================");

        corpus.load();
        DataSeeder.seed(repo);
        corpus.mergeFromRepository(repo);
        System.out.println("Loaded " + repo.size() + " sample records.");

        try {
            in = new AutocompleteReader(corpus.getTrie());
        } catch (IOException e) {
            System.out.println("Could not start terminal input: " + e.getMessage());
            return;
        }

        try {
            boolean running = true;
            while (running) {
                printMenu();
                int choice;
                try {
                    choice = readInt("Enter choice: ");
                } catch (CancelInputException e) {
                    continue;
                } catch (EndOfInputException e) {
                    System.out.println("\nGoodbye!");
                    break;
                }

                try {
                    switch (choice) {
                        case 1: addAlumniRecord(); break;
                        case 2: viewAllRecords(); break;
                        case 3: searchAlumniMenu(); break;
                        case 4: fuzzySearchMenu(); break;
                        case 5: similarityMenu(); break;
                        case 0:
                            running = false;
                            System.out.println("Goodbye!");
                            break;
                        default:
                            System.out.println("Invalid choice, try again.");
                    }
                } catch (CancelInputException e) {
                    System.out.println("Cancelled.");
                } catch (EndOfInputException e) {
                    System.out.println("\nGoodbye!");
                    break;
                }
            }
        } finally {
            in.close();
        }
    }

    private static void printMenu() {
        System.out.println("\n------------------- MENU -------------------");
        System.out.println("1. Add Alumni/Student Record");
        System.out.println("2. View All Records");
        System.out.println("3. Search Alumni");
        System.out.println("4. Smart Search");
        System.out.println("5. Find Similar Alumni");
        System.out.println("0. Exit");
        System.out.println("(Type 'back' at any prompt to cancel and return here.)");
        System.out.println("----------------------------------------------");
    }

    // ---------------------------------------------------------------
    // Add record
    // ---------------------------------------------------------------
    private static void addAlumniRecord() {
        String name = readLine("Name: ");
        String role = readLine("Role (Student/Alumni/Mentor): ");
        String org = readLine("Organization/College: ");
        int gradYear = readInt("Graduation Year: ");
        DynamicArray<String> skills = readCsvList("Skills (comma-separated): ");
        DynamicArray<String> interests = readCsvList("Interests (comma-separated): ");
        String bio = readLine("Short bio: ");

        AlumniRecord rec = repo.addRecord(name, role, org, gradYear, skills, interests, bio);
        corpus.addRecordTerms(rec); // feeds the autocomplete Trie and maintains data/corpus.txt
        System.out.println("Record added:");
        System.out.println(rec);
    }

    private static DynamicArray<String> readCsvList(String prompt) {
        String line = readLine(prompt);
        DynamicArray<String> list = new DynamicArray<>();
        StringBuilder current = new StringBuilder();
        for (int i = 0; i < line.length(); i++) {
            char c = line.charAt(i);
            if (c == ',') {
                String token = TextOps.trim(current.toString());
                if (token.length() > 0) list.add(token);
                current = new StringBuilder();
            } else {
                current.append(c);
            }
        }
        String last = TextOps.trim(current.toString());
        if (last.length() > 0) list.add(last);
        return list;
    }

    // ---------------------------------------------------------------
    // View all
    // ---------------------------------------------------------------
    private static void viewAllRecords() {
        if (repo.isEmpty()) {
            System.out.println("No records yet.");
            return;
        }
        System.out.println("Records (" + repo.size() + "):");
        DynamicArray<AlumniRecord> all = repo.getAll();
        for (int i = 0; i < all.size(); i++) {
            System.out.println(all.get(i));
            System.out.println("---------------------------------------------");
        }
    }

    private static void printIdNameList() {
        DynamicArray<AlumniRecord> all = repo.getAll();
        for (int i = 0; i < all.size(); i++) {
            AlumniRecord r = all.get(i);
            System.out.println(TextOps.padLeftZero(r.getId(), 2) + ". " + r.getName());
        }
    }

    // ---------------------------------------------------------------
    // Search Alumni: exact search + "Did you mean?" suggestions
    // ---------------------------------------------------------------
    private static void searchAlumniMenu() {
        PatternMatcher.SearchField field = chooseField();
        String query = readLine("Enter search term: ");
        if (TextOps.trim(query).length() == 0) {
            System.out.println("Empty query -- nothing to search.");
            return;
        }

        DynamicArray<String> vocabulary = FuzzySearch.buildVocabulary(repo, field);
        DynamicArray<FuzzySearch.Suggestion> suggestions =
                FuzzySearch.suggestSimilarWords(vocabulary, query, 3, 5);

        String resolvedQuery = query;
        if (suggestions.size() > 0) {
            System.out.println("\nDid you mean:");
            for (int i = 0; i < suggestions.size(); i++) {
                System.out.println("  " + (i + 1) + ". " + suggestions.get(i).word);
            }
            String pick = readLine("Pick a number, or press Enter to search \"" + query + "\" as typed: ");
            if (TextOps.trim(pick).length() > 0) {
                try {
                    int idx = TextOps.parseInt(pick);
                    if (idx >= 1 && idx <= suggestions.size()) {
                        resolvedQuery = suggestions.get(idx - 1).word;
                    } else {
                        System.out.println("Invalid selection -- searching \"" + query + "\" as typed.");
                    }
                } catch (NumberFormatException e) {
                    System.out.println("Invalid selection -- searching \"" + query + "\" as typed.");
                }
            }
        }

        // Several space-separated terms ("java react mentoring") are matched all
        // at once against every record in a single pass; a lone term keeps the
        // existing single-pattern exact search below.
        DynamicArray<String> terms = splitTerms(resolvedQuery);
        if (terms.size() > 1) {
            multiKeywordSearch(terms, field);
            return;
        }

        PatternMatcher.FieldSearchOutcome outcome =
                PatternMatcher.searchRepository(repo, resolvedQuery, field, PatternMatcher.Algorithm.KMP);

        if (outcome.matches.size() == 0) {
            System.out.println("No matches found.");
            return;
        }
        System.out.println("Found " + outcome.matches.size() + " match(es):");
        for (int i = 0; i < outcome.matches.size(); i++) {
            System.out.println("  -> " + outcome.matches.get(i).toCompactString());
        }

        if (readYesNo("Show additional details? (y/n): ")) {
            System.out.println("Characters compared: " + outcome.totalComparisons);
        }
    }

    private static void multiKeywordSearch(DynamicArray<String> terms, PatternMatcher.SearchField field) {
        DynamicArray<AhoCorasick.MultiMatch> matches =
                AhoCorasick.searchRepositoryMultiKeyword(repo, terms, field);

        if (matches.size() == 0) {
            System.out.println("No matches found.");
            return;
        }
        System.out.println("Found " + matches.size() + " match(es):");
        for (int i = 0; i < matches.size(); i++) {
            System.out.println("  -> " + matches.get(i).record.toCompactString());
        }

        if (readYesNo("Show additional details? (y/n): ")) {
            for (int i = 0; i < matches.size(); i++) {
                AhoCorasick.MultiMatch m = matches.get(i);
                System.out.println("     matched " + m.matchedKeywords.size() + " keyword(s): "
                        + joinWithCommas(m.matchedKeywords));
            }
        }
    }

    private static String joinWithCommas(DynamicArray<String> words) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < words.size(); i++) {
            sb.append(words.get(i));
            if (i != words.size() - 1) sb.append(", ");
        }
        return sb.toString();
    }

    /** Splits on whitespace (space/tab), discarding empty tokens -- used to detect multi-keyword queries. */
    private static DynamicArray<String> splitTerms(String line) {
        DynamicArray<String> list = new DynamicArray<>();
        StringBuilder current = new StringBuilder();
        for (int i = 0; i < line.length(); i++) {
            char c = line.charAt(i);
            if (c == ' ' || c == '\t') {
                String token = current.toString();
                if (token.length() > 0) list.add(token);
                current = new StringBuilder();
            } else {
                current.append(c);
            }
        }
        String last = current.toString();
        if (last.length() > 0) list.add(last);
        return list;
    }

    // ---------------------------------------------------------------
    // Fuzzy Search: typo-tolerant search
    // ---------------------------------------------------------------
    private static void fuzzySearchMenu() {
        PatternMatcher.SearchField field = chooseField();
        String query = readLine("Enter search term (typos okay): ");
        if (TextOps.trim(query).length() == 0) {
            System.out.println("Empty query -- nothing to search.");
            return;
        }
        int tolerance = readInt("Typo tolerance (0 = exact, higher = more typos allowed, e.g. 2): ");

        DynamicArray<FuzzySearch.FuzzyMatch> matches =
                FuzzySearch.fuzzySearch(repo, query, field, tolerance);

        if (matches.size() == 0) {
            System.out.println("No matches found.");
            return;
        }
        System.out.println("Found " + matches.size() + " possible match(es):");
        for (int i = 0; i < matches.size(); i++) {
            System.out.println("  -> " + matches.get(i).record.toCompactString());
        }

        if (readYesNo("Show additional details? (y/n): ")) {
            for (int i = 0; i < matches.size(); i++) {
                FuzzySearch.FuzzyMatch m = matches.get(i);
                System.out.println("     matched on \"" + m.matchedToken + "\" (closeness score: " + m.distance + ")");
            }
        }
    }

    // ---------------------------------------------------------------
    // Find Similar Alumni
    // ---------------------------------------------------------------
    private static void similarityMenu() {
        if (repo.isEmpty()) {
            System.out.println("No records yet.");
            return;
        }
        printIdNameList();
        int id = readInt("Enter the ID of the record to find matches for: ");
        AlumniRecord target = repo.getById(id);
        if (target == null) {
            System.out.println("No record found with ID " + id);
            return;
        }

        DynamicArray<SimilarityEngine.SimilarityResult> results =
                SimilarityEngine.findSimilarAlumni(repo, target);

        if (results.size() == 0) {
            System.out.println("No other records to compare against.");
            return;
        }
        System.out.println("Top matches for " + target.getName() + ":");
        int shown = 0;
        for (int i = 0; i < results.size() && shown < 5; i++, shown++) {
            SimilarityEngine.SimilarityResult r = results.get(i);
            StringBuilder sb = new StringBuilder();
            sb.append("  -> ").append(TextOps.padRight(r.record.getName(), 18))
              .append(" | Skill similarity=").append(TextOps.formatDecimal2(r.skillSimilarity))
              .append(" | Interest similarity=").append(TextOps.formatDecimal2(r.interestSimilarity))
              .append(" | Bio similarity=").append(TextOps.formatDecimal2(r.bioSimilarity))
              .append(" | Overall similarity=").append(TextOps.formatDecimal2(r.combinedScore));
            System.out.println(sb.toString());
        }
    }

    // ---------------------------------------------------------------
    // Shared helpers
    // ---------------------------------------------------------------
    private static PatternMatcher.SearchField chooseField() {
        System.out.println("Search field: 1-Name 2-Organization 3-Skills 4-Interests 5-Bio 6-All");
        int f = readInt("Choose field: ");
        switch (f) {
            case 1: return PatternMatcher.SearchField.NAME;
            case 2: return PatternMatcher.SearchField.ORGANIZATION;
            case 3: return PatternMatcher.SearchField.SKILLS;
            case 4: return PatternMatcher.SearchField.INTERESTS;
            case 5: return PatternMatcher.SearchField.BIO;
            default: return PatternMatcher.SearchField.ALL;
        }
    }

    private static boolean readYesNo(String prompt) {
        String ans = TextOps.trim(readLine(prompt));
        return TextOps.equalsIgnoreCase(ans, "y") || TextOps.equalsIgnoreCase(ans, "yes");
    }

    /**
     * Reads one line of input (with live autocomplete suggestions from the
     * corpus Trie). Typing 'back' (any case) cancels the current feature;
     * Ctrl+D (end of input) does the same.
     */
    private static String readLine(String prompt) {
        String line = in.readLine(prompt);
        if (line == null) throw new EndOfInputException();
        if (TextOps.equalsIgnoreCase(TextOps.trim(line), "back")) {
            throw new CancelInputException();
        }
        return line;
    }

    /** Reads an integer. Typing 'back' cancels; Ctrl+D ends the app; non-numeric input reprompts. */
    private static int readInt(String prompt) {
        while (true) {
            String raw = in.readLine(prompt);
            if (raw == null) throw new EndOfInputException();
            String line = TextOps.trim(raw);
            if (TextOps.equalsIgnoreCase(line, "back")) {
                throw new CancelInputException();
            }
            try {
                return TextOps.parseInt(line);
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid number (or 'back' to cancel).");
            }
        }
    }
}
