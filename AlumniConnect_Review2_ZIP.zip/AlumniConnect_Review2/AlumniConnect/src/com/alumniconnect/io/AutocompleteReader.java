package com.alumniconnect.io;

import com.alumniconnect.util.DynamicArray;
import com.alumniconnect.util.Trie;

import org.jline.reader.Candidate;
import org.jline.reader.Completer;
import org.jline.reader.Binding;
import org.jline.reader.EndOfFileException;
import org.jline.reader.LineReader;
import org.jline.reader.LineReader.Option;
import org.jline.reader.LineReaderBuilder;
import org.jline.reader.ParsedLine;
import org.jline.reader.Reference;
import org.jline.reader.UserInterruptException;
import org.jline.keymap.KeyMap;
import org.jline.terminal.Terminal;
import org.jline.terminal.TerminalBuilder;
import org.jline.widget.TailTipWidgets;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

/**
 * AutocompleteReader
 * -------------------
 * This project's I/O boundary for reading terminal input -- the same role
 * java.util.Scanner played before, upgraded to also show live, as-you-type
 * suggestions pulled from the hand-built Trie (see util.Trie).
 *
 * WHY JLINE: plain Java has no portable way to read individual keystrokes
 * and redraw a suggestion line before Enter is pressed -- the terminal
 * stays line-buffered and the JDK has no built-in raw-mode console API.
 * JLine is used ONLY for that raw keystroke I/O and screen redraw; every
 * bit of matching/ranking logic behind it -- the Trie itself and its
 * prefix search -- is still 100% hand-built, exactly like the rest of
 * this project. The java.util.Map/List types below appear only because
 * JLine's own constructor/interface signatures require them; nothing is
 * stored or decided in them -- they are handed straight to JLine, same
 * boundary as Scanner already was.
 */
public class AutocompleteReader {

    private final Terminal terminal;
    private final LineReader reader;
    private final TailTipWidgets tailTips;

    public AutocompleteReader(Trie suggestionSource) throws IOException {
        terminal = TerminalBuilder.builder().system(true).build();
        Completer completer = new TrieCompleter(suggestionSource);
        reader = LineReaderBuilder.builder()
                .terminal(terminal)
                .completer(completer)
                .build();
        // AUTO_MENU_LIST turns Tab into an actual navigable selection menu
        // (arrow keys / Tab to move, Enter to pick) whenever there's more
        // than one matching suggestion, instead of only listing them.
        reader.setOpt(Option.AUTO_MENU_LIST);
        reader.setOpt(Option.LIST_AMBIGUOUS);
        // TipType.COMPLETER shows the Trie's matches live, below the line, as
        // each character is typed -- no Tab press needed. The empty map is
        // JLine's "no command descriptions" argument; unused otherwise.
        tailTips = new TailTipWidgets(reader, new HashMap<>(), 0, TailTipWidgets.TipType.COMPLETER);
        // Only turn the live-suggestion display on for a real terminal. When
        // stdin isn't an actual console (input piped/redirected -- e.g. some
        // CI or automation contexts) JLine falls back to a "dumb" terminal
        // with no screen to redraw, and enabling the widgets there leaves it
        // in a state that throws on close(); readLine() still works fine
        // without them, just without the live suggestions.
        if (!Terminal.TYPE_DUMB.equals(terminal.getType()) && !Terminal.TYPE_DUMB_COLOR.equals(terminal.getType())) {
            tailTips.enable();
        }
        // Bind AFTER tailTips.enable() so this wins: Tab always opens JLine's
        // real interactive selection menu (arrow keys to move, Enter to pick)
        // rather than TailTipWidgets' own Tab handling, which only ever
        // inserts/lists and has no arrow-key selection of its own.
        KeyMap<Binding> mainKeyMap = reader.getKeyMaps().get(LineReader.MAIN);
        mainKeyMap.bind(new Reference(LineReader.MENU_SELECT), KeyMap.ctrl('I'));
    }

    /**
     * Reads one line, showing live completions as the user types.
     * Returns null on Ctrl+D (end of input).
     */
    public String readLine(String prompt) {
        try {
            return reader.readLine(prompt);
        } catch (UserInterruptException e) {
            return "back"; // Ctrl+C behaves like typing 'back'
        } catch (EndOfFileException e) {
            return null;
        }
    }

    public void close() {
        try {
            terminal.close();
        } catch (Exception ignored) {
            // nothing further to do if the terminal fails to close on exit
        }
    }

    /**
     * Bridges JLine's Completer contract to our hand-built Trie. The only
     * thing this class does is call Trie.wordsWithPrefix() and hand the
     * results to JLine in the shape it requires.
     */
    private static class TrieCompleter implements Completer {
        private final Trie trie;

        TrieCompleter(Trie trie) {
            this.trie = trie;
        }

        @Override
        public void complete(LineReader lineReader, ParsedLine parsedLine, List<Candidate> candidates) {
            String word = parsedLine.word();
            if (word == null || word.length() == 0) return;
            DynamicArray<String> matches = trie.wordsWithPrefix(word, 8);
            for (int i = 0; i < matches.size(); i++) {
                candidates.add(new Candidate(matches.get(i)));
            }
        }
    }
}
