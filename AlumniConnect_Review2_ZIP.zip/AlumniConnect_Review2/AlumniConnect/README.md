# AlumniConnect

A terminal-based Java application for an alumni networking / mentoring /
placement-matching platform. Everything — storage, string operations, and
search/matching logic — is hand-built from scratch: no `java.util`
collections, and no built-in `String`/`Character`/`Math`/formatting helpers
(`toLowerCase`, `equalsIgnoreCase`, `trim`, `Integer.parseInt`, `Math.min/max`,
`String.format`) are used anywhere in the core logic. The only exception is
terminal I/O itself — reading input has to go through some I/O class, so
`java.util.Scanner` was used for that boundary, and it has since been
upgraded to the [JLine](https://jline.org) library (`lib/jline-3.26.3.jar`)
purely to read raw keystrokes and redraw live autocomplete suggestions —
something the JDK has no portable, built-in way to do. Every suggestion
JLine displays still comes from a hand-built Trie (`util/Trie.java`); JLine
never does any matching or ranking itself.

The on-screen menu and prompts are kept plain and functional — no internal
algorithm names, comparison stats, or matrices are shown unless you
explicitly ask via an on-screen "Show additional details?" prompt, and even
then only a simple number is shown, never a full table. This is also why
menu option 4 is labelled "Smart Search" rather than naming the fuzzy-match
algorithm behind it, and why multi-keyword matching (Aho-Corasick, see
below) lives silently inside option 3 rather than getting its own menu
entry — it activates automatically whenever a search term contains more
than one word.

## How to run in VS Code

1. Unzip `AlumniConnect.zip` and open the resulting `AlumniConnect` folder
   in VS Code.
2. Install the **"Extension Pack for Java"** (by Microsoft) if you don't
   already have it.
3. `lib/jline-3.26.3.jar` is already referenced via `.vscode/settings.json`
   (`java.project.referencedLibraries`), so no extra setup is needed.
4. Open `src/com/alumniconnect/Main.java`.
5. Click **Run** above `public static void main(...)` (or press `F5`).
6. Use the integrated terminal to interact with the menu — start typing a
   skill/interest/name and matching suggestions from the corpus appear live
   below the line.

## How to run from a plain terminal (no VS Code)

macOS/Linux:
```bash
cd AlumniConnect
mkdir -p bin
javac -cp "lib/jline-3.26.3.jar" -d bin $(find src -name "*.java")
java -cp "bin:lib/jline-3.26.3.jar" com.alumniconnect.Main
```

Windows (PowerShell):
```powershell
cd AlumniConnect
New-Item -ItemType Directory -Force -Path bin | Out-Null
$files = Get-ChildItem -Recurse -Filter *.java src | ForEach-Object { $_.FullName }
javac -cp "lib\jline-3.26.3.jar" -d bin $files
java -cp "bin;lib\jline-3.26.3.jar" com.alumniconnect.Main
```

Run it from the `AlumniConnect` folder itself (not a parent directory) —
the corpus file at `data/corpus.txt` is read/written relative to the
working directory.

Note: if stdin isn't a real terminal (piped/redirected input, some CI
runners), JLine falls back to a plain "dumb" terminal automatically — input
still works, just without the live suggestion display.

## Menu overview

```
1. Add Alumni/Student Record
2. View All Records
3. Search Alumni           -> type a term; if close-spelling words exist in
                               the data, pick a "Did you mean?" suggestion
                               or press Enter to search your term as typed.
                               Typing several words ("java react mentoring")
                               matches all of them at once, ranked by how
                               many keywords each record contains.
4. Smart Search             -> typo-tolerant search; set how many typo
                               differences to allow.
5. Find Similar Alumni      -> ranked match list based on shared skills,
                               interests, and bio text.
0. Exit
```

Type `back` at any prompt to cancel out of the current action and return
to the menu without exiting the app. Wherever you type a name, skill, or
interest, live autocomplete suggestions from `data/corpus.txt` appear below
the line as you type.

The repository is preloaded with 5 sample records (`repository/DataSeeder.java`)
so every feature has data immediately — add more live via option 1.

## The autocomplete corpus

`data/corpus.txt` is a plain-text vocabulary file (one term per line) that
feeds the live autocomplete suggestions. It starts out hand-curated with
common skill/interest terms, and every name/skill/interest already in the
repository is merged in at startup. It is also **maintained automatically**:
any genuinely new term you type in via "Add Alumni/Student Record" is
appended to the file (skipping anything already present, case-insensitive),
so it keeps growing across runs instead of resetting each time.

## Project structure

```
AlumniConnect/
├── README.md
├── lib/
│   └── jline-3.26.3.jar            (terminal I/O only -- see note above)
├── data/
│   └── corpus.txt                  (autocomplete vocabulary, auto-maintained)
├── .vscode/
│   ├── launch.json
│   └── settings.json               (references lib/*.jar for VS Code's Java extension)
└── src/
    └── com/alumniconnect/
        ├── Main.java                       (menu-driven CLI)
        ├── model/
        │   └── AlumniRecord.java           (data entity)
        ├── repository/
        │   ├── AlumniRepository.java       (record storage)
        │   ├── CorpusRepository.java       (loads/merges/maintains data/corpus.txt)
        │   └── DataSeeder.java             (sample data)
        ├── algorithms/
        │   ├── PatternMatcher.java         (exact search: KMP; Naive kept but unused)
        │   ├── FuzzySearch.java            (typo-tolerant search + "did you mean" suggestions)
        │   ├── AhoCorasick.java            (multi-keyword search: one pass matches several terms at once)
        │   └── SimilarityEngine.java       (text-similarity ranked matching)
        ├── io/
        │   └── AutocompleteReader.java     (terminal I/O boundary: JLine for keystrokes/redraw, Trie for suggestions)
        └── util/
            ├── DynamicArray.java           (hand-built generic array, no java.util.ArrayList)
            ├── TextOps.java                (hand-built string/number helpers, no built-in equivalents)
            └── Trie.java                   (hand-built prefix tree powering autocomplete)
```
